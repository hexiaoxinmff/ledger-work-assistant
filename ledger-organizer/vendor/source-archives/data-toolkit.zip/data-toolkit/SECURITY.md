# Security Policy

**Phronesis Applied — Data Toolkit**

This toolkit is local-first: the compute engines run on the user's machine and do not
upload files, call home, or send telemetry. Please read [`PRINCIPLES.md` — Data handling & PII](PRINCIPLES.md#data-handling--pii-policy)
for the standing PII / confidential-data rule.

## Supported versions

| Version | Supported |
|---|---|
| Latest `main` / tagged release (currently 0.5.x) | Yes |
| Older tagged releases | Best-effort — please upgrade |

## Reporting a vulnerability

**Please do not open a public GitHub issue for security reports.**

Email **[hello@phronesis-applied.com](mailto:hello@phronesis-applied.com)** with:

- a short description of the issue and its impact
- steps to reproduce (or a proof-of-concept)
- affected version / commit if known
- whether you are okay being credited

We aim to acknowledge within a few business days and to keep you updated until the fix
ships or we explain why we are not treating it as a vulnerability.

## What this project considers in scope

- Bugs in the **local Python engines** that could cause wrong money maths, silent data loss,
  or unsafe defaults (e.g. inventing figures, force-fitting reconciliations)
- Failures of the **PII / confidential-data posture** in shipped code or hooks (egress
  tokenisation guidance, accidental logging of secrets in toolkit code)
- Supply-chain issues in this repository (malicious content, compromised release artefacts)

## Out of scope

- The **Claude / Anthropic host** (Claude Code, Cowork, Claude.ai) — model behaviour,
  prompt injection against the host, and cloud processing of prompts are governed by
  Anthropic's own security and data policies. Report host issues to Anthropic.
- Vulnerabilities that require the user to deliberately disable local safeguards or paste
  secrets into a chat
- Third-party optional dependencies (`PyMuPDF`, `pdfplumber`, etc.) — report upstream;
  we will bump or document once a fix is available
- Social-engineering / phishing that does not involve this codebase

## Agent runtime — intended use

`bin/data-toolkit` is built for **attended, human-in-the-loop** use (a person driving an AI
agent who reviews and confirms each step). Its guardrails — schema validation, plan confirmation,
signed approval receipts — assume that model.

- The signed approval receipts are a real control only when the signing key is held by an
  operator process **separate from the agent**. In a single attended session they are a
  convenience and an audit record, not a security boundary.
- The runtime does **not** sandbox the filesystem: a plan names its own input/output paths and
  the engines read/write them with the process's privileges. Confinement, input-size limits and
  network isolation are the host's responsibility.
- For **unattended automation**, call the deterministic engines directly as scripts and add your
  own controls; don't point the interactive agent runtime at a pipeline expecting it to be a
  hardened gateway. See [`RUNTIME.md`](RUNTIME.md) → *Intended use and trust model*.

## Data handling summary

- Engines read local files the user points them at and write outputs back to local folders
- No network calls in the core path; dashboards are self-contained HTML (no CDN)
- Shared drives are reached as **synced local paths**, not cloud connectors
- **The AI agent driving the skills is not local**: whatever it reads into its context is sent
  to the AI provider (see above). The toolkit does not claim your data never leaves the machine
  — it claims the *processing* is local and that no third party beyond your AI provider sees it.
  See [`PRINCIPLES.md` — Data handling & PII](PRINCIPLES.md#data-handling--pii-policy)
- Skills produce **drafts for a qualified person** — never post to ledgers or auto-send

If you believe a shipped code path violates that summary, treat it as in-scope and email us.
