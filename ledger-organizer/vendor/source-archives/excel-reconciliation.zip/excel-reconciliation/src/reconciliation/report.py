"""Run reporting: structured logs, exception workbook, run summary.

A reconciliation run produces two kinds of output. The summary says whether
anything is wrong and how much. The exception report says exactly which keys
are wrong, so the person who owns the data can go and look at those rows
rather than the whole extract.

Both are written even when every check passes, because "the run happened and
found nothing" is itself a useful record to keep next to a report that went
out to a business user.
"""

from __future__ import annotations

import json
import logging
import re
import sys
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import IO, Any, Protocol, runtime_checkable

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

__all__ = [
    "CheckResult",
    "KeyValueFormatter",
    "RunReport",
    "configure_logging",
    "new_run_id",
]

LOGGER = logging.getLogger(__name__)

_INVALID_SHEET_CHARS = re.compile(r"[\[\]:*?/\\]")
_MAX_SHEET_NAME = 31
_MAX_COLUMN_WIDTH = 48

_HEADER_FILL = PatternFill("solid", fgColor="D9D9D9")
_HEADER_FONT = Font(bold=True)


@runtime_checkable
class CheckResult(Protocol):
    """What every check result must provide to be reportable."""

    def summary(self) -> dict[str, object]:
        """Return a flat mapping describing the outcome of the check."""

    def exception_frames(self) -> dict[str, pd.DataFrame]:
        """Return non-empty exception tables, keyed by report sheet name."""


class KeyValueFormatter(logging.Formatter):
    """Format log records as ``key=value`` lines.

    Structured lines survive being grepped, shipped to a log collector or
    pasted into a ticket, which free-text messages do not. Callers put the
    structured part in ``extra={"fields": {...}}`` and use the message itself
    as a stable event name.
    """

    def format(self, record: logging.LogRecord) -> str:
        """Render one record as a single ``key=value`` line."""
        timestamp = datetime.fromtimestamp(record.created, tz=timezone.utc)
        parts = [
            f"ts={timestamp.isoformat(timespec='milliseconds')}",
            f"level={record.levelname}",
            f"logger={record.name}",
            f"event={record.getMessage()}",
        ]
        fields = getattr(record, "fields", None)
        if isinstance(fields, Mapping):
            parts.extend(
                f"{key}={_format_value(value)}" for key, value in fields.items()
            )
        if record.exc_info:
            parts.append(f"exc={_quote(self.formatException(record.exc_info))}")
        return " ".join(parts)


def _format_value(value: object) -> str:
    """Render a single log field value without breaking the line format."""
    if isinstance(value, (list, tuple)):
        return _quote(",".join(str(item) for item in value))
    if isinstance(value, bool):
        return "true" if value else "false"
    return _quote(str(value))


def _quote(text: str) -> str:
    """Quote a value if it contains characters that would split the line."""
    collapsed = text.replace("\n", "\\n")
    if any(character in collapsed for character in " \"="):
        escaped = collapsed.replace('"', '\\"')
        return f'"{escaped}"'
    return collapsed


def configure_logging(level: str = "INFO", stream: IO[str] | None = None) -> None:
    """Send structured logs to a stream, replacing any existing handlers.

    Logs go to stderr by default so that stdout stays clean for the run
    summary; a caller piping the summary into a file still sees the log.

    Args:
        level: Logging level name, for example ``"INFO"`` or ``"DEBUG"``.
        stream: Destination stream. Defaults to :data:`sys.stderr`.
    """
    handler = logging.StreamHandler(stream or sys.stderr)
    handler.setFormatter(KeyValueFormatter())
    root = logging.getLogger()
    for existing in list(root.handlers):
        root.removeHandler(existing)
    root.addHandler(handler)
    root.setLevel(level.upper())


def new_run_id(now: datetime | None = None) -> str:
    """Return a sortable run identifier such as ``run-20260818T090501Z``.

    Args:
        now: Timestamp to use. Defaults to the current UTC time.

    Returns:
        A run id safe to use in file names.
    """
    moment = now or datetime.now(tz=timezone.utc)
    return f"run-{moment.strftime('%Y%m%dT%H%M%SZ')}"


@dataclass
class RunReport:
    """Collects check results and writes the outputs for one run.

    Attributes:
        run_id: Identifier used in output file names and the summary.
        started_at: When the run began, in UTC.
        checks: Summaries of every check added, in order.
        sheets: Exception tables collected from the checks, in order.
        outputs: Paths written so far.
    """

    run_id: str = field(default_factory=new_run_id)
    started_at: datetime = field(default_factory=lambda: datetime.now(tz=timezone.utc))
    checks: list[dict[str, object]] = field(default_factory=list)
    sheets: dict[str, pd.DataFrame] = field(default_factory=dict, repr=False)
    outputs: list[Path] = field(default_factory=list)

    def add(self, result: CheckResult) -> None:
        """Add a check result to the run.

        Args:
            result: Any object exposing ``summary()`` and
                ``exception_frames()``, which every result dataclass in this
                package does.

        Raises:
            TypeError: If the result does not implement :class:`CheckResult`.
        """
        if not isinstance(result, CheckResult):
            raise TypeError(
                "result must provide summary() and exception_frames(); "
                f"got {type(result).__name__}"
            )
        self.checks.append(dict(result.summary()))
        for name, frame in result.exception_frames().items():
            self.sheets[self._unique_sheet_name(name)] = frame

    @property
    def exception_row_count(self) -> int:
        """Total number of exception rows across every collected table."""
        return int(sum(len(frame) for frame in self.sheets.values()))

    @property
    def passed(self) -> bool:
        """``True`` when every check reported a pass."""
        return all(bool(check.get("passed")) for check in self.checks)

    def summary(self) -> dict[str, object]:
        """Return the whole run as a JSON-serialisable mapping."""
        return {
            "run_id": self.run_id,
            "started_at": self.started_at.isoformat(timespec="seconds"),
            "checks": self.checks,
            "exception_sheets": {
                name: int(len(frame)) for name, frame in self.sheets.items()
            },
            "exception_rows": self.exception_row_count,
            "passed": self.passed,
        }

    def write_excel(self, path: str | Path) -> Path:
        """Write the summary and every exception table to one workbook.

        The first sheet is the run summary, so whoever opens the file sees
        the shape of the problem before the detail.

        Args:
            path: Destination ``.xlsx`` path. Parent directories are created.

        Returns:
            The path written.
        """
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)

        workbook = Workbook()
        summary_sheet = workbook.active
        summary_sheet.title = "run_summary"
        _write_frame(summary_sheet, self._summary_frame())

        for name, frame in self.sheets.items():
            _write_frame(workbook.create_sheet(title=name), frame)

        workbook.save(destination)
        self.outputs.append(destination)
        LOGGER.info(
            "report.excel_written",
            extra={
                "fields": {
                    "path": str(destination),
                    "sheets": len(self.sheets) + 1,
                    "exception_rows": self.exception_row_count,
                }
            },
        )
        return destination

    def write_csvs(self, directory: str | Path) -> list[Path]:
        """Write each exception table to its own CSV file.

        Args:
            directory: Destination directory, created if needed.

        Returns:
            The paths written, summary first.
        """
        target = Path(directory)
        target.mkdir(parents=True, exist_ok=True)

        written = [target / f"{self.run_id}_summary.csv"]
        self._summary_frame().to_csv(written[0], index=False)
        for name, frame in self.sheets.items():
            path = target / f"{self.run_id}_{name}.csv"
            frame.to_csv(path, index=False)
            written.append(path)

        self.outputs.extend(written)
        LOGGER.info(
            "report.csv_written",
            extra={"fields": {"directory": str(target), "files": len(written)}},
        )
        return written

    def write_json(self, path: str | Path) -> Path:
        """Write the run summary as JSON for downstream automation.

        Args:
            path: Destination ``.json`` path. Parent directories are created.

        Returns:
            The path written.
        """
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(
            json.dumps(self.summary(), indent=2, default=str) + "\n", encoding="utf-8"
        )
        self.outputs.append(destination)
        LOGGER.info("report.json_written", extra={"fields": {"path": str(destination)}})
        return destination

    def render_text(self) -> str:
        """Render a plain-text summary suitable for stdout or an email body.

        Returns:
            A multi-line string; no trailing newline.
        """
        lines = [
            f"Reconciliation run {self.run_id}",
            f"Started        : {self.started_at.isoformat(timespec='seconds')}",
            f"Overall result : {'PASS' if self.passed else 'EXCEPTIONS FOUND'}",
            "",
            "Checks",
        ]
        for check in self.checks:
            name = str(check.get("check", "check"))
            status = "pass" if check.get("passed") else "FAIL"
            detail = ", ".join(
                f"{key}={_format_value(value)}"
                for key, value in check.items()
                if key not in ("check", "passed")
            )
            lines.append(f"  [{status:>4}] {name}: {detail}")

        lines.extend(["", "Exception tables"])
        if not self.sheets:
            lines.append("  none")
        else:
            for name, frame in self.sheets.items():
                lines.append(f"  {name}: {len(frame)} row(s)")
            lines.append(f"  total exception rows: {self.exception_row_count}")

        if self.outputs:
            lines.extend(["", "Outputs"])
            lines.extend(f"  {path}" for path in self.outputs)
        return "\n".join(lines)

    def _summary_frame(self) -> pd.DataFrame:
        """Build the tabular version of the run summary."""
        rows: list[dict[str, object]] = []
        for check in self.checks:
            for key, value in check.items():
                if key == "check":
                    continue
                rows.append(
                    {
                        "run_id": self.run_id,
                        "check": check.get("check", "check"),
                        "metric": key,
                        "value": _scalar(value),
                    }
                )
        rows.append(
            {
                "run_id": self.run_id,
                "check": "run",
                "metric": "exception_rows",
                "value": self.exception_row_count,
            }
        )
        rows.append(
            {
                "run_id": self.run_id,
                "check": "run",
                "metric": "passed",
                "value": self.passed,
            }
        )
        return pd.DataFrame(rows, columns=["run_id", "check", "metric", "value"])

    def _unique_sheet_name(self, name: str) -> str:
        """Return a workbook-safe sheet name that is not already in use."""
        cleaned = _INVALID_SHEET_CHARS.sub("_", name).strip() or "sheet"
        cleaned = cleaned[:_MAX_SHEET_NAME]
        if cleaned not in self.sheets:
            return cleaned
        for suffix in range(2, 100):
            tail = f"_{suffix}"
            candidate = cleaned[: _MAX_SHEET_NAME - len(tail)] + tail
            if candidate not in self.sheets:
                return candidate
        raise ValueError(f"cannot find a unique sheet name for {name!r}")


def _write_frame(sheet: Worksheet, frame: pd.DataFrame) -> None:
    """Write a frame to a worksheet with a frozen, filtered header row."""
    columns = list(frame.columns)
    if not columns:
        sheet.cell(row=1, column=1, value="(no columns)")
        return

    for index, column in enumerate(columns, start=1):
        cell = sheet.cell(row=1, column=index, value=str(column))
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
        cell.alignment = Alignment(horizontal="left")

    for row_offset, record in enumerate(frame.itertuples(index=False), start=2):
        for column_offset, value in enumerate(record, start=1):
            sheet.cell(row=row_offset, column=column_offset, value=_scalar(value))

    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = (
        f"A1:{get_column_letter(len(columns))}{max(len(frame) + 1, 1)}"
    )
    _fit_column_widths(sheet, frame, columns)


def _fit_column_widths(
    sheet: Worksheet, frame: pd.DataFrame, columns: Iterable[str]
) -> None:
    """Set a readable width per column based on the widest sampled value."""
    sample = frame.head(200)
    for index, column in enumerate(columns, start=1):
        widest = len(str(column))
        if not sample.empty:
            values = sample[column].astype("string").fillna("")
            widest = max(widest, int(values.str.len().max() or 0))
        sheet.column_dimensions[get_column_letter(index)].width = min(
            widest + 2, _MAX_COLUMN_WIDTH
        )


def _scalar(value: Any) -> Any:
    """Convert a pandas or numpy value into something openpyxl can store."""
    if value is None:
        return None
    if isinstance(value, (str, bool, int, float)):
        return None if isinstance(value, float) and pd.isna(value) else value
    if isinstance(value, (list, tuple)):
        return ", ".join(str(item) for item in value)
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    item = getattr(value, "item", None)
    if callable(item):
        try:
            return item()
        except (AttributeError, ValueError):
            pass
    if isinstance(value, (datetime, pd.Timestamp)):
        return value.isoformat()
    return str(value)
