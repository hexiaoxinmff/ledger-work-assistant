"""Amount variance comparison with configurable tolerance.

The check answers one question: for every entity that exists on both sides,
does the amount reported by source A agree with the amount reported by
source B, within a tolerance the caller chooses?

Two things make this less trivial than ``a == b``:

* Amounts arrive as binary floating point, so ``0.1 + 0.2 != 0.3``. Sums of
  many small values drift further. Comparing raw floats produces noise
  exceptions that train people to ignore the report.
* "Close enough" is a business decision, not a technical one. A half-satang
  rounding gap is noise; a 500-unit gap is a real problem. The threshold
  belongs in configuration, and it needs to work both as an absolute amount
  and as a percentage of the value being compared.

This module handles both by rounding to a declared number of decimal places
with half-up rounding (what a finance user expects) before differencing, and
by treating the tolerance boundary as inclusive.
"""

from __future__ import annotations

import logging
import math
from collections.abc import Sequence
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal
from typing import Literal

import pandas as pd

__all__ = [
    "ToleranceMode",
    "VarianceResult",
    "compare_amounts",
    "round_half_up",
    "within_tolerance",
]

LOGGER = logging.getLogger(__name__)

ToleranceMode = Literal["absolute", "relative"]

#: Slack added to the tolerance before comparing, so that a difference which
#: is mathematically equal to the tolerance is not rejected because of the
#: last bit of a float. It is deliberately far smaller than any tolerance a
#: caller would set on money.
_BOUNDARY_EPSILON = 1e-9


def round_half_up(value: float | int | None, decimals: int = 2) -> float:
    """Round ``value`` to ``decimals`` places using half-up rounding.

    Python's built-in :func:`round` uses banker's rounding, so ``round(0.5)``
    is ``0`` and ``round(2.675, 2)`` is ``2.67``. Finance users expect
    ``1`` and ``2.68``. Converting through :class:`~decimal.Decimal` with the
    shortest repr of the float gives the expected answer.

    Args:
        value: Number to round. ``None`` and NaN are returned as NaN.
        decimals: Number of decimal places to keep. Must be >= 0.

    Returns:
        The rounded value as a float.

    Raises:
        ValueError: If ``decimals`` is negative.
    """
    if decimals < 0:
        raise ValueError("decimals must be >= 0")
    if value is None:
        return float("nan")
    number = float(value)
    if math.isnan(number) or math.isinf(number):
        return number
    quantum = Decimal(1).scaleb(-decimals)
    return float(Decimal(repr(number)).quantize(quantum, rounding=ROUND_HALF_UP))


def within_tolerance(
    left: float,
    right: float,
    tolerance: float,
    mode: ToleranceMode = "absolute",
) -> bool:
    """Return ``True`` when two amounts agree within ``tolerance``.

    In ``"absolute"`` mode the raw difference is compared against the
    tolerance. In ``"relative"`` mode the difference is divided by the
    magnitude of the left-hand amount (falling back to the right-hand amount
    when the left is zero) and compared against the tolerance expressed as a
    fraction, so ``0.01`` means one percent.

    The boundary is inclusive: a difference exactly equal to the tolerance
    passes.

    Args:
        left: Amount from the first source.
        right: Amount from the second source.
        tolerance: Threshold, absolute or fractional depending on ``mode``.
        mode: ``"absolute"`` or ``"relative"``.

    Returns:
        ``True`` if the pair is within tolerance, ``False`` otherwise. A NaN
        on either side is never within tolerance.

    Raises:
        ValueError: If ``tolerance`` is negative or ``mode`` is unknown.
    """
    if tolerance < 0:
        raise ValueError("tolerance must be >= 0")
    if mode not in ("absolute", "relative"):
        raise ValueError(f"unknown tolerance mode: {mode!r}")
    if math.isnan(left) or math.isnan(right):
        return False

    difference = abs(left - right)
    if mode == "absolute":
        return difference <= tolerance + _BOUNDARY_EPSILON

    base = abs(left) if left != 0 else abs(right)
    if base == 0:
        # Both sides are zero, so they agree regardless of the tolerance.
        return difference == 0
    return (difference / base) <= tolerance + _BOUNDARY_EPSILON


@dataclass(frozen=True)
class VarianceResult:
    """Outcome of comparing one amount column between two sources.

    Attributes:
        key_columns: Columns identifying the entity being compared.
        tolerance: Tolerance that was applied.
        tolerance_mode: ``"absolute"`` or ``"relative"``.
        decimals: Decimal places both sides were rounded to before comparison.
        comparison: One row per entity present on both sides, with the two
            amounts, the signed difference, the relative difference and a
            ``within_tolerance`` flag.
        left_name: Label used for the first source in column names and logs.
        right_name: Label used for the second source.
    """

    key_columns: tuple[str, ...]
    tolerance: float
    tolerance_mode: ToleranceMode
    decimals: int
    comparison: pd.DataFrame = field(repr=False)
    left_name: str = "left"
    right_name: str = "right"

    @property
    def compared_count(self) -> int:
        """Number of entities that were compared."""
        return int(len(self.comparison))

    @property
    def breach_count(self) -> int:
        """Number of entities whose difference exceeded the tolerance."""
        if self.comparison.empty:
            return 0
        return int((~self.comparison["within_tolerance"]).sum())

    @property
    def passed(self) -> bool:
        """``True`` when every compared entity is within tolerance."""
        return self.breach_count == 0

    @property
    def total_absolute_variance(self) -> float:
        """Sum of the absolute differences across all compared entities."""
        if self.comparison.empty:
            return 0.0
        return float(self.comparison["difference"].abs().sum())

    def breaches(self) -> pd.DataFrame:
        """Return only the rows that exceeded the tolerance.

        Returns:
            A copy of the comparison frame filtered to breaching entities,
            sorted by absolute difference descending so the worst offenders
            are at the top of the exception report.
        """
        if self.comparison.empty:
            return self.comparison.copy()
        breaching = self.comparison.loc[~self.comparison["within_tolerance"]].copy()
        if breaching.empty:
            return breaching
        breaching["_abs"] = breaching["difference"].abs()
        breaching = breaching.sort_values("_abs", ascending=False).drop(columns="_abs")
        return breaching.reset_index(drop=True)

    def exception_frames(self) -> dict[str, pd.DataFrame]:
        """Return the non-empty exception frames, keyed by report sheet name."""
        breaches = self.breaches()
        return {} if breaches.empty else {"variance_breaches": breaches}

    def summary(self) -> dict[str, object]:
        """Return a flat, log-friendly and JSON-friendly summary."""
        return {
            "check": "variance",
            "key_columns": list(self.key_columns),
            "tolerance": self.tolerance,
            "tolerance_mode": self.tolerance_mode,
            "decimals": self.decimals,
            "compared": self.compared_count,
            "breaches": self.breach_count,
            "total_absolute_variance": round_half_up(
                self.total_absolute_variance, self.decimals
            ),
            "passed": self.passed,
        }


def compare_amounts(
    left: pd.DataFrame,
    right: pd.DataFrame,
    key_columns: Sequence[str],
    left_amount_column: str,
    right_amount_column: str | None = None,
    *,
    tolerance: float = 0.01,
    tolerance_mode: ToleranceMode = "absolute",
    decimals: int = 2,
    aggregate: bool = True,
    left_name: str = "left",
    right_name: str = "right",
) -> VarianceResult:
    """Compare an amount per entity between two datasets.

    Both sides are optionally aggregated to one row per key, rounded to
    ``decimals`` places, and differenced. Entities missing from either side
    are *not* reported here -- that is what
    :func:`reconciliation.key_match.match_on_composite_key` is for, and
    mixing the two makes both reports harder to read.

    Args:
        left: First dataset, treated as the reference for relative tolerance.
        right: Second dataset.
        key_columns: Columns identifying an entity. Must exist on both sides.
        left_amount_column: Numeric column to compare on the left.
        right_amount_column: Numeric column on the right. Defaults to
            ``left_amount_column``.
        tolerance: Threshold; absolute amount or fraction, see
            ``tolerance_mode``.
        tolerance_mode: ``"absolute"`` or ``"relative"``.
        decimals: Decimal places to round both sides to before differencing.
        aggregate: When ``True`` (default) each side is summed by key. Set to
            ``False`` when the inputs already hold one row per key; duplicate
            keys then raise instead of being silently combined.
        left_name: Label for the first source, used in output column names.
        right_name: Label for the second source.

    Returns:
        A :class:`VarianceResult`.

    Raises:
        KeyError: If a key or amount column is missing from either frame.
        ValueError: If ``aggregate`` is ``False`` and a key is duplicated, or
            if the tolerance or decimals arguments are invalid.
    """
    keys = tuple(key_columns)
    if not keys:
        raise ValueError("key_columns must not be empty")
    right_amount_column = right_amount_column or left_amount_column
    _require_columns(left, [*keys, left_amount_column], side=left_name)
    _require_columns(right, [*keys, right_amount_column], side=right_name)
    if tolerance < 0:
        raise ValueError("tolerance must be >= 0")
    if tolerance_mode not in ("absolute", "relative"):
        raise ValueError(f"unknown tolerance mode: {tolerance_mode!r}")

    left_amounts = _prepare_side(
        left, keys, left_amount_column, aggregate, decimals, left_name
    )
    right_amounts = _prepare_side(
        right, keys, right_amount_column, aggregate, decimals, right_name
    )

    left_column = f"{left_name}_amount"
    right_column = f"{right_name}_amount"
    left_amounts = left_amounts.rename(columns={"_amount": left_column})
    right_amounts = right_amounts.rename(columns={"_amount": right_column})

    comparison = left_amounts.merge(right_amounts, on=list(keys), how="inner")
    comparison = _add_difference_columns(
        comparison, left_column, right_column, tolerance, tolerance_mode, decimals
    )

    result = VarianceResult(
        key_columns=keys,
        tolerance=tolerance,
        tolerance_mode=tolerance_mode,
        decimals=decimals,
        comparison=comparison,
        left_name=left_name,
        right_name=right_name,
    )
    LOGGER.info("variance.compared", extra={"fields": result.summary()})
    return result


def _add_difference_columns(
    comparison: pd.DataFrame,
    left_column: str,
    right_column: str,
    tolerance: float,
    tolerance_mode: ToleranceMode,
    decimals: int,
) -> pd.DataFrame:
    """Attach difference, relative difference and tolerance flag columns."""
    if comparison.empty:
        for column in ("difference", "relative_difference"):
            comparison[column] = pd.Series(dtype="float64")
        comparison["within_tolerance"] = pd.Series(dtype="bool")
        return comparison

    left_values = comparison[left_column].astype("float64")
    right_values = comparison[right_column].astype("float64")
    difference = (left_values - right_values).map(
        lambda value: round_half_up(value, decimals)
    )
    comparison["difference"] = difference

    base = left_values.abs().where(left_values != 0, right_values.abs())
    relative = difference.abs().div(base).where(base != 0, 0.0)
    comparison["relative_difference"] = relative.map(
        lambda value: round_half_up(value, decimals + 4)
    )

    comparison["within_tolerance"] = [
        within_tolerance(left_value, right_value, tolerance, tolerance_mode)
        for left_value, right_value in zip(left_values, right_values, strict=True)
    ]
    return comparison


def _prepare_side(
    frame: pd.DataFrame,
    keys: tuple[str, ...],
    amount_column: str,
    aggregate: bool,
    decimals: int,
    side: str,
) -> pd.DataFrame:
    """Reduce one input to a key plus a single rounded ``_amount`` column.

    A value that cannot be parsed as a number becomes NaN, and any key whose
    rows contain one is left as NaN rather than being summed around. NaN
    never satisfies a tolerance, so a corrupt amount surfaces as an exception
    instead of quietly reading as zero.
    """
    working = frame.loc[:, [*keys, amount_column]].copy()
    working["_amount"] = pd.to_numeric(working[amount_column], errors="coerce")
    working = working.drop(columns=[c for c in [amount_column] if c != "_amount"])
    working["_unparsable"] = working["_amount"].isna()

    if aggregate:
        working = working.groupby(list(keys), dropna=False, as_index=False).agg(
            _amount=("_amount", "sum"), _unparsable=("_unparsable", "max")
        )
    else:
        duplicated = working.duplicated(subset=list(keys), keep=False)
        if bool(duplicated.any()):
            raise ValueError(
                f"{side} contains {int(duplicated.sum())} rows with duplicate keys "
                "but aggregate=False was requested"
            )

    working["_amount"] = working["_amount"].mask(
        working["_unparsable"].astype("bool"), other=float("nan")
    )
    working["_amount"] = working["_amount"].map(
        lambda value: round_half_up(value, decimals)
    )
    return working.drop(columns="_unparsable")


def _require_columns(frame: pd.DataFrame, columns: Sequence[str], side: str) -> None:
    """Raise :class:`KeyError` listing every column missing from ``frame``."""
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise KeyError(f"{side} frame is missing columns: {missing}")
