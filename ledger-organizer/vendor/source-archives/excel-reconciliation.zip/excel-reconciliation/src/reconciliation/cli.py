"""Command line interface: ``python -m reconciliation <command>``.

Four commands. Three run a single check, the fourth runs a whole
configuration in one go:

* ``control-totals`` -- concatenate chunks and compare against declared totals
* ``key-match``      -- classify rows across a composite-key join
* ``variance``       -- compare amounts per entity within a tolerance
* ``run``            -- run all configured checks from a JSON config file

Every command writes an exception report and prints a summary. The process
exits 0 even when exceptions are found, unless ``--fail-on-exceptions`` is
given; see the Design notes in the README.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from collections.abc import Mapping, Sequence
from pathlib import Path

import pandas as pd

from .control_totals import DeclaredTotals, check_control_totals, load_chunks
from .key_match import match_on_composite_key
from .report import RunReport, configure_logging, new_run_id
from .variance import compare_amounts

__all__ = ["build_parser", "main"]

LOGGER = logging.getLogger(__name__)

EXIT_OK = 0
EXIT_USAGE = 1
EXIT_EXCEPTIONS = 2

#: Value a ``run`` config can use for a dataset path to mean "the frame the
#: control totals step assembled from its chunks".
COMBINED_CHUNKS = "@control_totals"


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser for every command.

    Returns:
        A configured :class:`argparse.ArgumentParser`.
    """
    parser = argparse.ArgumentParser(
        prog="python -m reconciliation",
        description=(
            "Reconciliation checks for tabular data: control totals, "
            "composite-key matching and amount variance."
        ),
    )
    parser.add_argument(
        "--log-level",
        default=os.environ.get("RECON_LOG_LEVEL", "INFO"),
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help=(
            "verbosity of the structured log written to stderr "
            "(default: $RECON_LOG_LEVEL, or INFO)"
        ),
    )
    subcommands = parser.add_subparsers(dest="command", required=True)

    control = subcommands.add_parser(
        "control-totals",
        help="check merged row count and column sums against declared totals",
    )
    control.add_argument(
        "--chunk",
        action="append",
        default=[],
        metavar="PATH",
        help="chunk CSV to include; repeat for each chunk",
    )
    control.add_argument(
        "--chunk-glob",
        metavar="PATTERN",
        help="glob for chunk CSVs, for example 'sample_data/ledger_chunk_*.csv'",
    )
    control.add_argument(
        "--declared",
        required=True,
        metavar="PATH",
        help="JSON file with row_count, column_sums and the declared chunk names",
    )
    control.add_argument(
        "--amount-tolerance",
        type=float,
        default=0.01,
        help="absolute tolerance on each declared column sum (default: 0.01)",
    )
    _add_output_arguments(control)

    match = subcommands.add_parser(
        "key-match", help="classify rows as matched, left-only or right-only"
    )
    match.add_argument("--left", required=True, metavar="PATH", help="left CSV")
    match.add_argument("--right", required=True, metavar="PATH", help="right CSV")
    match.add_argument(
        "--key",
        action="append",
        required=True,
        metavar="COLUMN",
        help="composite key column; repeat for each component",
    )
    match.add_argument("--left-name", default="left", help="label for the left dataset")
    match.add_argument(
        "--right-name", default="right", help="label for the right dataset"
    )
    _add_output_arguments(match)

    variance = subcommands.add_parser(
        "variance", help="compare an amount per entity within a tolerance"
    )
    variance.add_argument("--left", required=True, metavar="PATH", help="left CSV")
    variance.add_argument("--right", required=True, metavar="PATH", help="right CSV")
    variance.add_argument(
        "--key",
        action="append",
        required=True,
        metavar="COLUMN",
        help="entity key column; repeat for each component",
    )
    variance.add_argument(
        "--left-amount", required=True, help="numeric column to compare on the left"
    )
    variance.add_argument(
        "--right-amount", help="numeric column on the right (default: same as left)"
    )
    variance.add_argument(
        "--tolerance",
        type=float,
        default=0.01,
        help="absolute amount, or fraction when --tolerance-mode relative",
    )
    variance.add_argument(
        "--tolerance-mode",
        choices=["absolute", "relative"],
        default="absolute",
        help="how --tolerance is interpreted (default: absolute)",
    )
    variance.add_argument(
        "--decimals",
        type=int,
        default=2,
        help="decimal places both sides are rounded to before comparison",
    )
    variance.add_argument("--left-name", default="left", help="label for the left side")
    variance.add_argument(
        "--right-name", default="right", help="label for the right side"
    )
    _add_output_arguments(variance)

    run = subcommands.add_parser(
        "run", help="run every check described by a JSON config file"
    )
    run.add_argument(
        "--config", required=True, metavar="PATH", help="JSON configuration file"
    )
    _add_output_arguments(run)

    return parser


def _add_output_arguments(parser: argparse.ArgumentParser) -> None:
    """Add the output options shared by every command."""
    parser.add_argument(
        "--output-dir",
        default=os.environ.get("RECON_OUTPUT_DIR", "output"),
        metavar="DIR",
        help=(
            "directory for the exception report and run summary "
            "(default: $RECON_OUTPUT_DIR, or 'output')"
        ),
    )
    parser.add_argument(
        "--format",
        dest="output_format",
        choices=["xlsx", "csv", "both"],
        default="xlsx",
        help="exception report format (default: xlsx)",
    )
    parser.add_argument(
        "--fail-on-exceptions",
        action="store_true",
        help=f"exit {EXIT_EXCEPTIONS} when any check reports exceptions",
    )


def main(argv: Sequence[str] | None = None) -> int:
    """Run the CLI.

    Args:
        argv: Argument list, defaulting to :data:`sys.argv`.

    Returns:
        A process exit code: 0 on success, 1 on a usage or input error,
        2 when exceptions were found and ``--fail-on-exceptions`` was given.
    """
    args = build_parser().parse_args(argv)
    configure_logging(args.log_level)

    report = RunReport(run_id=new_run_id())
    LOGGER.info(
        "run.started",
        extra={"fields": {"run_id": report.run_id, "command": args.command}},
    )

    try:
        if args.command == "control-totals":
            _command_control_totals(args, report)
        elif args.command == "key-match":
            _command_key_match(args, report)
        elif args.command == "variance":
            _command_variance(args, report)
        elif args.command == "run":
            _command_run(args, report)
        else:  # pragma: no cover - argparse rejects unknown commands
            raise ValueError(f"unknown command: {args.command}")
    except (FileNotFoundError, KeyError, ValueError) as error:
        LOGGER.error(
            "run.failed",
            extra={"fields": {"run_id": report.run_id, "error": str(error)}},
        )
        print(f"error: {error}", file=sys.stderr)
        return EXIT_USAGE

    _write_outputs(report, Path(args.output_dir), args.output_format)
    print(report.render_text())
    LOGGER.info(
        "run.finished",
        extra={
            "fields": {
                "run_id": report.run_id,
                "passed": report.passed,
                "exception_rows": report.exception_row_count,
            }
        },
    )

    if args.fail_on_exceptions and not report.passed:
        return EXIT_EXCEPTIONS
    return EXIT_OK


def _command_control_totals(args: argparse.Namespace, report: RunReport) -> None:
    """Run the control totals check from command line arguments."""
    paths = _resolve_chunk_paths(args.chunk, args.chunk_glob)
    declared = DeclaredTotals.from_json(args.declared)
    loaded = load_chunks(paths, declared_chunks=declared.chunks)
    report.add(
        check_control_totals(
            loaded.frame,
            declared,
            amount_tolerance=args.amount_tolerance,
            chunks_missing=loaded.chunks_missing,
            rows_per_chunk=loaded.rows_per_chunk,
        )
    )


def _command_key_match(args: argparse.Namespace, report: RunReport) -> None:
    """Run the composite-key match from command line arguments."""
    report.add(
        match_on_composite_key(
            _read_csv(args.left),
            _read_csv(args.right),
            args.key,
            left_name=args.left_name,
            right_name=args.right_name,
        )
    )


def _command_variance(args: argparse.Namespace, report: RunReport) -> None:
    """Run the variance check from command line arguments."""
    report.add(
        compare_amounts(
            _read_csv(args.left),
            _read_csv(args.right),
            args.key,
            args.left_amount,
            args.right_amount,
            tolerance=args.tolerance,
            tolerance_mode=args.tolerance_mode,
            decimals=args.decimals,
            left_name=args.left_name,
            right_name=args.right_name,
        )
    )


def _command_run(args: argparse.Namespace, report: RunReport) -> None:
    """Run every check described by a JSON config file.

    Paths inside the config are resolved relative to the config file, so a
    config can be moved around with its data.
    """
    config_path = Path(args.config)
    if not config_path.exists():
        raise FileNotFoundError(f"config file not found: {config_path}")
    config = json.loads(config_path.read_text(encoding="utf-8"))
    if not isinstance(config, Mapping):
        raise ValueError("config file must contain a JSON object")
    base = config_path.parent

    combined: pd.DataFrame | None = None

    control_config = config.get("control_totals")
    if control_config:
        declared = DeclaredTotals.from_json(base / str(control_config["declared"]))
        paths = _resolve_chunk_paths(
            [base / str(chunk) for chunk in control_config.get("chunks", [])],
            str(base / control_config["chunk_glob"])
            if control_config.get("chunk_glob")
            else None,
        )
        loaded = load_chunks(paths, declared_chunks=declared.chunks)
        combined = loaded.frame
        report.add(
            check_control_totals(
                loaded.frame,
                declared,
                amount_tolerance=float(control_config.get("amount_tolerance", 0.01)),
                chunks_missing=loaded.chunks_missing,
                rows_per_chunk=loaded.rows_per_chunk,
            )
        )

    match_config = config.get("key_match")
    if match_config:
        report.add(
            match_on_composite_key(
                _dataset(match_config["left"], base, combined),
                _dataset(match_config["right"], base, combined),
                match_config["keys"],
                left_name=str(match_config.get("left_name", "left")),
                right_name=str(match_config.get("right_name", "right")),
            )
        )

    variance_config = config.get("variance")
    if variance_config:
        report.add(
            compare_amounts(
                _dataset(variance_config["left"], base, combined),
                _dataset(variance_config["right"], base, combined),
                variance_config["keys"],
                str(variance_config["left_amount"]),
                variance_config.get("right_amount"),
                tolerance=float(variance_config.get("tolerance", 0.01)),
                tolerance_mode=str(variance_config.get("tolerance_mode", "absolute")),
                decimals=int(variance_config.get("decimals", 2)),
                left_name=str(variance_config.get("left_name", "left")),
                right_name=str(variance_config.get("right_name", "right")),
            )
        )

    if not report.checks:
        raise ValueError(
            "config contained no checks; expected at least one of "
            "'control_totals', 'key_match', 'variance'"
        )


def _dataset(
    reference: str, base: Path, combined: pd.DataFrame | None
) -> pd.DataFrame:
    """Resolve a config dataset reference to a frame.

    Args:
        reference: Either a path relative to the config file, or the literal
            :data:`COMBINED_CHUNKS` to reuse the concatenated chunk frame.
        base: Directory the config file lives in.
        combined: Frame assembled by the control totals step, if it ran.

    Returns:
        The requested frame.

    Raises:
        ValueError: If the config asks for the combined frame but the control
            totals step did not run.
    """
    if reference == COMBINED_CHUNKS:
        if combined is None:
            raise ValueError(
                f"'{COMBINED_CHUNKS}' requires a 'control_totals' section in the config"
            )
        return combined
    return _read_csv(base / str(reference))


def _resolve_chunk_paths(
    chunks: Sequence[str | Path], chunk_glob: str | None
) -> list[Path]:
    """Collect chunk paths from explicit arguments and an optional glob.

    Args:
        chunks: Explicit chunk paths, kept in the order given.
        chunk_glob: Optional glob pattern; matches are sorted by name so the
            concatenation order is stable between runs.

    Returns:
        Chunk paths, de-duplicated, explicit ones first.

    Raises:
        ValueError: If no chunk was supplied at all.
    """
    paths: list[Path] = [Path(chunk) for chunk in chunks]
    if chunk_glob:
        pattern = Path(chunk_glob)
        root = pattern.parent if str(pattern.parent) else Path(".")
        paths.extend(sorted(root.glob(pattern.name)))
    if not paths:
        raise ValueError("no chunks supplied; use --chunk and/or --chunk-glob")

    unique: list[Path] = []
    seen: set[Path] = set()
    for path in paths:
        resolved = path.resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique.append(path)
    return unique


def _read_csv(path: str | Path) -> pd.DataFrame:
    """Read a CSV, failing with a clear message when it is not there."""
    target = Path(path)
    if not target.exists():
        raise FileNotFoundError(f"input file not found: {target}")
    frame = pd.read_csv(target)
    LOGGER.info(
        "input.loaded",
        extra={
            "fields": {
                "path": str(target),
                "rows": len(frame),
                "columns": len(frame.columns),
            }
        },
    )
    return frame


def _write_outputs(report: RunReport, output_dir: Path, output_format: str) -> None:
    """Write the exception report and JSON summary in the chosen format(s)."""
    if output_format in ("xlsx", "both"):
        report.write_excel(output_dir / f"{report.run_id}_exceptions.xlsx")
    if output_format in ("csv", "both"):
        report.write_csvs(output_dir)
    report.write_json(output_dir / f"{report.run_id}_summary.json")
