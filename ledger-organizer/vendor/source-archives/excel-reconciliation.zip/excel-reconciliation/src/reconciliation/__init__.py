"""Reconciliation checks for tabular data before it reaches a business user.

Three checks, each usable on its own:

* :mod:`reconciliation.control_totals` -- did every chunk of a multi-part
  extract arrive, and do the merged row count and column sums match what the
  source declared?
* :mod:`reconciliation.key_match` -- which rows exist on both sides of a
  composite-key join, and which exist on only one?
* :mod:`reconciliation.variance` -- do the amounts agree per entity, within a
  tolerance the caller sets?

Failures are collected into an exception report by
:mod:`reconciliation.report` rather than raising. See the README for why.
"""

from __future__ import annotations

from .control_totals import (
    ChunkLoadResult,
    ColumnTotalCheck,
    ControlTotalResult,
    DeclaredTotals,
    check_control_totals,
    combine_chunks,
    load_chunks,
)
from .key_match import MatchResult, match_on_composite_key
from .report import (
    CheckResult,
    KeyValueFormatter,
    RunReport,
    configure_logging,
    new_run_id,
)
from .variance import (
    ToleranceMode,
    VarianceResult,
    compare_amounts,
    round_half_up,
    within_tolerance,
)

__version__ = "0.1.0"

__all__ = [
    "CheckResult",
    "ChunkLoadResult",
    "ColumnTotalCheck",
    "ControlTotalResult",
    "DeclaredTotals",
    "KeyValueFormatter",
    "MatchResult",
    "RunReport",
    "ToleranceMode",
    "VarianceResult",
    "__version__",
    "check_control_totals",
    "combine_chunks",
    "compare_amounts",
    "configure_logging",
    "load_chunks",
    "match_on_composite_key",
    "new_run_id",
    "round_half_up",
    "within_tolerance",
]
