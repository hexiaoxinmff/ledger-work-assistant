"""Control totals for extracts that arrive in several chunks.

Many reporting sources cap how much a single export can return: a date
range, a row limit, a timeout. The practical result is that one logical
dataset arrives as several partial files, and the person assembling them has
to trust that every part turned up and that nothing was dropped on the way.

A control total is the cheap defence. The source states, up front, how many
rows and what column sums the full extract should contain. After the chunks
are concatenated, the assembled frame is measured against that statement.
If a chunk failed silently, or an export stopped halfway through, the row
count or the sums will not line up and the run says so before anyone builds
a report on top of it.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from .variance import round_half_up, within_tolerance

__all__ = [
    "ChunkLoadResult",
    "ColumnTotalCheck",
    "ControlTotalResult",
    "DeclaredTotals",
    "check_control_totals",
    "combine_chunks",
    "load_chunks",
]

LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class DeclaredTotals:
    """What the source system says the complete extract contains.

    Attributes:
        row_count: Expected number of rows once every chunk is concatenated.
        column_sums: Expected sum per numeric column, keyed by column name.
        chunks: Names of the chunk files the source says it produced. Used to
            detect a chunk that never arrived at all.
        label: Free-text label for the dataset, used in logs and reports.
    """

    row_count: int
    column_sums: Mapping[str, float] = field(default_factory=dict)
    chunks: tuple[str, ...] = ()
    label: str = "dataset"

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> DeclaredTotals:
        """Build declared totals from a plain mapping.

        Args:
            payload: Mapping with ``row_count`` and optionally
                ``column_sums``, ``chunks`` and ``label``.

        Returns:
            A :class:`DeclaredTotals`.

        Raises:
            KeyError: If ``row_count`` is absent.
            ValueError: If ``row_count`` is not a non-negative integer.
        """
        if "row_count" not in payload:
            raise KeyError("declared totals must contain 'row_count'")
        row_count = int(payload["row_count"])  # type: ignore[arg-type]
        if row_count < 0:
            raise ValueError("row_count must be >= 0")
        raw_sums = payload.get("column_sums") or {}
        if not isinstance(raw_sums, Mapping):
            raise ValueError("column_sums must be a mapping of column -> number")
        column_sums = {str(key): float(value) for key, value in raw_sums.items()}
        raw_chunks = payload.get("chunks") or ()
        chunks = tuple(str(chunk) for chunk in raw_chunks)  # type: ignore[union-attr]
        return cls(
            row_count=row_count,
            column_sums=column_sums,
            chunks=chunks,
            label=str(payload.get("label", "dataset")),
        )

    @classmethod
    def from_json(cls, path: str | Path) -> DeclaredTotals:
        """Load declared totals from a JSON file.

        Args:
            path: Path to a JSON document in the shape accepted by
                :meth:`from_dict`.

        Returns:
            A :class:`DeclaredTotals`.
        """
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(payload)


@dataclass(frozen=True)
class ChunkLoadResult:
    """The concatenated frame plus what was found on the way.

    Attributes:
        frame: All chunks concatenated in the order they were supplied.
        rows_per_chunk: Row count per chunk name, in load order.
        chunks_missing: Declared chunk names that were not supplied.
    """

    frame: pd.DataFrame = field(repr=False)
    rows_per_chunk: Mapping[str, int] = field(default_factory=dict)
    chunks_missing: tuple[str, ...] = ()

    @property
    def row_count(self) -> int:
        """Total rows across all loaded chunks."""
        return int(len(self.frame))


@dataclass(frozen=True)
class ColumnTotalCheck:
    """Comparison of one column sum against its declared value.

    Attributes:
        column: Column that was summed.
        expected: Sum declared by the source.
        actual: Sum measured on the assembled frame.
        difference: ``actual - expected``, rounded.
        tolerance: Absolute tolerance applied to the comparison.
        passed: Whether the difference is within tolerance.
    """

    column: str
    expected: float
    actual: float
    difference: float
    tolerance: float
    passed: bool


@dataclass(frozen=True)
class ControlTotalResult:
    """Outcome of a control total check.

    Attributes:
        label: Dataset label taken from the declared totals.
        expected_rows: Declared row count.
        actual_rows: Row count of the assembled frame.
        column_checks: One :class:`ColumnTotalCheck` per declared column sum.
        chunks_missing: Declared chunk names that were never loaded.
        rows_per_chunk: Row count per loaded chunk, for the exception report.
    """

    label: str
    expected_rows: int
    actual_rows: int
    column_checks: tuple[ColumnTotalCheck, ...] = ()
    chunks_missing: tuple[str, ...] = ()
    rows_per_chunk: Mapping[str, int] = field(default_factory=dict)

    @property
    def row_difference(self) -> int:
        """``actual_rows - expected_rows``. Negative means rows were lost."""
        return self.actual_rows - self.expected_rows

    @property
    def row_count_passed(self) -> bool:
        """``True`` when the assembled row count matches the declaration."""
        return self.row_difference == 0

    @property
    def passed(self) -> bool:
        """``True`` only when rows, chunks and every column sum agree."""
        return (
            self.row_count_passed
            and not self.chunks_missing
            and all(check.passed for check in self.column_checks)
        )

    @property
    def failure_count(self) -> int:
        """Number of individual failures, one per exception report row."""
        failures = 0 if self.row_count_passed else 1
        failures += len(self.chunks_missing)
        failures += sum(1 for check in self.column_checks if not check.passed)
        return failures

    def exceptions(self) -> pd.DataFrame:
        """Return one row per failed control, ready for the exception report.

        Returns:
            A frame with ``check``, ``subject``, ``expected``, ``actual``,
            ``difference`` and ``detail`` columns. Empty when the check
            passed.
        """
        rows: list[dict[str, object]] = []
        for chunk in self.chunks_missing:
            rows.append(
                {
                    "check": "chunk_missing",
                    "subject": chunk,
                    "expected": "present",
                    "actual": "absent",
                    "difference": "",
                    "detail": "declared chunk was not supplied to the run",
                }
            )
        if not self.row_count_passed:
            rows.append(
                {
                    "check": "row_count",
                    "subject": self.label,
                    "expected": self.expected_rows,
                    "actual": self.actual_rows,
                    "difference": self.row_difference,
                    "detail": (
                        "fewer rows than declared"
                        if self.row_difference < 0
                        else "more rows than declared"
                    ),
                }
            )
        for check in self.column_checks:
            if check.passed:
                continue
            rows.append(
                {
                    "check": "column_sum",
                    "subject": check.column,
                    "expected": check.expected,
                    "actual": check.actual,
                    "difference": check.difference,
                    "detail": f"outside absolute tolerance {check.tolerance}",
                }
            )
        return pd.DataFrame(
            rows,
            columns=["check", "subject", "expected", "actual", "difference", "detail"],
        )

    def chunk_breakdown(self) -> pd.DataFrame:
        """Return rows loaded per chunk, including missing chunks as zero.

        Returns:
            A frame with ``chunk``, ``rows`` and ``status`` columns. Useful
            in the exception workbook because the chunk with the odd row
            count is usually the one that failed.
        """
        rows = [
            {"chunk": name, "rows": count, "status": "loaded"}
            for name, count in self.rows_per_chunk.items()
        ]
        rows.extend(
            {"chunk": name, "rows": 0, "status": "missing"}
            for name in self.chunks_missing
        )
        return pd.DataFrame(rows, columns=["chunk", "rows", "status"])

    def exception_frames(self) -> dict[str, pd.DataFrame]:
        """Return the non-empty exception frames, keyed by report sheet name.

        The per-chunk breakdown is included only when something failed: when
        the totals agree nobody needs it, and when they do not it is usually
        the fastest way to see which chunk came back short.
        """
        if self.passed:
            return {}
        return {
            "control_total_failures": self.exceptions(),
            "control_total_chunks": self.chunk_breakdown(),
        }

    def summary(self) -> dict[str, object]:
        """Return a flat, log-friendly and JSON-friendly summary."""
        return {
            "check": "control_totals",
            "label": self.label,
            "expected_rows": self.expected_rows,
            "actual_rows": self.actual_rows,
            "row_difference": self.row_difference,
            "chunks_loaded": len(self.rows_per_chunk),
            "chunks_missing": len(self.chunks_missing),
            "column_checks": len(self.column_checks),
            "column_failures": sum(
                1 for check in self.column_checks if not check.passed
            ),
            "failures": self.failure_count,
            "passed": self.passed,
        }


def load_chunks(
    paths: Sequence[str | Path],
    *,
    declared_chunks: Sequence[str] = (),
    read_options: Mapping[str, object] | None = None,
) -> ChunkLoadResult:
    """Read CSV chunks from disk and concatenate them.

    Only files that exist are read. A declared chunk whose file is absent is
    reported through :attr:`ChunkLoadResult.chunks_missing` rather than
    raising, because "the export never produced part 4" is exactly the
    failure this module exists to surface.

    Args:
        paths: Chunk file paths, in the order they should be concatenated.
        declared_chunks: File names the source says it produced. Matching is
            done on the file name, not the full path.
        read_options: Extra keyword arguments passed to :func:`pandas.read_csv`.

    Returns:
        A :class:`ChunkLoadResult`.

    Raises:
        ValueError: If two chunks do not share the same columns.
    """
    options = dict(read_options or {})
    frames: list[pd.DataFrame] = []
    rows_per_chunk: dict[str, int] = {}
    seen_names: set[str] = set()

    for raw_path in paths:
        path = Path(raw_path)
        if not path.exists():
            LOGGER.warning("chunk.absent", extra={"fields": {"path": str(path)}})
            continue
        frame = pd.read_csv(path, **options)
        frames.append(frame)
        rows_per_chunk[path.name] = int(len(frame))
        seen_names.add(path.name)
        LOGGER.info(
            "chunk.loaded",
            extra={"fields": {"chunk": path.name, "rows": len(frame)}},
        )

    missing = tuple(name for name in declared_chunks if name not in seen_names)
    if missing:
        LOGGER.warning("chunk.missing", extra={"fields": {"chunks": list(missing)}})

    combined = combine_chunks(frames)
    return ChunkLoadResult(
        frame=combined, rows_per_chunk=rows_per_chunk, chunks_missing=missing
    )


def combine_chunks(frames: Iterable[pd.DataFrame]) -> pd.DataFrame:
    """Concatenate chunk frames after checking they share a schema.

    Args:
        frames: Frames to concatenate, in order.

    Returns:
        A single frame with a fresh integer index. An empty input produces an
        empty frame.

    Raises:
        ValueError: If the frames do not all have the same set of columns.
        Concatenating mismatched chunks would produce NaN-filled columns that
        quietly pass a row count check while corrupting every downstream sum.
    """
    frame_list = list(frames)
    if not frame_list:
        return pd.DataFrame()

    reference = list(frame_list[0].columns)
    for index, frame in enumerate(frame_list[1:], start=1):
        if list(frame.columns) != reference:
            raise ValueError(
                "chunk schemas differ: "
                f"chunk 0 has {reference}, chunk {index} has {list(frame.columns)}"
            )
    return pd.concat(frame_list, ignore_index=True)


def check_control_totals(
    frame: pd.DataFrame,
    declared: DeclaredTotals,
    *,
    amount_tolerance: float = 0.01,
    decimals: int = 2,
    chunks_missing: Sequence[str] = (),
    rows_per_chunk: Mapping[str, int] | None = None,
) -> ControlTotalResult:
    """Measure an assembled frame against the totals the source declared.

    Args:
        frame: The concatenated dataset.
        declared: What the source says the complete extract contains.
        amount_tolerance: Absolute tolerance applied to each column sum, to
            absorb float accumulation over large row counts.
        decimals: Decimal places used when rounding sums for comparison.
        chunks_missing: Chunk names known to be absent, normally taken from
            :attr:`ChunkLoadResult.chunks_missing`.
        rows_per_chunk: Rows loaded per chunk, carried into the report.

    Returns:
        A :class:`ControlTotalResult`.

    Raises:
        KeyError: If a declared column sum names a column that is not in the
            frame. A typo in configuration must not read as a passing check.
    """
    missing_columns = [
        column for column in declared.column_sums if column not in frame.columns
    ]
    if missing_columns:
        raise KeyError(
            f"declared column sums reference missing columns: {missing_columns}"
        )

    checks: list[ColumnTotalCheck] = []
    for column, expected in declared.column_sums.items():
        actual = float(pd.to_numeric(frame[column], errors="coerce").sum())
        actual_rounded = round_half_up(actual, decimals)
        expected_rounded = round_half_up(float(expected), decimals)
        checks.append(
            ColumnTotalCheck(
                column=column,
                expected=expected_rounded,
                actual=actual_rounded,
                difference=round_half_up(actual_rounded - expected_rounded, decimals),
                tolerance=amount_tolerance,
                passed=within_tolerance(
                    expected_rounded, actual_rounded, amount_tolerance, "absolute"
                ),
            )
        )

    result = ControlTotalResult(
        label=declared.label,
        expected_rows=declared.row_count,
        actual_rows=int(len(frame)),
        column_checks=tuple(checks),
        chunks_missing=tuple(chunks_missing),
        rows_per_chunk=dict(rows_per_chunk or {}),
    )
    LOGGER.info("control_totals.checked", extra={"fields": result.summary()})
    return result
