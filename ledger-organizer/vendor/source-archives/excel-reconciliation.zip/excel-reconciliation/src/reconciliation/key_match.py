"""Matching two datasets on a composite key.

Reconciliation between two systems rarely has a shared surrogate id to join
on. Each side has its own internal id, and the only thing they agree on is a
combination of business attributes -- an entity, a location and a period, for
example. That combination is the composite key.

Joining on a composite key brings two problems a single-id join hides, and
this module reports both instead of letting them distort the result:

* **Duplicates.** If a key repeats on both sides, an inner join multiplies
  rows and every downstream sum is inflated. So the key sets are compared
  first, and repeated keys are reported as their own exception category.
* **Nulls.** A missing component makes the key meaningless, and SQL-style
  null comparison would drop those rows without a word. They are separated
  out and reported before matching starts.
"""

from __future__ import annotations

import logging
from collections.abc import Sequence
from dataclasses import dataclass, field

import pandas as pd

__all__ = ["MatchResult", "match_on_composite_key"]

LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class MatchResult:
    """Outcome of matching two datasets on a composite key.

    Attributes:
        key_columns: Columns that make up the composite key.
        left_name: Label for the first dataset.
        right_name: Label for the second dataset.
        matched: One row per key present on both sides, with the number of
            rows contributing from each side.
        left_only: Full rows whose key exists only in the left dataset.
        right_only: Full rows whose key exists only in the right dataset.
        duplicate_keys: Keys that appear more than once on either side, with
            the per-side occurrence counts.
        null_key_rows: Rows excluded from matching because at least one key
            component was null, with the offending component named.
    """

    key_columns: tuple[str, ...]
    left_name: str
    right_name: str
    matched: pd.DataFrame = field(repr=False)
    left_only: pd.DataFrame = field(repr=False)
    right_only: pd.DataFrame = field(repr=False)
    duplicate_keys: pd.DataFrame = field(repr=False)
    null_key_rows: pd.DataFrame = field(repr=False)

    @property
    def matched_count(self) -> int:
        """Number of keys found on both sides."""
        return int(len(self.matched))

    @property
    def left_only_count(self) -> int:
        """Number of left-hand rows with no counterpart."""
        return int(len(self.left_only))

    @property
    def right_only_count(self) -> int:
        """Number of right-hand rows with no counterpart."""
        return int(len(self.right_only))

    @property
    def duplicate_key_count(self) -> int:
        """Number of keys that repeat on at least one side."""
        return int(len(self.duplicate_keys))

    @property
    def null_key_row_count(self) -> int:
        """Number of rows excluded because a key component was null."""
        return int(len(self.null_key_rows))

    @property
    def exception_count(self) -> int:
        """Total rows that will appear in the exception report."""
        return (
            self.left_only_count
            + self.right_only_count
            + self.duplicate_key_count
            + self.null_key_row_count
        )

    @property
    def passed(self) -> bool:
        """``True`` when every row matched and no key was duplicated or null."""
        return self.exception_count == 0

    def exception_frames(self) -> dict[str, pd.DataFrame]:
        """Return the non-empty exception frames, keyed by report sheet name."""
        candidates = {
            f"only_in_{self.left_name}": self.left_only,
            f"only_in_{self.right_name}": self.right_only,
            "duplicate_keys": self.duplicate_keys,
            "null_key_rows": self.null_key_rows,
        }
        return {name: frame for name, frame in candidates.items() if not frame.empty}

    def summary(self) -> dict[str, object]:
        """Return a flat, log-friendly and JSON-friendly summary."""
        return {
            "check": "key_match",
            "key_columns": list(self.key_columns),
            "matched_keys": self.matched_count,
            f"only_in_{self.left_name}": self.left_only_count,
            f"only_in_{self.right_name}": self.right_only_count,
            "duplicate_keys": self.duplicate_key_count,
            "null_key_rows": self.null_key_row_count,
            "exceptions": self.exception_count,
            "passed": self.passed,
        }


def match_on_composite_key(
    left: pd.DataFrame,
    right: pd.DataFrame,
    key_columns: Sequence[str],
    *,
    left_name: str = "left",
    right_name: str = "right",
) -> MatchResult:
    """Classify every row of two datasets as matched, left-only or right-only.

    Rows with a null key component are removed first and reported separately.
    The remaining rows are compared at key level, so a duplicated key does
    not multiply the output the way an inner join would; duplicates get their
    own exception frame instead.

    Args:
        left: First dataset.
        right: Second dataset.
        key_columns: Columns forming the composite key. Must exist on both
            sides.
        left_name: Label for the first dataset, used in sheet names and logs.
        right_name: Label for the second dataset.

    Returns:
        A :class:`MatchResult`.

    Raises:
        KeyError: If a key column is missing from either dataset.
        ValueError: If ``key_columns`` is empty or the two labels are equal.
    """
    keys = tuple(key_columns)
    if not keys:
        raise ValueError("key_columns must not be empty")
    if left_name == right_name:
        raise ValueError("left_name and right_name must differ")
    _require_columns(left, keys, left_name)
    _require_columns(right, keys, right_name)

    left_clean, left_nulls = _split_null_keys(left, keys, left_name)
    right_clean, right_nulls = _split_null_keys(right, keys, right_name)
    null_key_rows = _concat([left_nulls, right_nulls])

    duplicate_keys = _duplicate_keys(
        left_clean, right_clean, keys, left_name, right_name
    )

    left_counts = _key_counts(left_clean, keys, f"{left_name}_rows")
    right_counts = _key_counts(right_clean, keys, f"{right_name}_rows")
    key_index = left_counts.merge(
        right_counts, on=list(keys), how="outer", indicator=True
    )

    matched = (
        key_index.loc[key_index["_merge"] == "both"]
        .drop(columns="_merge")
        .reset_index(drop=True)
    )
    for column in (f"{left_name}_rows", f"{right_name}_rows"):
        # The outer merge widens the counts to float; they are counts.
        matched[column] = matched[column].astype("int64")
    left_only_keys = key_index.loc[key_index["_merge"] == "left_only", list(keys)]
    right_only_keys = key_index.loc[key_index["_merge"] == "right_only", list(keys)]

    left_only = _select_rows(left_clean, left_only_keys, keys)
    right_only = _select_rows(right_clean, right_only_keys, keys)

    result = MatchResult(
        key_columns=keys,
        left_name=left_name,
        right_name=right_name,
        matched=matched,
        left_only=left_only,
        right_only=right_only,
        duplicate_keys=duplicate_keys,
        null_key_rows=null_key_rows,
    )
    LOGGER.info("key_match.completed", extra={"fields": result.summary()})
    return result


def _split_null_keys(
    frame: pd.DataFrame, keys: tuple[str, ...], side: str
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Split a frame into rows with a complete key and rows without one."""
    if frame.empty:
        empty = frame.copy()
        empty.insert(0, "null_key_column", pd.Series(dtype="object"))
        empty.insert(0, "source", pd.Series(dtype="object"))
        return frame.copy(), empty

    null_mask = frame[list(keys)].isna().any(axis=1)
    complete = frame.loc[~null_mask].copy()
    incomplete = frame.loc[null_mask].copy()

    if incomplete.empty:
        incomplete.insert(0, "null_key_column", pd.Series(dtype="object"))
        incomplete.insert(0, "source", pd.Series(dtype="object"))
        return complete, incomplete

    offending = incomplete[list(keys)].isna().apply(
        lambda row: ", ".join(column for column, is_null in row.items() if is_null),
        axis=1,
    )
    incomplete.insert(0, "null_key_column", offending)
    incomplete.insert(0, "source", side)
    LOGGER.warning(
        "key_match.null_keys",
        extra={"fields": {"source": side, "rows": int(len(incomplete))}},
    )
    return complete, incomplete.reset_index(drop=True)


def _key_counts(
    frame: pd.DataFrame, keys: tuple[str, ...], count_column: str
) -> pd.DataFrame:
    """Return one row per distinct key with the number of rows holding it."""
    if frame.empty:
        columns = {key: pd.Series(dtype=_key_dtype(frame, key)) for key in keys}
        columns[count_column] = pd.Series(dtype="int64")
        return pd.DataFrame(columns)
    counts = (
        frame.groupby(list(keys), dropna=False, as_index=False)
        .size()
        .rename(columns={"size": count_column})
    )
    return counts


def _key_dtype(frame: pd.DataFrame, key: str) -> object:
    """Return the dtype of a key column, defaulting to object."""
    if key in frame.columns:
        return frame[key].dtype
    return "object"


def _duplicate_keys(
    left: pd.DataFrame,
    right: pd.DataFrame,
    keys: tuple[str, ...],
    left_name: str,
    right_name: str,
) -> pd.DataFrame:
    """Return keys occurring more than once on either side, with counts."""
    left_column = f"{left_name}_rows"
    right_column = f"{right_name}_rows"
    counts = _key_counts(left, keys, left_column).merge(
        _key_counts(right, keys, right_column), on=list(keys), how="outer"
    )
    if counts.empty:
        counts[left_column] = pd.Series(dtype="int64")
        counts[right_column] = pd.Series(dtype="int64")
        return counts

    counts[left_column] = counts[left_column].fillna(0).astype("int64")
    counts[right_column] = counts[right_column].fillna(0).astype("int64")
    duplicated = counts.loc[(counts[left_column] > 1) | (counts[right_column] > 1)]
    if duplicated.empty:
        return duplicated.reset_index(drop=True)

    duplicated = duplicated.copy()
    duplicated["duplicated_in"] = [
        _duplicate_side(left_rows, right_rows, left_name, right_name)
        for left_rows, right_rows in zip(
            duplicated[left_column], duplicated[right_column], strict=True
        )
    ]
    LOGGER.warning(
        "key_match.duplicate_keys",
        extra={"fields": {"keys": int(len(duplicated))}},
    )
    return duplicated.reset_index(drop=True)


def _duplicate_side(
    left_rows: int, right_rows: int, left_name: str, right_name: str
) -> str:
    """Name the side, or sides, on which a key is duplicated."""
    sides = []
    if left_rows > 1:
        sides.append(left_name)
    if right_rows > 1:
        sides.append(right_name)
    return " and ".join(sides)


def _select_rows(
    frame: pd.DataFrame, wanted_keys: pd.DataFrame, keys: tuple[str, ...]
) -> pd.DataFrame:
    """Return the full rows of ``frame`` whose key appears in ``wanted_keys``."""
    if frame.empty or wanted_keys.empty:
        return frame.iloc[0:0].copy()
    selected = frame.merge(wanted_keys.drop_duplicates(), on=list(keys), how="inner")
    return selected.reset_index(drop=True)


def _concat(frames: Sequence[pd.DataFrame]) -> pd.DataFrame:
    """Concatenate frames, skipping empty ones to keep dtypes predictable."""
    populated = [frame for frame in frames if not frame.empty]
    if not populated:
        return frames[0].copy() if frames else pd.DataFrame()
    return pd.concat(populated, ignore_index=True)


def _require_columns(frame: pd.DataFrame, columns: Sequence[str], side: str) -> None:
    """Raise :class:`KeyError` listing every column missing from ``frame``."""
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise KeyError(f"{side} frame is missing key columns: {missing}")
