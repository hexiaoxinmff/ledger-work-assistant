#!/usr/bin/env bash
# Generate the synthetic dataset and run every check over it.
#
# Usage:  ./examples/run_demo.sh
#
# The demo exits 0 even though the sample data contains deliberate defects:
# exceptions are reported, not raised. Add --fail-on-exceptions to the run
# command below to make the exit code reflect the findings instead.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

SAMPLE_DIR="${RECON_SAMPLE_DIR:-sample_data}"
OUTPUT_DIR="${RECON_OUTPUT_DIR:-$SAMPLE_DIR/output}"
PYTHON="${PYTHON:-python3}"

# Run from the source tree without installing the package.
export PYTHONPATH="$REPO_ROOT/src:${PYTHONPATH:-}"

echo "== 1/2 generating synthetic sample data =="
"$PYTHON" scripts/generate_sample_data.py --output-dir "$SAMPLE_DIR"

echo
echo "== 2/2 running all three checks =="
"$PYTHON" -m reconciliation run \
    --config "$SAMPLE_DIR/demo_config.json" \
    --output-dir "$OUTPUT_DIR" \
    --format both

echo
echo "Exception report and run summary are in $OUTPUT_DIR"
