# excel-reconciliation

Validates tabular data before it is released to a business consumer: control totals over multi-part extracts, composite-key matching between two sources, and amount variance with a configurable tolerance, all reported as an exception workbook rather than a crash.

## The problem

Reports go out to business users, and the numbers in them are trusted immediately. The data behind those numbers often arrives in pieces, because the source system caps how much a single export can return, so one logical dataset turns up as several range-based chunks that somebody has to concatenate. When one of those chunks is truncated, or never lands at all, nothing fails: the pipeline runs, the file is written, the report is delivered, and the total is quietly wrong. Nobody notices until a business user queries a figure a week later, and by then the report has been used to make decisions.

This tool is the check that runs between "the data is assembled" and "the report is released". It compares what arrived against what the source said it would send, matches the result against a second system, and produces a list of exactly which keys disagree.

## Quickstart

Requires Python 3.10 or newer.

```bash
git clone https://github.com/<your-user>/excel-reconciliation.git
cd excel-reconciliation

python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .                   # optional: installs the `reconciliation` command

./examples/run_demo.sh
```

The demo generates a synthetic dataset with defects deliberately seeded into it, then runs all three checks over it. It is equivalent to:

```bash
python scripts/generate_sample_data.py --output-dir sample_data
PYTHONPATH=src python -m reconciliation run \
    --config sample_data/demo_config.json \
    --output-dir sample_data/output \
    --format both
```

### Expected output

The generator first reports what it wrote and what it broke:

```
== 1/2 generating synthetic sample data ==
Wrote sample data to /path/to/excel-reconciliation/sample_data
  chunks written : 4 of 5 declared
    ledger_chunk_01.csv
    ledger_chunk_02.csv
    ledger_chunk_03.csv
    ledger_chunk_04.csv
  declared totals: declared_totals.json
  second dataset : warehouse_extract.csv
  demo config    : demo_config.json
Seeded defects:
  - ledger_chunk_03.csv truncated: last 12 lines dropped
  - ledger_chunk_05.csv declared but never written (failed export part)
  - 5 lines removed from the second dataset (become left-only)
  - 3 lines duplicated in the second dataset (double posting)
  - 4 adjustment lines present only in the second dataset
  - 2 rows with a blank site_code (incomplete composite key)
  - 3 entities with amounts outside the demo tolerance (45.0, -120.5, 3.75)
  - 1 entity differing by exactly the tolerance (0.5) to exercise the inclusive boundary
  - 2 entities differing by rounding noise only (0.01, -0.02)
```

Then the run itself. This is the actual stdout, with the run id being the only thing that changes between runs:

```
== 2/2 running all three checks ==
Reconciliation run run-20260818T041340Z
Started        : 2026-08-18T04:13:40+00:00
Overall result : EXCEPTIONS FOUND

Checks
  [FAIL] control_totals: label="ledger extract", expected_rows=549, actual_rows=507, row_difference=-42, chunks_loaded=4, chunks_missing=1, column_checks=2, column_failures=2, failures=4
  [FAIL] key_match: key_columns=entity_id,site_code,period,document_no,line_no, matched_keys=500, only_in_ledger=7, only_in_warehouse=46, duplicate_keys=3, null_key_rows=2, exceptions=58
  [FAIL] variance: key_columns=entity_id,site_code,period, tolerance=0.5, tolerance_mode=absolute, decimals=2, compared=105, breaches=14, total_absolute_variance=86385.59

Exception tables
  control_total_failures: 4 row(s)
  control_total_chunks: 5 row(s)
  only_in_ledger: 7 row(s)
  only_in_warehouse: 46 row(s)
  duplicate_keys: 3 row(s)
  null_key_rows: 2 row(s)
  variance_breaches: 14 row(s)
  total exception rows: 81

Outputs
  sample_data/output/run-20260818T041340Z_exceptions.xlsx
  sample_data/output/run-20260818T041340Z_summary.csv
  sample_data/output/run-20260818T041340Z_control_total_failures.csv
  sample_data/output/run-20260818T041340Z_control_total_chunks.csv
  sample_data/output/run-20260818T041340Z_only_in_ledger.csv
  sample_data/output/run-20260818T041340Z_only_in_warehouse.csv
  sample_data/output/run-20260818T041340Z_duplicate_keys.csv
  sample_data/output/run-20260818T041340Z_null_key_rows.csv
  sample_data/output/run-20260818T041340Z_variance_breaches.csv
  sample_data/output/run-20260818T041340Z_summary.json

Exception report and run summary are in sample_data/output
```

Alongside that, a structured log goes to stderr so stdout stays clean when the summary is piped somewhere:

```
ts=2026-08-18T04:13:40.302+00:00 level=WARNING logger=reconciliation.control_totals event=chunk.missing chunks=ledger_chunk_05.csv
ts=2026-08-18T04:13:40.304+00:00 level=INFO logger=reconciliation.control_totals event=control_totals.checked check=control_totals label="ledger extract" expected_rows=549 actual_rows=507 row_difference=-42 chunks_loaded=4 chunks_missing=1 column_checks=2 column_failures=2 failures=4
```

The workbook has one sheet per exception table, with the run summary first. Every count above traces back to a seeded defect: 42 missing rows is the undelivered chunk plus the truncation, the 46 warehouse-only lines are those same rows seen from the other side, and the variance breaches include entities whose totals moved because a line was missing, duplicated or had a blank key.

The three checks can also be run individually. These assume the package is on the path, either through `pip install -e .` or by exporting `PYTHONPATH=src`:

```bash
python -m reconciliation control-totals --chunk-glob 'sample_data/ledger_chunk_*.csv' \
    --declared sample_data/declared_totals.json
python -m reconciliation key-match --left A.csv --right B.csv --key entity_id --key period
python -m reconciliation variance --left A.csv --right B.csv --key entity_id \
    --left-amount amount --right-amount net_amount --tolerance 0.50
```

## The three checks

### 1. Control totals

The source declares, up front, how many rows and what column sums the complete extract holds. After the chunks are concatenated, the assembled frame is measured against that declaration. A missing chunk file, a truncated export or a partially written file all show up here.

```python
import pandas as pd
from reconciliation import DeclaredTotals, check_control_totals

delivered = pd.DataFrame(
    {"entity_id": ["E01", "E02", "E03"], "amount": [100.00, 250.50, 99.50]}
)
declared = DeclaredTotals(
    row_count=4, column_sums={"amount": 500.00}, label="daily extract"
)

result = check_control_totals(delivered, declared)
print(result.passed)
print(result.exceptions()[["check", "subject", "expected", "actual", "difference"]])
```

```
False
     check       subject  expected  actual  difference
 row_count daily extract       4.0     3.0        -1.0
column_sum        amount     500.0   450.0       -50.0
```

One row of 50.00 never arrived, and both the count and the sum say so. `load_chunks()` does the reading and concatenation, refuses to concatenate chunks whose schemas differ, and reports a declared chunk file that is not on disk instead of raising.

### 2. Composite-key matching

Two datasets are joined on a multi-column key, and every row is classified. Keys that repeat, and keys with a null component, get their own categories rather than being folded into the match.

```python
from reconciliation import match_on_composite_key

columns = ["entity_id", "site_code", "period", "amount"]
ledger = pd.DataFrame(
    [("E01", "S01", "2026-05", 100.00),
     ("E02", "S01", "2026-05", 250.50),
     ("E03", "S02", "2026-05", 99.50)], columns=columns
)
warehouse = pd.DataFrame(
    [("E01", "S01", "2026-05", 100.00),
     ("E02", "S02", "2026-05", 250.50),
     ("E04", "S01", "2026-05", 80.00)], columns=columns
)

result = match_on_composite_key(
    ledger, warehouse,
    ["entity_id", "site_code", "period"],
    left_name="ledger", right_name="warehouse",
)
print(result.summary())
print(result.left_only)
```

```
{'check': 'key_match', 'key_columns': ['entity_id', 'site_code', 'period'],
 'matched_keys': 1, 'only_in_ledger': 2, 'only_in_warehouse': 2,
 'duplicate_keys': 0, 'null_key_rows': 0, 'exceptions': 4, 'passed': False}

entity_id site_code  period  amount
      E02       S01 2026-05   250.5
      E03       S02 2026-05    99.5
```

`E02` exists on both sides but at a different site, so it is not a match. That is the case a single-id join gets wrong: the id agrees, the business key does not, and the row silently reconciles against the wrong counterpart.

### 3. Variance with tolerance

Amounts are aggregated per entity on both sides, rounded, differenced, and compared against a tolerance that is either an absolute amount or a fraction of the value.

```python
from reconciliation import compare_amounts

ledger = pd.DataFrame(
    [("E01", 0.10), ("E01", 0.20), ("E02", 1000.00), ("E03", 5000.00)],
    columns=["entity_id", "amount"],
)
warehouse = pd.DataFrame(
    [("E01", 0.30), ("E02", 1000.50), ("E03", 4880.25)],
    columns=["entity_id", "amount"],
)

result = compare_amounts(ledger, warehouse, ["entity_id"], "amount", tolerance=0.50)
print(result.comparison)
```

```
entity_id  left_amount  right_amount  difference  relative_difference  within_tolerance
      E01          0.3          0.30        0.00              0.00000              True
      E02       1000.0       1000.50       -0.50              0.00050              True
      E03       5000.0       4880.25      119.75              0.02395             False
```

`E01` is two ledger lines of 0.10 and 0.20 against a single 0.30, which is the classic float trap; it reconciles. `E02` differs by exactly the tolerance, which passes. Only `E03` is reported.

## Design notes

### Why exceptions are reported, not raised

The first version of a check like this usually raises on the first bad row. That turns out to be the wrong behaviour for reconciliation, for three reasons.

A run that stops at the first problem tells you about one row. The person who has to fix the data needs all of them, because they will go to the source system once, not once per row. Finding 46 unmatched keys in a single pass is a morning's work; finding them one failed run at a time is a week's.

Not every exception is a defect, either. A late adjustment posted in one system and not yet in the other is a real, explainable difference. If the tool blocks on it, people start disabling the tool. Reporting it puts the judgement where it belongs, with the person who knows the process.

And the checks corroborate each other. In the demo, the truncated chunk shows up three times: as a row count shortfall, as warehouse-only rows, and as variance on the entities whose lines were cut. Seeing all three together identifies the cause immediately. Stopping at the first one hides that.

So the process exits 0 by default and writes the findings. When a caller does want a reconciliation failure to stop a pipeline, `--fail-on-exceptions` makes the exit code 2, and the JSON summary carries the same information for a scheduler to act on. That is a deployment decision, not a library one.

### Why composite keys instead of a single id

Two systems that were not designed together do not share a surrogate id. Each has its own internal sequence, and the only thing they genuinely agree on is a combination of business attributes: an entity, a location, a period, a document, a line. So the composite key is not a preference, it is the only key available.

Working with one has consequences the library handles explicitly rather than hoping for the best:

- **Duplicates multiply.** If a key appears twice on each side, an inner join produces four rows and every total after it is inflated. So the key sets are compared first and duplicates are reported as their own category, which means a double posting is visible as a double posting instead of showing up as an unexplained variance later.
- **Nulls are not keys.** A row with a blank site code cannot be matched against anything. SQL-style null comparison would drop it without comment. Those rows are separated before matching and reported with the name of the component that was missing. Their counterparts on the other side then correctly appear as unmatched, which is why the demo reports 7 ledger-only rows for 5 deliberately removed ones.
- **Column order does not matter, membership does.** The key is a list of columns given by the caller, so the same function works for a five-part line key and a three-part entity key. The demo uses both against the same pair of files.

### How tolerance is handled

Three separate decisions, because conflating them is what produces either false exceptions or missed ones.

**Rounding comes first.** Both sides are rounded to a declared number of decimal places, half-up, before anything is subtracted. Half-up rather than Python's default banker's rounding, because a finance user expects 2.675 to become 2.68. Rounding first means the comparison happens on the numbers a person would see on a report, not on their binary representations, which is why 0.1 + 0.2 reconciles against 0.3 with a tolerance of exactly zero.

**The boundary is inclusive.** A difference equal to the tolerance passes. A tolerance of 0.50 that rejects a difference of 0.50 is a bug report waiting to happen, so the comparison is `abs(difference) <= tolerance`, with a 1e-9 epsilon added so that the last bit of a float cannot flip a value that is mathematically on the line.

**Absolute and relative are both first-class.** Absolute suits populations where the amounts are of a similar size: anything over half a unit is worth looking at. Relative suits populations spanning several orders of magnitude, where a fixed amount is either noise on the large rows or an alarm on every small one. In relative mode the difference is divided by the left-hand amount, falling back to the right-hand one when the left is zero, and two zeroes are treated as agreeing.

One further decision: an amount that cannot be parsed as a number becomes NaN, and any entity whose rows contain one is left as NaN rather than summed around. NaN never satisfies a tolerance, so a corrupt value is reported as an exception instead of quietly reading as zero and reconciling.

## What I would do differently at larger scale

This is built for datasets that fit comfortably in memory, which covers the reports it was written for. Past that, several things would change.

**Reading.** `pandas.read_csv` per chunk stops being viable once the assembled frame is larger than memory. Chunked reads with an incremental accumulator would keep the control totals check working at any size, since row counts and column sums are both streaming operations and never need the whole frame at once.

**Joining.** The key match and the variance check are joins, and a database does joins better than a Python process does. Where both sides already live in a database, the right move is to push the join down and pull back only the exceptions, keeping the classification logic identical so the two paths can be tested against each other. Where they do not, a columnar engine over Parquet would be the next step before hand-rolling anything.

**Rounding.** `round_half_up` runs per value through `Decimal`, which is correct but not fast. On millions of rows I would use a vectorised integer-cent representation, and keep the current implementation as the reference the fast path is tested against.

**Run history.** Right now each run writes a file and forgets. Persisting summaries to a small table would let you answer the question that actually matters after a few months: is this getting worse, and which entities appear every single week? A recurring exception is a process problem, not a data problem, and you cannot see it one file at a time.

**Notification.** Writing a workbook is only useful if somebody opens it. In a scheduled deployment the summary would go to the owning team automatically, with the workbook attached and the exit code driving whether the downstream job runs at all.

## Tests

```bash
python -m pytest
```

```
============================= test session starts ==============================
collected 57 items

tests/test_control_totals.py ..............                              [ 24%]
tests/test_end_to_end.py ...........                                     [ 43%]
tests/test_key_match.py .............                                    [ 66%]
tests/test_variance.py ...................                               [100%]

============================== 57 passed in 1.97s ==============================
```

The suite covers the edge cases that produce wrong answers rather than exceptions:

- empty frames on either or both sides, and an empty frame against a non-zero declared row count
- a declared chunk file that never arrives, checked end to end through `load_chunks`
- chunks whose schemas do not match, which would otherwise concatenate into NaN-filled columns and still pass a row count check
- composite keys duplicated on one side and on both sides, asserting that matched keys are not multiplied
- null key components, including a row missing two of them, and the knock-on effect on the other side
- tolerance exactly on the boundary, one satang either side of it, and relative against absolute mode on the same data
- float behaviour: `0.1 + 0.2` against `0.3` with zero tolerance, ten values of `0.1` against a declared `1.00`, and half-up rounding of `2.675`
- unparsable amounts, which must be reported rather than treated as zero
- the whole CLI, over a generated dataset with defects and over one without, including exit codes

`tests/test_end_to_end.py` regenerates the sample data into a temporary directory and drives the real CLI, so the wiring between the checks, the report and the command line is covered rather than assumed. It also asserts that generation is reproducible from a seed, since a demo whose numbers move between runs is not much of a demo.

Linting is configured in `pyproject.toml`:

```bash
ruff check .
```

## Repository layout

```
src/reconciliation/
  control_totals.py   chunk loading, concatenation, declared totals
  key_match.py        composite-key classification
  variance.py         rounding, tolerance, amount comparison
  report.py           structured logging, exception workbook, run summary
  cli.py              argparse entry point
scripts/
  generate_sample_data.py   synthetic data with seeded defects
examples/
  run_demo.sh               generate, then run everything
tests/                      unit and end-to-end tests
```

All sample data is generated locally by the script; nothing in this repository is real data.

## Licence

MIT. See [LICENSE](LICENSE).
