#!/usr/bin/env python3
"""Generate the synthetic dataset used by the demo and the end-to-end test.

Everything this script writes is invented. There is no real data in this
repository and none is downloaded: the numbers come from a seeded random
number generator, so the same seed always produces the same files.

The generated dataset imitates a common situation. A source system exports
transaction lines in several parts, split by entity code range because a
single export would be too large. A second system holds what it believes is
the same population. Both are then compared.

Defects are deliberately seeded so the checks have something to find:

1. one chunk file is truncated part-way through
2. one declared chunk file is never written at all
3. a handful of lines are absent from the second dataset
4. a handful of lines exist only in the second dataset
5. a few lines are duplicated in the second dataset
6. a couple of rows have a blank key component
7. several entities have amounts that differ, including one difference
   exactly equal to the tolerance the demo uses

Run ``python scripts/generate_sample_data.py --help`` for the options.
"""

from __future__ import annotations

import argparse
import json
import os
import random
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

DEFAULT_SEED = 20260818
DEFAULT_ENTITIES = 52
PERIODS = ("2026-05", "2026-06")
SITES = ("S01", "S02", "S03", "S04", "S05")

#: Entity bands used to split the extract into chunks. The last band is
#: deliberately small: the tail of a range-based export usually is.
CHUNK_BANDS = ((0, 12), (12, 24), (24, 36), (36, 48), (48, DEFAULT_ENTITIES))

#: Absolute tolerance the demo config uses, in currency units.
DEMO_TOLERANCE = 0.50

LEDGER_COLUMNS = [
    "entity_id",
    "site_code",
    "period",
    "document_no",
    "line_no",
    "amount",
    "quantity",
]
WAREHOUSE_COLUMNS = [
    "entity_id",
    "site_code",
    "period",
    "document_no",
    "line_no",
    "net_amount",
    "qty",
    "source_ref",
]

LINE_KEY = ["entity_id", "site_code", "period", "document_no", "line_no"]
ENTITY_KEY = ["entity_id", "site_code", "period"]


@dataclass(frozen=True)
class GeneratedFiles:
    """Paths written by a generation run.

    Attributes:
        chunks: Chunk files actually written to disk.
        chunks_declared: Chunk names the declared totals claim exist.
        declared_totals: Path of the declared totals JSON.
        warehouse: Path of the second dataset.
        config: Path of the demo configuration file.
        defects: Human-readable list of the defects that were seeded.
    """

    chunks: tuple[Path, ...]
    chunks_declared: tuple[str, ...]
    declared_totals: Path
    warehouse: Path
    config: Path
    defects: tuple[str, ...]


def build_ledger(seed: int, entity_count: int) -> pd.DataFrame:
    """Build the complete, defect-free source dataset.

    Args:
        seed: Seed for the random number generator.
        entity_count: Number of distinct entities to generate.

    Returns:
        A frame with :data:`LEDGER_COLUMNS`, sorted by the line key.
    """
    rng = random.Random(seed)
    rows: list[dict[str, object]] = []
    document_counter = 1000

    for index in range(entity_count):
        entity_id = f"E{index + 1:04d}"
        sites = rng.sample(SITES, rng.choice((1, 1, 2)))
        for site_code in sites:
            for period in PERIODS:
                if rng.random() < 0.15:
                    # Not every entity trades at every site in every period.
                    continue
                for _ in range(rng.randint(1, 3)):
                    document_counter += 1
                    document_no = f"DOC-{period.replace('-', '')}-{document_counter}"
                    for line_no in range(1, rng.randint(1, 4) + 1):
                        rows.append(
                            {
                                "entity_id": entity_id,
                                "site_code": site_code,
                                "period": period,
                                "document_no": document_no,
                                "line_no": line_no,
                                "amount": round(rng.uniform(120.0, 9800.0), 2),
                                "quantity": rng.randint(1, 40),
                            }
                        )

    ledger = pd.DataFrame(rows, columns=LEDGER_COLUMNS)
    return ledger.sort_values(LINE_KEY).reset_index(drop=True)


def split_into_chunks(
    ledger: pd.DataFrame, bands: Sequence[tuple[int, int]]
) -> list[pd.DataFrame]:
    """Split the ledger into chunks by entity code range.

    Args:
        ledger: The complete dataset.
        bands: ``(start, stop)`` index pairs over the sorted entity list.

    Returns:
        One frame per band, in order.
    """
    entities = sorted(ledger["entity_id"].unique())
    chunks: list[pd.DataFrame] = []
    for start, stop in bands:
        band = set(entities[start:stop])
        chunks.append(
            ledger.loc[ledger["entity_id"].isin(band)].reset_index(drop=True)
        )
    return chunks


def build_warehouse(
    ledger: pd.DataFrame,
    seed: int,
    with_defects: bool,
    delivered_entities: Sequence[str] = (),
) -> tuple[pd.DataFrame, list[str]]:
    """Build the second dataset from the ledger, optionally seeding defects.

    Args:
        ledger: The complete, defect-free source dataset.
        seed: Seed for the random number generator.
        with_defects: When ``False`` the two datasets agree exactly.
        delivered_entities: Entities that reach the comparison, that is,
            everything outside the chunk which is never written. Defects are
            confined to these so each one is visible in its own right rather
            than hidden behind the missing chunk.

    Returns:
        The second dataset and a list of descriptions of what was seeded.
    """
    rng = random.Random(seed + 1)
    warehouse = ledger.rename(
        columns={"amount": "net_amount", "quantity": "qty"}
    ).copy()
    warehouse["source_ref"] = [f"WH{index + 1:06d}" for index in range(len(warehouse))]
    warehouse = warehouse.loc[:, WAREHOUSE_COLUMNS]
    defects: list[str] = []
    if not with_defects:
        return warehouse.reset_index(drop=True), defects

    delivered = set(delivered_entities) or set(ledger["entity_id"].unique())
    candidates = warehouse.index[warehouse["entity_id"].isin(delivered)].tolist()

    dropped = rng.sample(candidates, 5)
    warehouse = warehouse.drop(index=dropped)
    defects.append("5 lines removed from the second dataset (become left-only)")

    remaining = warehouse.index[warehouse["entity_id"].isin(delivered)].tolist()
    duplicated = rng.sample(remaining, 3)
    warehouse = pd.concat(
        [warehouse, warehouse.loc[duplicated]], ignore_index=False
    )
    defects.append("3 lines duplicated in the second dataset (double posting)")

    delivered_list = sorted(delivered)
    extras = []
    for offset in range(4):
        extras.append(
            {
                "entity_id": rng.choice(delivered_list),
                "site_code": rng.choice(SITES),
                "period": rng.choice(PERIODS),
                "document_no": f"DOC-ADJ-{9000 + offset}",
                "line_no": 1,
                "net_amount": round(rng.uniform(200.0, 1500.0), 2),
                "qty": rng.randint(1, 10),
                "source_ref": f"WHADJ{offset + 1:04d}",
            }
        )
    warehouse = pd.concat(
        [warehouse, pd.DataFrame(extras, columns=WAREHOUSE_COLUMNS)],
        ignore_index=True,
    )
    defects.append("4 adjustment lines present only in the second dataset")

    blanks = rng.sample(
        warehouse.index[warehouse["entity_id"].isin(delivered)].tolist(), 2
    )
    warehouse.loc[blanks, "site_code"] = ""
    defects.append("2 rows with a blank site_code (incomplete composite key)")

    warehouse, amount_notes = _seed_amount_differences(warehouse, delivered, rng)
    defects.extend(amount_notes)

    return warehouse.reset_index(drop=True), defects


def _seed_amount_differences(
    warehouse: pd.DataFrame, delivered: set[str], rng: random.Random
) -> tuple[pd.DataFrame, list[str]]:
    """Adjust amounts on a few lines to create variance exceptions."""
    usable = warehouse.index[
        warehouse["entity_id"].isin(delivered) & (warehouse["site_code"] != "")
    ].tolist()
    targets = rng.sample(usable, 6)
    adjustments = [45.00, -120.50, 3.75, DEMO_TOLERANCE, 0.01, -0.02]
    for index, adjustment in zip(targets, adjustments, strict=True):
        warehouse.loc[index, "net_amount"] = round(
            float(warehouse.loc[index, "net_amount"]) + adjustment, 2
        )
    notes = [
        "3 entities with amounts outside the demo tolerance "
        f"({adjustments[0]}, {adjustments[1]}, {adjustments[2]})",
        f"1 entity differing by exactly the tolerance ({DEMO_TOLERANCE}) "
        "to exercise the inclusive boundary",
        "2 entities differing by rounding noise only (0.01, -0.02)",
    ]
    return warehouse, notes


def write_dataset(
    output_dir: Path, seed: int, entity_count: int, with_defects: bool
) -> GeneratedFiles:
    """Generate every sample file and write it to ``output_dir``.

    Args:
        output_dir: Destination directory, created if needed.
        seed: Seed for the random number generator.
        entity_count: Number of entities to generate.
        with_defects: Whether to seed the deliberate defects.

    Returns:
        A :class:`GeneratedFiles` describing what was written.
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    ledger = build_ledger(seed, entity_count)
    bands = _bands_for(entity_count)
    chunks = split_into_chunks(ledger, bands)
    defects: list[str] = []

    declared_names = tuple(
        f"ledger_chunk_{index:02d}.csv" for index in range(1, len(chunks) + 1)
    )
    entities = sorted(ledger["entity_id"].unique())
    delivered_entities = entities[: bands[-1][0]] if with_defects else entities
    written: list[Path] = []
    for index, (name, chunk) in enumerate(
        zip(declared_names, chunks, strict=True), start=1
    ):
        if with_defects and index == 3:
            chunk = chunk.iloc[:-12]
            defects.append(f"{name} truncated: last 12 lines dropped")
        if with_defects and index == len(chunks):
            defects.append(f"{name} declared but never written (failed export part)")
            continue
        path = output_dir / name
        chunk.to_csv(path, index=False)
        written.append(path)

    declared = {
        "label": "ledger extract",
        "row_count": int(len(ledger)),
        "column_sums": {
            "amount": round(float(ledger["amount"].sum()), 2),
            "quantity": int(ledger["quantity"].sum()),
        },
        "chunks": list(declared_names),
    }
    declared_path = output_dir / "declared_totals.json"
    declared_path.write_text(json.dumps(declared, indent=2) + "\n", encoding="utf-8")

    warehouse, warehouse_defects = build_warehouse(
        ledger, seed, with_defects, delivered_entities
    )
    defects.extend(warehouse_defects)
    warehouse_path = output_dir / "warehouse_extract.csv"
    warehouse.to_csv(warehouse_path, index=False)

    config_path = output_dir / "demo_config.json"
    config_path.write_text(
        json.dumps(_demo_config(declared_names), indent=2) + "\n", encoding="utf-8"
    )

    return GeneratedFiles(
        chunks=tuple(written),
        chunks_declared=declared_names,
        declared_totals=declared_path,
        warehouse=warehouse_path,
        config=config_path,
        defects=tuple(defects),
    )


def _bands_for(entity_count: int) -> tuple[tuple[int, int], ...]:
    """Return chunk bands, adjusted when a non-default entity count is used."""
    if entity_count == DEFAULT_ENTITIES:
        return CHUNK_BANDS
    step = max(entity_count // 5, 1)
    bands = [(index * step, (index + 1) * step) for index in range(4)]
    bands.append((4 * step, entity_count))
    return tuple(band for band in bands if band[0] < entity_count)


def _demo_config(declared_names: Sequence[str]) -> dict[str, object]:
    """Build the configuration file the demo passes to ``reconciliation run``."""
    return {
        "name": "demo reconciliation",
        "control_totals": {
            "chunks": list(declared_names),
            "declared": "declared_totals.json",
            "amount_tolerance": 0.01,
        },
        "key_match": {
            "left": "@control_totals",
            "right": "warehouse_extract.csv",
            "keys": LINE_KEY,
            "left_name": "ledger",
            "right_name": "warehouse",
        },
        "variance": {
            "left": "@control_totals",
            "right": "warehouse_extract.csv",
            "keys": ENTITY_KEY,
            "left_amount": "amount",
            "right_amount": "net_amount",
            "tolerance": DEMO_TOLERANCE,
            "tolerance_mode": "absolute",
            "decimals": 2,
            "left_name": "ledger",
            "right_name": "warehouse",
        },
    }


def main(argv: Sequence[str] | None = None) -> int:
    """Parse arguments, generate the files and print what was created.

    Args:
        argv: Argument list, defaulting to :data:`sys.argv`.

    Returns:
        A process exit code, always 0.
    """
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument(
        "--output-dir",
        default=os.environ.get("RECON_SAMPLE_DIR", "sample_data"),
        help=(
            "where to write the generated files "
            "(default: $RECON_SAMPLE_DIR, or sample_data)"
        ),
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=DEFAULT_SEED,
        help=f"random seed (default: {DEFAULT_SEED})",
    )
    parser.add_argument(
        "--entities",
        type=int,
        default=DEFAULT_ENTITIES,
        help=f"number of entities to generate (default: {DEFAULT_ENTITIES})",
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help="generate a dataset with no seeded defects, so every check passes",
    )
    args = parser.parse_args(argv)

    generated = write_dataset(
        Path(args.output_dir), args.seed, args.entities, with_defects=not args.clean
    )

    print(f"Wrote sample data to {Path(args.output_dir).resolve()}")
    print(f"  chunks written : {len(generated.chunks)} of "
          f"{len(generated.chunks_declared)} declared")
    for path in generated.chunks:
        print(f"    {path.name}")
    print(f"  declared totals: {generated.declared_totals.name}")
    print(f"  second dataset : {generated.warehouse.name}")
    print(f"  demo config    : {generated.config.name}")
    if generated.defects:
        print("Seeded defects:")
        for defect in generated.defects:
            print(f"  - {defect}")
    else:
        print("No defects seeded; every check should pass.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
