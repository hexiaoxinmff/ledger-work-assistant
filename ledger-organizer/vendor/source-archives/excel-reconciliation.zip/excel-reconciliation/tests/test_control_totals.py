"""Tests for the control totals check."""

from __future__ import annotations

import json

import pandas as pd
import pytest

from reconciliation.control_totals import (
    DeclaredTotals,
    check_control_totals,
    combine_chunks,
    load_chunks,
)


def make_chunk(start: int, rows: int) -> pd.DataFrame:
    """Build a small chunk with predictable amounts."""
    return pd.DataFrame(
        {
            "entity_id": [f"E{start + index:04d}" for index in range(rows)],
            "amount": [round(10.0 + index, 2) for index in range(rows)],
            "quantity": [index + 1 for index in range(rows)],
        }
    )


def test_matching_totals_pass() -> None:
    frame = make_chunk(1, 4)
    declared = DeclaredTotals(
        row_count=4, column_sums={"amount": 46.0, "quantity": 10}, label="test"
    )

    result = check_control_totals(frame, declared)

    assert result.passed
    assert result.row_difference == 0
    assert result.failure_count == 0
    assert result.exceptions().empty
    assert result.exception_frames() == {}


def test_dropped_rows_are_detected() -> None:
    full = make_chunk(1, 10)
    truncated = full.iloc[:7]
    declared = DeclaredTotals(
        row_count=10,
        column_sums={"amount": float(full["amount"].sum())},
        label="test",
    )

    result = check_control_totals(truncated, declared)

    assert not result.passed
    assert result.row_difference == -3
    assert result.failure_count == 2  # row count plus the amount sum
    exceptions = result.exceptions()
    assert set(exceptions["check"]) == {"row_count", "column_sum"}


def test_column_sum_tolerance_boundary_is_inclusive() -> None:
    frame = pd.DataFrame({"amount": [100.0, 100.0]})
    declared = DeclaredTotals(row_count=2, column_sums={"amount": 199.99})

    at_boundary = check_control_totals(frame, declared, amount_tolerance=0.01)
    just_inside = check_control_totals(frame, declared, amount_tolerance=0.02)
    too_tight = check_control_totals(frame, declared, amount_tolerance=0.001)

    assert at_boundary.passed
    assert just_inside.passed
    assert not too_tight.passed


def test_float_accumulation_does_not_raise_a_false_exception() -> None:
    frame = pd.DataFrame({"amount": [0.1] * 10})
    declared = DeclaredTotals(row_count=10, column_sums={"amount": 1.0})

    result = check_control_totals(frame, declared, amount_tolerance=0.0)

    assert result.passed, "0.1 summed ten times must still reconcile to 1.00"


def test_empty_frame_with_zero_declared_rows_passes() -> None:
    result = check_control_totals(pd.DataFrame({"amount": []}), DeclaredTotals(0, {}))

    assert result.passed
    assert result.actual_rows == 0


def test_empty_frame_with_declared_rows_fails() -> None:
    result = check_control_totals(pd.DataFrame({"amount": []}), DeclaredTotals(25, {}))

    assert not result.passed
    assert result.row_difference == -25


def test_unknown_declared_column_raises() -> None:
    with pytest.raises(KeyError, match="missing columns"):
        check_control_totals(
            make_chunk(1, 2), DeclaredTotals(2, {"not_a_column": 1.0})
        )


def test_combine_chunks_rejects_mismatched_schemas() -> None:
    first = pd.DataFrame({"a": [1], "b": [2]})
    second = pd.DataFrame({"a": [1], "c": [2]})

    with pytest.raises(ValueError, match="chunk schemas differ"):
        combine_chunks([first, second])


def test_combine_chunks_with_no_input_returns_empty_frame() -> None:
    combined = combine_chunks([])

    assert combined.empty
    assert list(combined.columns) == []


def test_missing_chunk_file_is_reported_not_raised(tmp_path) -> None:
    declared_names = [f"chunk_{index}.csv" for index in range(1, 4)]
    paths = []
    for index, name in enumerate(declared_names):
        path = tmp_path / name
        paths.append(path)
        if name == "chunk_3.csv":
            continue  # the third export part never arrived
        make_chunk(index * 10 + 1, 5).to_csv(path, index=False)

    loaded = load_chunks(paths, declared_chunks=declared_names)

    assert loaded.chunks_missing == ("chunk_3.csv",)
    assert loaded.row_count == 10
    assert loaded.rows_per_chunk == {"chunk_1.csv": 5, "chunk_2.csv": 5}

    result = check_control_totals(
        loaded.frame,
        DeclaredTotals(row_count=15, label="three part extract"),
        chunks_missing=loaded.chunks_missing,
        rows_per_chunk=loaded.rows_per_chunk,
    )

    assert not result.passed
    assert result.failure_count == 2  # the missing chunk and the row shortfall
    breakdown = result.chunk_breakdown()
    assert breakdown.loc[breakdown["status"] == "missing", "chunk"].tolist() == [
        "chunk_3.csv"
    ]
    assert set(result.exception_frames()) == {
        "control_total_failures",
        "control_total_chunks",
    }


def test_declared_totals_from_json_round_trip(tmp_path) -> None:
    path = tmp_path / "declared.json"
    path.write_text(
        json.dumps(
            {
                "label": "extract",
                "row_count": 3,
                "column_sums": {"amount": 12.5},
                "chunks": ["a.csv", "b.csv"],
            }
        ),
        encoding="utf-8",
    )

    declared = DeclaredTotals.from_json(path)

    assert declared.row_count == 3
    assert declared.column_sums == {"amount": 12.5}
    assert declared.chunks == ("a.csv", "b.csv")
    assert declared.label == "extract"


def test_declared_totals_require_row_count() -> None:
    with pytest.raises(KeyError):
        DeclaredTotals.from_dict({"column_sums": {"amount": 1.0}})


def test_declared_totals_reject_negative_row_count() -> None:
    with pytest.raises(ValueError):
        DeclaredTotals.from_dict({"row_count": -1})


def test_summary_is_json_serialisable() -> None:
    result = check_control_totals(make_chunk(1, 2), DeclaredTotals(2))

    assert json.loads(json.dumps(result.summary()))["check"] == "control_totals"
