"""End-to-end tests: generate the sample data, then run the CLI over it.

These are the tests that would have caught a wiring mistake between the
checks, the report and the command line, which unit tests on their own do
not.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from openpyxl import load_workbook

from generate_sample_data import DEFAULT_ENTITIES, write_dataset
from reconciliation.cli import EXIT_EXCEPTIONS, EXIT_OK, EXIT_USAGE, main


@pytest.fixture(scope="module")
def defective_dataset(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Generate the sample dataset with every deliberate defect seeded."""
    directory = tmp_path_factory.mktemp("defective")
    write_dataset(
        directory, seed=20260818, entity_count=DEFAULT_ENTITIES, with_defects=True
    )
    return directory


@pytest.fixture(scope="module")
def clean_dataset(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Generate a dataset with no defects, where every check should pass."""
    directory = tmp_path_factory.mktemp("clean")
    write_dataset(
        directory, seed=20260818, entity_count=DEFAULT_ENTITIES, with_defects=False
    )
    return directory


def read_summary(output_dir: Path) -> dict:
    """Load the single run summary JSON written into ``output_dir``."""
    summaries = sorted(output_dir.glob("*_summary.json"))
    assert len(summaries) == 1, f"expected one summary, found {summaries}"
    return json.loads(summaries[0].read_text(encoding="utf-8"))


def check_by_name(summary: dict, name: str) -> dict:
    """Return the summary entry for one check."""
    matches = [check for check in summary["checks"] if check["check"] == name]
    assert matches, f"no {name} check in {summary['checks']}"
    return matches[0]


def test_full_run_reports_every_seeded_defect(
    defective_dataset: Path, tmp_path: Path
) -> None:
    output_dir = tmp_path / "output"

    exit_code = main(
        [
            "run",
            "--config",
            str(defective_dataset / "demo_config.json"),
            "--output-dir",
            str(output_dir),
            "--format",
            "both",
        ]
    )

    assert exit_code == EXIT_OK, "exceptions must not fail the run by default"

    summary = read_summary(output_dir)
    assert summary["passed"] is False
    assert summary["exception_rows"] > 0

    control = check_by_name(summary, "control_totals")
    assert control["chunks_missing"] == 1, "the undelivered chunk must be reported"
    assert control["row_difference"] < 0, "truncation must show as missing rows"
    assert control["column_failures"] == 2

    match = check_by_name(summary, "key_match")
    assert match["only_in_ledger"] > 0
    assert match["only_in_warehouse"] > 0
    assert match["duplicate_keys"] == 3
    assert match["null_key_rows"] == 2

    variance = check_by_name(summary, "variance")
    assert variance["breaches"] > 0
    assert variance["tolerance"] == 0.5


def test_full_run_writes_a_multi_sheet_workbook(
    defective_dataset: Path, tmp_path: Path
) -> None:
    output_dir = tmp_path / "output"

    main(
        [
            "run",
            "--config",
            str(defective_dataset / "demo_config.json"),
            "--output-dir",
            str(output_dir),
        ]
    )

    workbooks = list(output_dir.glob("*_exceptions.xlsx"))
    assert len(workbooks) == 1
    sheets = load_workbook(workbooks[0]).sheetnames
    assert sheets[0] == "run_summary"
    for expected in (
        "control_total_failures",
        "only_in_ledger",
        "only_in_warehouse",
        "duplicate_keys",
        "null_key_rows",
        "variance_breaches",
    ):
        assert expected in sheets


def test_csv_output_writes_one_file_per_exception_table(
    defective_dataset: Path, tmp_path: Path
) -> None:
    output_dir = tmp_path / "output"

    main(
        [
            "run",
            "--config",
            str(defective_dataset / "demo_config.json"),
            "--output-dir",
            str(output_dir),
            "--format",
            "csv",
        ]
    )

    assert not list(output_dir.glob("*.xlsx"))
    assert list(output_dir.glob("*_variance_breaches.csv"))


def test_fail_on_exceptions_changes_the_exit_code(
    defective_dataset: Path, tmp_path: Path
) -> None:
    exit_code = main(
        [
            "run",
            "--config",
            str(defective_dataset / "demo_config.json"),
            "--output-dir",
            str(tmp_path / "output"),
            "--fail-on-exceptions",
        ]
    )

    assert exit_code == EXIT_EXCEPTIONS


def test_clean_dataset_passes_every_check(clean_dataset: Path, tmp_path: Path) -> None:
    output_dir = tmp_path / "output"

    exit_code = main(
        [
            "run",
            "--config",
            str(clean_dataset / "demo_config.json"),
            "--output-dir",
            str(output_dir),
            "--fail-on-exceptions",
        ]
    )

    assert exit_code == EXIT_OK
    summary = read_summary(output_dir)
    assert summary["passed"] is True
    assert summary["exception_rows"] == 0
    assert summary["exception_sheets"] == {}

    workbook = load_workbook(next(iter(output_dir.glob("*_exceptions.xlsx"))))
    assert workbook.sheetnames == ["run_summary"], (
        "a passing run still gets a workbook, but only the summary sheet"
    )


def test_control_totals_command_accepts_a_glob(
    defective_dataset: Path, tmp_path: Path
) -> None:
    exit_code = main(
        [
            "control-totals",
            "--chunk-glob",
            str(defective_dataset / "ledger_chunk_*.csv"),
            "--declared",
            str(defective_dataset / "declared_totals.json"),
            "--output-dir",
            str(tmp_path / "output"),
            "--format",
            "csv",
        ]
    )

    assert exit_code == EXIT_OK
    summary = read_summary(tmp_path / "output")
    assert len(summary["checks"]) == 1
    assert check_by_name(summary, "control_totals")["chunks_missing"] == 1


def test_key_match_command_runs_standalone(
    defective_dataset: Path, tmp_path: Path
) -> None:
    exit_code = main(
        [
            "key-match",
            "--left",
            str(defective_dataset / "ledger_chunk_01.csv"),
            "--right",
            str(defective_dataset / "warehouse_extract.csv"),
            "--key",
            "entity_id",
            "--key",
            "site_code",
            "--key",
            "period",
            "--key",
            "document_no",
            "--key",
            "line_no",
            "--left-name",
            "ledger",
            "--right-name",
            "warehouse",
            "--output-dir",
            str(tmp_path / "output"),
        ]
    )

    assert exit_code == EXIT_OK
    summary = read_summary(tmp_path / "output")
    assert check_by_name(summary, "key_match")["matched_keys"] > 0


def test_variance_command_runs_standalone(
    defective_dataset: Path, tmp_path: Path
) -> None:
    exit_code = main(
        [
            "variance",
            "--left",
            str(defective_dataset / "ledger_chunk_01.csv"),
            "--right",
            str(defective_dataset / "warehouse_extract.csv"),
            "--key",
            "entity_id",
            "--key",
            "site_code",
            "--key",
            "period",
            "--left-amount",
            "amount",
            "--right-amount",
            "net_amount",
            "--tolerance",
            "0.5",
            "--output-dir",
            str(tmp_path / "output"),
        ]
    )

    assert exit_code == EXIT_OK
    assert check_by_name(read_summary(tmp_path / "output"), "variance")["compared"] > 0


def test_missing_config_file_is_a_usage_error(tmp_path: Path) -> None:
    exit_code = main(
        [
            "run",
            "--config",
            str(tmp_path / "does_not_exist.json"),
            "--output-dir",
            str(tmp_path / "output"),
        ]
    )

    assert exit_code == EXIT_USAGE


def test_config_without_any_check_is_a_usage_error(tmp_path: Path) -> None:
    config = tmp_path / "empty.json"
    config.write_text(json.dumps({"name": "nothing to do"}), encoding="utf-8")

    exit_code = main(
        ["run", "--config", str(config), "--output-dir", str(tmp_path / "output")]
    )

    assert exit_code == EXIT_USAGE


def test_sample_data_is_reproducible(tmp_path: Path) -> None:
    first = tmp_path / "first"
    second = tmp_path / "second"
    write_dataset(first, seed=99, entity_count=20, with_defects=True)
    write_dataset(second, seed=99, entity_count=20, with_defects=True)

    for path in sorted(first.iterdir()):
        assert path.read_bytes() == (second / path.name).read_bytes(), path.name
