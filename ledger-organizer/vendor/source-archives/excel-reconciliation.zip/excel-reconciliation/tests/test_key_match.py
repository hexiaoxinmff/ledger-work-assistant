"""Tests for composite-key matching."""

from __future__ import annotations

import pandas as pd
import pytest

from reconciliation.key_match import match_on_composite_key

KEYS = ["entity_id", "site_code", "period"]


def frame(rows: list[tuple[str, str, str, float]]) -> pd.DataFrame:
    """Build a small frame with the standard composite key plus an amount."""
    return pd.DataFrame(rows, columns=[*KEYS, "amount"])


def test_rows_are_classified_three_ways() -> None:
    left = frame(
        [
            ("E01", "S01", "2026-05", 100.0),
            ("E02", "S01", "2026-05", 200.0),
            ("E03", "S02", "2026-05", 300.0),
        ]
    )
    right = frame(
        [
            ("E01", "S01", "2026-05", 100.0),
            ("E02", "S01", "2026-05", 200.0),
            ("E04", "S03", "2026-05", 400.0),
        ]
    )

    result = match_on_composite_key(left, right, KEYS)

    assert result.matched_count == 2
    assert result.left_only["entity_id"].tolist() == ["E03"]
    assert result.right_only["entity_id"].tolist() == ["E04"]
    assert not result.passed
    assert result.exception_count == 2


def test_identical_datasets_pass() -> None:
    left = frame([("E01", "S01", "2026-05", 100.0)])

    result = match_on_composite_key(left, left.copy(), KEYS)

    assert result.passed
    assert result.exception_frames() == {}
    assert result.matched_count == 1


def test_same_entity_at_different_sites_is_a_different_key() -> None:
    left = frame(
        [
            ("E01", "S01", "2026-05", 100.0),
            ("E01", "S02", "2026-05", 150.0),
        ]
    )
    right = frame([("E01", "S01", "2026-05", 100.0)])

    result = match_on_composite_key(left, right, KEYS)

    assert result.matched_count == 1
    assert result.left_only["site_code"].tolist() == ["S02"]


def test_duplicate_keys_are_reported_and_do_not_multiply_rows() -> None:
    left = frame([("E01", "S01", "2026-05", 100.0)])
    right = frame(
        [
            ("E01", "S01", "2026-05", 100.0),
            ("E01", "S01", "2026-05", 100.0),
            ("E01", "S01", "2026-05", 100.0),
        ]
    )

    result = match_on_composite_key(
        left, right, KEYS, left_name="ledger", right_name="warehouse"
    )

    assert result.matched_count == 1, "a duplicated key must stay one key"
    assert result.duplicate_key_count == 1
    duplicate = result.duplicate_keys.iloc[0]
    assert duplicate["ledger_rows"] == 1
    assert duplicate["warehouse_rows"] == 3
    assert duplicate["duplicated_in"] == "warehouse"
    assert result.matched.iloc[0]["warehouse_rows"] == 3


def test_keys_duplicated_on_both_sides_name_both() -> None:
    rows = [("E01", "S01", "2026-05", 100.0)] * 2
    result = match_on_composite_key(frame(rows), frame(rows), KEYS)

    assert result.duplicate_keys.iloc[0]["duplicated_in"] == "left and right"


def test_null_key_components_are_separated_before_matching() -> None:
    left = frame([("E01", "S01", "2026-05", 100.0)])
    right = pd.DataFrame(
        [
            ("E01", "S01", "2026-05", 100.0),
            ("E02", None, "2026-05", 200.0),
        ],
        columns=[*KEYS, "amount"],
    )

    result = match_on_composite_key(left, right, KEYS)

    assert result.null_key_row_count == 1
    assert result.null_key_rows.iloc[0]["null_key_column"] == "site_code"
    assert result.null_key_rows.iloc[0]["source"] == "right"
    assert result.right_only.empty, "a null-key row must not be reported twice"
    assert result.matched_count == 1


def test_multiple_null_components_are_all_named() -> None:
    left = frame([])
    right = pd.DataFrame(
        [("E01", None, None, 10.0)], columns=[*KEYS, "amount"]
    )

    result = match_on_composite_key(left, right, KEYS)

    assert result.null_key_rows.iloc[0]["null_key_column"] == "site_code, period"


def test_two_empty_frames_pass() -> None:
    result = match_on_composite_key(frame([]), frame([]), KEYS)

    assert result.passed
    assert result.matched_count == 0
    assert result.exception_count == 0


def test_empty_left_reports_every_right_row() -> None:
    right = frame([("E01", "S01", "2026-05", 100.0)])

    result = match_on_composite_key(frame([]), right, KEYS)

    assert result.matched_count == 0
    assert result.right_only_count == 1
    assert result.left_only_count == 0


def test_missing_key_column_raises() -> None:
    left = frame([("E01", "S01", "2026-05", 100.0)])
    right = left.drop(columns=["period"])

    with pytest.raises(KeyError, match="missing key columns"):
        match_on_composite_key(left, right, KEYS)


def test_empty_key_list_raises() -> None:
    with pytest.raises(ValueError, match="must not be empty"):
        match_on_composite_key(frame([]), frame([]), [])


def test_identical_side_labels_raise() -> None:
    with pytest.raises(ValueError, match="must differ"):
        match_on_composite_key(
            frame([]), frame([]), KEYS, left_name="same", right_name="same"
        )


def test_exception_frames_use_the_side_labels() -> None:
    left = frame([("E01", "S01", "2026-05", 100.0)])
    right = frame([("E02", "S01", "2026-05", 100.0)])

    result = match_on_composite_key(
        left, right, KEYS, left_name="ledger", right_name="warehouse"
    )

    assert set(result.exception_frames()) == {"only_in_ledger", "only_in_warehouse"}
