"""Tests for the amount variance check."""

from __future__ import annotations

import math

import pandas as pd
import pytest

from reconciliation.variance import compare_amounts, round_half_up, within_tolerance

KEYS = ["entity_id", "site_code"]


def frame(rows: list[tuple[str, str, float]], column: str = "amount") -> pd.DataFrame:
    """Build a small frame with a two-part key and one amount column."""
    return pd.DataFrame(rows, columns=[*KEYS, column])


def test_round_half_up_matches_finance_expectations() -> None:
    assert round_half_up(2.675, 2) == 2.68
    assert round_half_up(0.5, 0) == 1.0
    assert round_half_up(1.5, 0) == 2.0
    assert round_half_up(-2.675, 2) == -2.68
    assert math.isnan(round_half_up(None))
    assert math.isnan(round_half_up(float("nan")))


def test_round_half_up_rejects_negative_decimals() -> None:
    with pytest.raises(ValueError):
        round_half_up(1.0, -1)


def test_within_tolerance_boundary_is_inclusive() -> None:
    assert within_tolerance(100.00, 100.50, 0.50)
    assert not within_tolerance(100.00, 100.51, 0.50)
    assert within_tolerance(100.00, 99.50, 0.50)


def test_within_tolerance_relative_mode() -> None:
    assert within_tolerance(1000.0, 1010.0, 0.01, "relative")
    assert not within_tolerance(1000.0, 1011.0, 0.01, "relative")
    assert within_tolerance(0.0, 0.0, 0.0, "relative")
    assert not within_tolerance(0.0, 5.0, 0.01, "relative")


def test_within_tolerance_rejects_bad_arguments() -> None:
    with pytest.raises(ValueError):
        within_tolerance(1.0, 1.0, -0.5)
    with pytest.raises(ValueError):
        within_tolerance(1.0, 1.0, 0.5, "loose")  # type: ignore[arg-type]


def test_nan_never_passes() -> None:
    assert not within_tolerance(float("nan"), 1.0, 100.0)


def test_float_addition_does_not_create_a_false_exception() -> None:
    left = frame([("E01", "S01", 0.1), ("E01", "S01", 0.2)])
    right = frame([("E01", "S01", 0.3)])

    result = compare_amounts(left, right, KEYS, "amount", tolerance=0.0)

    assert result.passed, "0.1 + 0.2 must reconcile against 0.3"
    assert result.comparison.iloc[0]["difference"] == 0.0


def test_exact_tolerance_boundary_passes_but_one_satang_more_does_not() -> None:
    left = frame([("E01", "S01", 100.00), ("E02", "S01", 100.00)])
    right = frame([("E01", "S01", 100.50), ("E02", "S01", 100.51)])

    result = compare_amounts(left, right, KEYS, "amount", tolerance=0.50)

    breaches = result.breaches()
    assert result.breach_count == 1
    assert breaches.iloc[0]["entity_id"] == "E02"


def test_amounts_are_aggregated_per_key() -> None:
    left = frame(
        [("E01", "S01", 10.0), ("E01", "S01", 15.0), ("E02", "S01", 20.0)]
    )
    right = frame([("E01", "S01", 25.0), ("E02", "S01", 20.0)])

    result = compare_amounts(left, right, KEYS, "amount", tolerance=0.0)

    assert result.compared_count == 2
    assert result.passed


def test_different_amount_column_names_are_supported() -> None:
    left = frame([("E01", "S01", 100.0)])
    right = frame([("E01", "S01", 90.0)], column="net_amount")

    result = compare_amounts(
        left,
        right,
        KEYS,
        "amount",
        "net_amount",
        tolerance=0.50,
        left_name="ledger",
        right_name="warehouse",
    )

    row = result.comparison.iloc[0]
    assert row["ledger_amount"] == 100.0
    assert row["warehouse_amount"] == 90.0
    assert row["difference"] == 10.0
    assert result.total_absolute_variance == 10.0


def test_relative_tolerance_scales_with_the_amount() -> None:
    left = frame([("E01", "S01", 100.0), ("E02", "S01", 100000.0)])
    right = frame([("E01", "S01", 105.0), ("E02", "S01", 100500.0)])

    absolute = compare_amounts(left, right, KEYS, "amount", tolerance=10.0)
    relative = compare_amounts(
        left, right, KEYS, "amount", tolerance=0.01, tolerance_mode="relative"
    )

    assert absolute.breach_count == 1, "only the large gap breaks an absolute limit"
    assert relative.breach_count == 1, "only the large ratio breaks a relative limit"
    assert absolute.breaches().iloc[0]["entity_id"] == "E02"
    assert relative.breaches().iloc[0]["entity_id"] == "E01"


def test_breaches_are_ordered_by_size() -> None:
    left = frame(
        [("E01", "S01", 100.0), ("E02", "S01", 100.0), ("E03", "S01", 100.0)]
    )
    right = frame(
        [("E01", "S01", 110.0), ("E02", "S01", 400.0), ("E03", "S01", 150.0)]
    )

    result = compare_amounts(left, right, KEYS, "amount", tolerance=0.50)

    assert result.breaches()["entity_id"].tolist() == ["E02", "E03", "E01"]


def test_keys_on_only_one_side_are_not_compared() -> None:
    left = frame([("E01", "S01", 100.0), ("E99", "S09", 100.0)])
    right = frame([("E01", "S01", 100.0)])

    result = compare_amounts(left, right, KEYS, "amount")

    assert result.compared_count == 1
    assert result.passed, "unmatched keys belong to the key match report"


def test_empty_inputs_produce_an_empty_comparison() -> None:
    empty = frame([])

    result = compare_amounts(empty, empty.copy(), KEYS, "amount")

    assert result.compared_count == 0
    assert result.breach_count == 0
    assert result.passed
    assert result.exception_frames() == {}
    assert list(result.comparison.columns)[-3:] == [
        "difference",
        "relative_difference",
        "within_tolerance",
    ]


def test_duplicate_keys_raise_when_aggregation_is_disabled() -> None:
    left = frame([("E01", "S01", 10.0), ("E01", "S01", 10.0)])
    right = frame([("E01", "S01", 20.0)])

    with pytest.raises(ValueError, match="duplicate keys"):
        compare_amounts(left, right, KEYS, "amount", aggregate=False)


def test_non_numeric_amounts_become_nan_and_are_flagged() -> None:
    left = pd.DataFrame([("E01", "S01", "n/a")], columns=[*KEYS, "amount"])
    right = frame([("E01", "S01", 10.0)])

    result = compare_amounts(left, right, KEYS, "amount", tolerance=1000.0)

    assert result.breach_count == 1, "an unparsable amount must not pass silently"


def test_missing_column_raises() -> None:
    left = frame([("E01", "S01", 10.0)])

    with pytest.raises(KeyError, match="missing columns"):
        compare_amounts(left, left.copy(), KEYS, "not_a_column")


def test_negative_tolerance_raises() -> None:
    left = frame([("E01", "S01", 10.0)])

    with pytest.raises(ValueError, match="tolerance must be"):
        compare_amounts(left, left.copy(), KEYS, "amount", tolerance=-1.0)


def test_summary_reports_the_configuration() -> None:
    left = frame([("E01", "S01", 10.0)])
    summary = compare_amounts(
        left, left.copy(), KEYS, "amount", tolerance=0.25
    ).summary()

    assert summary["check"] == "variance"
    assert summary["tolerance"] == 0.25
    assert summary["tolerance_mode"] == "absolute"
    assert summary["passed"] is True
