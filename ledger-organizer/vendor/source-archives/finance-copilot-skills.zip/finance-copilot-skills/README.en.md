# finance-copilot-skills

![license](https://img.shields.io/badge/license-MIT-blue)
![language](https://img.shields.io/badge/language-Chinese--first-green)
![status](https://img.shields.io/badge/status-v0.3.0-blue)
![release](https://img.shields.io/badge/release-Preview-yellow)
![data](https://img.shields.io/badge/data-local%20only%20·%20network%20blocked-brightgreen)
![agents](https://img.shields.io/badge/agents-Claude%20Code%20%7C%20Codex%20%7C%20WorkBuddy-grey)

[简体中文](README.md) | **English**

finance-copilot-skills is a set of finance-workflow agent skills you drop into the coding agent you already use (Claude Code / Codex / WorkBuddy). **Programs do the math** (amounts, matching, cross-foot checks run in local deterministic code), **AI does the guiding and explaining** (clarify field mappings, describe results, flag risks), **humans make the business calls** (which line truly matches, which one to chase, whether to sign off). Built for accountants, auditors, and SME finance leads: no Python required, no commands to type, and your ledgers never get uploaded anywhere. It is **not** an ERP, an accounting system, or bookkeeping software — it sits on top of your existing Excel / CSV / local-file workflow and adds small, single-purpose skills; installing one never forces you to install the whole set. Currently at **v0.3.0**: one released skill, [`fcs-reconcile`](skills/fcs-reconcile/) (reconciliation, release status `Preview`), plus 8 candidate directions awaiting real-demand validation. The authoritative status, platform support, and test state for each skill live in its [`SKILL_META.yaml`](skills/fcs-reconcile/SKILL_META.yaml).

> **A note on language.** The skills are Chinese-first by design: prompts, result workbooks, and status labels are written in Chinese finance terminology, because that is what the target users read and hand to their auditors. This English README documents the same system; if you install it, expect Chinese output.

## Design philosophy

**Deterministic work goes to programs, ambiguous work goes to humans, and AI only translates between the two.**

The most time-consuming part of finance work (pulling data from many files, cleaning formats, reconciling bank statements against ledgers, cross-foot checks) follows fairly stable rules yet breaks easily through copy-paste and formula slips. The part that should *never* be automated (is this delta a bank fee, is this in-transit item worth chasing, can this be signed off) depends on business judgment and accountability. General-purpose AI gets these backwards: it substitutes uncertain reasoning for deterministic computation, produces different results from the same data on two runs, and never tells you whether your file was uploaded, retained, or used for training.

This toolkit draws that line hard: **amount arithmetic, matching, cross-foot checks, format conversion, and rule validation are all performed by repeatable local programs.** AI understands your intent, guides field confirmation, explains results, and flags risks. AI does **not** guess amounts, does **not** arbitrarily pick one of several candidates, does **not** invent explanations for discrepancies, does **not** auto-confirm when rules are ambiguous, and does **not** make the final business judgment for you.

**Non-negotiable baseline**: no uncertain match is ever auto-released; every result states what input, what rule, what evidence it rests on, and what still needs human confirmation; raw transaction detail does not enter the model context by default.

**Conflict arbitration: rigor has veto power.** Deterministic validation must never be relaxed, tests never skipped, and data-flow disclosure never blurred in the name of "ship faster, lighter process, one less confirmation step." When it looks like a trade-off, the process itself usually needs redesign — "human confirmation slows us down" means optimize the confirmation step, not loosen the auto-confirm criteria ([PRD §1.2](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md), in Chinese).

**Free, but not at the price of your data**: core capabilities are free, and revenue never comes from collecting, selling, training on, or analyzing your financial data. No hidden paywall, no forced registration, no default upload of usage records, no telemetry behind your back.

## ✅ What it does / ⛔ What it won't do

| ✅ finance-copilot-skills will | ⛔ finance-copilot-skills won't |
| --- | --- |
| Reconcile bank statements against payment ledgers, AR against collections, AP against payments | Guess which line a transaction pairs with when the candidate isn't unique |
| Sort discrepancies into 8 explicit states and rank them for human review | Auto-release fuzzy matches, or treat uncertainty as "matched" |
| Show you which files it reads/writes, whether it goes online, and whether raw data reaches the model — before running | Log into your online banking / tax portal / production ERP, or hold your credentials |
| SHA-256 the inputs before and after, keep source files read-only, refuse to overwrite inputs | Create, approve, or post accounting vouchers |
| Emit a machine-readable run manifest per run (versions, hashes, field mapping, config, counts) | Issue tax-filing conclusions or accounting-policy judgments |
| Produce an Excel result workbook you keep reviewing, circulating, and handing to audit | Connect to databases or production systems by default |
| Say plainly what still needs human confirmation and what is a data-quality problem | Collect or sell your financial data, or train models on it |
| Solve exactly one task per skill, installable / upgradable / removable on its own | Become a "super skill" that covers everything |

**"Won't auto-release" is a responsibility boundary, not a missing feature.** In reconciliation, the line that *looks* like it matches is precisely the line a human needs to see. That is why tolerance here only **grades** discrepancies and never widens auto-confirmation: an 8-yuan gap may be a bank fee or may be a short receipt; the program refuses to characterize it and instead ranks it prominently in the "items to handle" sheet with both amounts, the delta, the source rows, and a suggested action.

> Every boundary traces back to [PRD §2.5 non-goals](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md) and [§4 design principles](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md); the auto-confirm rules for reconciliation are in [matching-rules.md](skills/fcs-reconcile/references/matching-rules.md).

## Finance workflow × toolkit capabilities

| Finance task | Skill | What it does | Status |
| --- | --- | --- | --- |
| **Reconciliation** | [`fcs-reconcile`](skills/fcs-reconcile/) | Bank statement vs payment ledger, AR vs collections, AP vs payments, or two business systems' transaction detail; locate discrepancies and produce a human-review worksheet | ✅ Released (`Preview`) |
| Data cleaning | `fcs-clean` | Clean Excel / CSV finance detail; normalize IDs, amounts, and dates | 🔭 Candidate, pending validation |
| Field extraction | `fcs-extract` | Extract specified finance fields from structured files | 🔭 Candidate, pending validation |
| Report generation | `fcs-report` | Generate management reports from a confirmed template | 🔭 Candidate, pending validation |
| Cross-foot checks | `fcs-check` | Check statement cross-footing, formulas, and abnormal swings | 🔭 Candidate, pending validation |
| Statement analysis | `fcs-analyze` | Analyze financial statements, trends, and key metrics | 🔭 Candidate, pending validation |
| Budget variance | `fcs-budget` | Compare budget against actuals and locate variances | 🔭 Candidate, pending validation |
| AR aging | `fcs-aging` | Build and analyze accounts-receivable aging | 🔭 Candidate, pending validation |
| Expense checks | `fcs-expense` | Find duplicates, anomalies, and missing fields in expense detail | 🔭 Candidate, pending validation |
| Voucher posting / tax filing / logging into external systems | — (no skill) | Belongs to accounting systems and professional judgment; explicitly left to humans and existing systems | 🚫 Explicitly not covered |

**A candidate is not a roadmap promise.** Every new skill must pass independent demand validation (real users, a recurring task, verifiable inputs/outputs, a programmable deterministic core, a clear security boundary, and at least one de-identified test set with golden answers). Nothing gets greenlit just because "the toolkit wants to grow" ([PRD §8.2](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md)). Skills touching PDF, OCR, tax, vouchers, or production-system connections need a separate security review on top.

## Quick start

What works today is **reconciliation**: hand it the bank statement and the payment ledger you exported, and it produces a result workbook of 7 Chinese worksheets, computed entirely locally. Demo data ships with the repo, so you can see the full output about three minutes after installing.

### Installation

**Copy the block below that matches your agent and paste it to them** — the agent does the install; you don't type a single command and don't change a single character. The three blocks differ only in the target directory, and each one is self-contained.

**Install into Claude Code** 👇

```text
Please install the finance-copilot-skills finance toolkit for me:

1. Clone https://github.com/cxtx/finance-copilot-skills into a temp directory
2. Make sure ~/.claude/skills/ exists (create it if not), then copy **every subdirectory**
   under the repo's skills/ into it — all of them, none left out (currently 1: fcs-reconcile)
   - Copy the subdirectories themselves; do NOT nest the whole skills/ directory inside.
     One extra level and the skill gets named skills:fcs-reconcile
   - Copy each skill directory whole: SKILL.md, SKILL_META.yaml, requirements.txt,
     LICENSE plus scripts/ references/ examples/ must all be there. Without scripts/
     the skill is discoverable but cannot actually reconcile anything
   - Overwrite directories of the same name; that is how updates work
   - Leave every skill from other sources alone — do NOT wipe the directory
3. Install the runtime dependencies (**this is the only step that needs network**):
   python -m pip install -r ~/.claude/skills/fcs-reconcile/requirements.txt
   - Whichever python you install with is the python that must later run the reconcile
     script; it has to be the same interpreter
   - Report the actual installed versions of pandas / openpyxl / pyyaml back to me
   - If it fails, paste the error verbatim; do not skip this step and call it done —
     the reconcile script fails outright without these dependencies
4. Delete the temp directory
5. Tell me where it landed, which skills are installed, and which interpreter has the deps
```

**Install into Codex** 👇

```text
Please install the finance-copilot-skills finance toolkit for me:

1. Clone https://github.com/cxtx/finance-copilot-skills into a temp directory
2. Make sure ~/.codex/skills/ exists (create it if not), then copy **every subdirectory**
   under the repo's skills/ into it — all of them, none left out (currently 1: fcs-reconcile)
   - Copy the subdirectories themselves; do NOT nest the whole skills/ directory inside.
     One extra level and the skill gets named skills:fcs-reconcile
   - Copy each skill directory whole: SKILL.md, SKILL_META.yaml, requirements.txt,
     LICENSE plus scripts/ references/ examples/ must all be there. Without scripts/
     the skill is discoverable but cannot actually reconcile anything
   - Overwrite directories of the same name; that is how updates work
   - Leave every skill from other sources alone — do NOT wipe the directory
3. Install the runtime dependencies (**this is the only step that needs network**):
   python -m pip install -r ~/.codex/skills/fcs-reconcile/requirements.txt
   - Whichever python you install with is the python that must later run the reconcile
     script; it has to be the same interpreter
   - Report the actual installed versions of pandas / openpyxl / pyyaml back to me
   - If it fails, paste the error verbatim; do not skip this step and call it done —
     the reconcile script fails outright without these dependencies
4. Delete the temp directory
5. Tell me where it landed, which skills are installed, and which interpreter has the deps
```

**Install into WorkBuddy** 👇

```text
Please install the finance-copilot-skills finance toolkit for me:

1. Clone https://github.com/cxtx/finance-copilot-skills into a temp directory
2. Make sure ~/.workbuddy/skills/ exists (create it if not), then copy **every subdirectory**
   under the repo's skills/ into it — all of them, none left out (currently 1: fcs-reconcile)
   - Copy the subdirectories themselves; do NOT nest the whole skills/ directory inside.
     One extra level and the skill gets named skills:fcs-reconcile
   - Copy each skill directory whole: SKILL.md, SKILL_META.yaml, requirements.txt,
     LICENSE plus scripts/ references/ examples/ must all be there. Without scripts/
     the skill is discoverable but cannot actually reconcile anything
   - Overwrite directories of the same name; that is how updates work
   - Leave every skill from other sources alone — do NOT wipe the directory
3. Install the runtime dependencies (**this is the only step that needs network**):
   python -m pip install -r ~/.workbuddy/skills/fcs-reconcile/requirements.txt
   - Whichever python you install with is the python that must later run the reconcile
     script; it has to be the same interpreter
   - Report the actual installed versions of pandas / openpyxl / pyyaml back to me
   - If it fails, paste the error verbatim; do not skip this step and call it done —
     the reconcile script fails outright without these dependencies
4. Delete the temp directory
5. Tell me where it landed, which skills are installed, and which interpreter has the deps
```

Skills load only in a **newly opened session** — an already-open session won't see them. WorkBuddy also lets you verify the install in its "Skills" panel.

> **Want it in a single project only?** Swap the user-level path in the prompt for the
> project-level directory under that project's root: `.claude/skills/` for Claude Code,
> `.codex/skills/` for Codex, and **`.codebuddy/skills/` for WorkBuddy** — note it is *not*
> `.workbuddy/`. Its user-level directory is `~/.workbuddy/`, but the project-level one keeps
> the name of the underlying CodeBuddy kernel. Get it wrong and no skill shows up at all.
>
> **Using a different host?** Same prompt; just point the target path at that host's skills
> directory. These skills follow the general Agent Skills format (`SKILL.md` + `scripts/` +
> `references/`) and aren't locked to one host. **Installing to the wrong location shows up as
> no skills at all and no error message whatsoever** — the hosts don't read each other's
> directories, so install a copy per host you use.
>
> **Network at install time, blocked at run time**: step 3 needs network. After that, every
> reconciliation runs locally — `scripts/reconcile.py` blocks the network as its first action
> and installs nothing, connects nowhere.

> ⚠ **The three hosts are not at the same support level — check which one you are on:**
>
> | Host | Level | What it means |
> | --- | --- | --- |
> | Claude Code, Codex | **Use-verified** | The maintainer has installed and run it repeatedly across several real projects. 6 of the 9 PRD FT-11 verification items are covered by that actual use; **3 are not confirmed inside the host** — permission confirmation, run-time network blocking, and error handling. Those only surface on failure paths that routine reconciliation never reaches. Item-by-item status: [verification records](tests/cross_platform/records/) (Chinese) |
> | WorkBuddy | **Format compatible** | The layout follows the general Agent Skills format and the paths come from the host's public conventions, but **this repo has never actually run on it** |
>
> "Use-verified" is not the item-by-item walkthrough FT-11 defines. Full path table, the 9
> verification items, and troubleshooting order are in the
> [multi-agent install matrix](docs/governance/agent-install.md) (Chinese).

### Three-minute test drive

[`skills/fcs-reconcile/examples/`](skills/fcs-reconcile/examples/) ships demo data (a 12-row ledger vs a 13-row bank statement, seeded with 7 typical discrepancy types). Point your agent at it:

> Use fcs-reconcile to reconcile these two tables: the ledger and the bank statement in 对账演示数据.xlsx

It will **show a data-handling declaration and wait for your confirmation** first:

```plaintext
Run mode: locally isolated
Will read: N local files ｜ Will write: M result files
Raw data enters the model: No
Network access: disabled
Source files modified: No
Transaction detail printed to terminal: No
Input integrity: SHA-256 verified before and after
```

Only after you confirm does it reconcile locally and emit the result workbook plus the run manifest. A sample output, `对账演示数据_对账结果.xlsx`, sits in the same directory — open it to see exactly what to expect.

The demo data deliberately covers the 7 situations you hit most often. Case ④ is **intentionally left unmatched** to show where primary-key matching stops:

| Type | Scenario | What to notice |
| --- | --- | --- |
| ① Exact match | Amount / date / ID all agree | The baseline; lands in "matched" |
| ② Amount mismatch | 5,800 vs 5,808 | Bank fee / FX difference — motivates amount tolerance |
| ③ One-to-many | Ledger 12,000 ↔ bank 8,000 + 4,000 | Matched on the summed amount |
| ④ Many-to-one | Ledger 3,500 + 2,500 ↔ bank's merged 6,000 | The bank memo carries no business ID, so pure key matching can't reach it → goes to review, your call |
| ⑤ Left-only | In the ledger, not in the bank | In transit / not yet cleared |
| ⑥ Right-only | In the bank, not in the ledger | Unrecorded entry / fee / interest / anonymous receipt |
| ⑦ Date offset | Booked 7/3, cleared 7/4 | Date tolerance for cross-day reconciliation |

## How to ask: prompts for reconciliation

**You don't need to memorize skill names.** Describe where you're stuck in your own words and the agent matches the right skill; naming `fcs-reconcile` explicitly works exactly the same.

> **Asking is the opening move, not a one-shot exchange.** It will first pin down which two tables, which columns are ID / amount / date / direction, what tolerance to use, and where results go — then stop at the data-handling declaration and wait for you. **Nothing is written to disk before you confirm.**

| What you'd ask | Lands on | What you get |
| --- | --- | --- |
| "Reconcile this month's bank statement against the collections ledger" | `fcs-reconcile` | Field mapping and rule confirmation → data-handling declaration → result workbook of 7 Chinese worksheets + `manifest.json` run manifest |
| "AR and collections don't tie out, where's the gap?" / "Check AP against payments" | `fcs-reconcile` | Same as above; swap in AR/collections or AP/payments as the two sides — the rules don't change |
| "Two systems exported different detail, find the differences" | `fcs-reconcile` | Same as above; supports different column names per side, non-first-row headers, and a specified worksheet |
| "The ledger and the bank differ by 8 — is that a fee?" | `fcs-reconcile` (tolerance grading) | Lands as "likely match (pending human confirmation)," **not** an auto-release; comes with both amounts, the delta, source rows, and a suggested action |
| "The same document number appears twice — now what?" | `fcs-reconcile` (bypass path) | The "duplicates and conflicts" sheet lists **all** candidates and the conflict reason; it won't pick one for you |
| "Excel turned these IDs into scientific notation" | `fcs-reconcile` (data quality) | The "data quality" sheet flags them as risky long IDs and preserves the original text — it does **not** silently "fix" them |
| "Audit wants this result — how do I prove it wasn't altered?" | `fcs-reconcile` (auditability) | The "run parameters" sheet + `manifest.json`: input/output SHA-256, field mapping, rule/contract versions, run time and config |
| "This data is sensitive; I want to confirm nothing leaves the machine before it runs" | Pre-run declaration | Files read/written, whether raw data reaches the model, network state, whether source files change, integrity check result — it proceeds only after you confirm |

### These asks get turned down — each with an alternative

| What you might ask | Why it won't | Where it points you |
| --- | --- | --- |
| "Just auto-match the close-enough ones, I don't want to review line by line" | Auto-releasing fuzzy matches writes misjudgments into the books; NFR-01 requires a zero misjudgment rate for deterministic auto-confirmation | → Tolerance **grades and ranks** discrepancies instead, so you only work the "items to handle" sheet |
| "Post the matched ones / generate the vouchers" | Voucher creation, approval, and posting belong to accounting systems — an explicit non-goal | → The result workbook carries full source rows; feed it back into your existing accounting process |
| "Log into my online banking and pull the statement" | The runtime blocks the network, holds no credentials, and touches no production system | → Export xlsx / csv from your bank yourself, then reconcile locally |
| "Just send me both files and analyze them" | Raw detail does not enter the model context by default (NFR-02) | → Give file paths only; the program reads them locally and AI receives just the summary (match rate, per-state counts, cross-foot verdict) |
| "Tell me whether to accrue this / how to treat it for tax" | Accounting policy and tax conclusions are professional judgments; AI issues none | → It lays out the amount delta, source rows, and evidence; the characterization is yours |
| "Overwrite the original file with the result" | Overwriting the input destroys audit evidence | → The output-path check **refuses to run**; save to a new file |
| "Build me one super skill that reconciles everything in one click" | Single-purpose is a hard constraint; piling on features breaks both boundaries and security review | → One task per skill, install and upgrade what you need |

### End to end: one reconciliation from start to finish

```plaintext
 1. Export the statement from your bank and the ledger from your system (2 xlsx/csv)
                                                        <- you, offline
 2. "Reconcile these two for me"                        -> agent matches fcs-reconcile
 3. Confirm the two sides, field mapping, tolerance,
    debit/credit direction, output location             <- your call
 4. Review the data-handling declaration (files, model, network)
                                                        <- you confirm; nothing on disk yet
 5. Reconcile locally: read -> normalize -> staged match -> classify
                                                        <- program, network blocked
 6. Cross-foot checks (count and amount, in Decimal)    <- verdict goes to the overview
                                                           sheet and the manifest, never
                                                           silently swallowed
 7. Write the 7-sheet result workbook + manifest.json   <- to the location you chose
 8. AI receives only the summary: match rate, per-state counts, cross-foot verdict
                                                        <- detail stays local
 9. Review "items to handle" in Excel; fill in review status / reviewer / notes
                                                        <- judgment is yours
10. Hand the result plus the run manifest to audit      <- versions, hashes, config included
```

## What you get: the 7 sheets of the result workbook

All in Chinese, with no English status codes, so you keep filtering, annotating, and circulating in Excel ([output contract v1.0](docs/contracts/fcs-reconcile/output-contract.md)):

| Worksheet | Purpose | Key columns |
| --- | --- | --- |
| **对账总览** (Overview) | Judge completeness of this run at a glance | Match rate, count cross-foot, amount cross-foot, left/right amount totals, per-state counts, privacy run summary (run mode / model exposure / network / source-file mutation) |
| **待处理事项** (Items to handle) | The human-review worksheet — your main workspace | Priority · issue type · business ID · left amount · right amount · amount delta · evidence · suggested action · source rows · review status · reviewer · review notes |
| **已匹配** (Matched) | Audit trail for auto-confirmed pairs | Business ID, both amounts, matching evidence, source rows |
| **重复与冲突** (Duplicates & conflicts) | Duplicate IDs and every candidate | Business ID, candidate list, conflict reason |
| **数据质量** (Data quality) | Empty IDs / invalid amounts / risky long IDs | Issue type, source rows, original value |
| **审计明细** (Audit detail) | Traceable evidence | Source row, normalized value, rule hit, matching evidence |
| **运行参数** (Run parameters) | Everything needed to reproduce the run | Inputs, field mapping, config, rule/contract versions, file hashes |

**The 8 result states** (all Chinese in the output): auto-matched · likely match · amount discrepancy · left-only · right-only · duplicate ID · multi-candidate conflict · data-quality issue. Definitions and the Chinese finance-terminology mapping are in [field-glossary.md](skills/fcs-reconcile/references/field-glossary.md).

## Why you can trust it

Not promises — engineering decisions you can check one by one:

- **The auto-confirm rule**: a pair becomes "auto-matched" if and only if ① the candidate is unique (exactly one row per side, no competing candidate) **and** ② the rule is fully satisfied (amount delta strictly 0, or every composite-key field equal). Fail either and it becomes a review or conflict state instead. **Tolerance only grades discrepancies and never widens auto-confirmation** — anything inside tolerance is by definition uncertain and goes to a human ([matching-rules.md](skills/fcs-reconcile/references/matching-rules.md)).
- **Amounts never touch floats**: `Decimal` fixed-point throughout; thousands separators, currency symbols, and full-width characters are cleaned first; the quantization scale is configurable with HALF_UP rounding.
- **Cross-footing is surfaced, never swallowed**: `left row count = Σ per-state left counts`, `right row count = Σ per-state right counts`, and `Σ left amounts − Σ right amounts = Σ amount deltas` (all in `Decimal`). The verdict is written as pass/fail at the top of the overview sheet and counted in the run manifest's `errors` field — a failed cross-foot means the reconciliation itself is broken, and you see it at a glance instead of receiving a result that merely looks right. This is what guarantees every row is accounted for.
- **Network blocked at run time**: `scripts/reconcile.py` calls `guard.block_network()` as its first step; any outbound `socket.connect` raises `NetworkDisabledError`. Only the dependency install needs network.
- **Source files read-only, and provably so**: SHA-256 computed before and after and compared; if the output path equals any input path, execution is refused.
- **Detail stays inside the data plane**: only the `summary` (match rate, per-state counts, cross-foot verdict) is handed up to AI. Raw detail, DataFrames, and normalized rows never leave; the terminal prints no transaction detail, and logs carry only state counts and error codes.
- **Reproducible**: identical input + identical config + identical rule version must produce an identical result (NFR-05). `rule_version` and `contract_version` only ever increment once published — manifests already on disk cite the old numbers, so rewriting them would falsify audit evidence.
- **No version drift**: the versions in `pyproject.toml`, `SKILL_META.yaml`, `scripts/version.py`, `SKILL.md`, and both CHANGELOGs are machine-asserted equal by [`tests/supply_chain/test_version_consistency.py`](tests/supply_chain/test_version_consistency.py), and the README's install paths are guarded against the [install matrix](docs/governance/agent-install.md) by [`tests/cross_platform/test_install_paths.py`](tests/cross_platform/test_install_paths.py). Both classes of drift are nearly undetectable from the user's side, which is exactly why they're machine-checked.
- **Test state**: unit / property / golden (cell-by-cell snapshot) / security tests pass (network isolation, log redaction, source-file integrity, output-never-overwrites-input), and the 6-item toolkit-level security baseline runs for real in CI. **Independent forward testing is `self-tested`** — the maintainer has used it, but the round where the tester doesn't know the expected answers hasn't been run, and the more familiar you are with a skill the less you can stand in for a stranger. Hence not `passing`.

> ⚠ **Do not read "runs locally" as "data never leaves your machine."** The local script does block the network and raw detail does not enter the model by default — but **your conversation with the agent** goes through the host platform (Claude Code / Codex / WorkBuddy each have their own data policies). So: file paths, column names, and aggregate numbers do enter the conversation; transaction detail does not. For highly sensitive data, use a fully offline setup ([PRD §7.2 host-platform disclosure](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md)).

> ⚠ **Release status is `Preview`**: no interface-stability commitment. Still outstanding — the 9-item FT-11 walkthrough (currently "use-verified", 3 items unconfirmed inside the hosts), the independent forward test of PRD §10.1 (currently maintainer self-testing), release signing, and SBOM. Before using it on production books, evaluate it against your own internal-control requirements and keep a human review step. Known limitations are itemized under "已知限制" in the [CHANGELOG](CHANGELOG.md).

## Repository layout

| Directory | Purpose |
| --- | --- |
| [`skills/`](skills/) | Source for each skill (one directory per skill; releases build self-contained packages) |
| [`packages/`](packages/) | Single source for shared libraries (abstracted only after ≥2 skills prove reuse; empty today) |
| [`tools/`](tools/) | Build / sync / package / sign / SBOM / security checks / scaffolding |
| [`tests/`](tests/README.md) | Toolkit-level tests (trigger conflicts, cross-platform, supply chain) |
| [`docs/`](docs/) | [PRD](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md), [technical design](docs/design/fcs-reconcile-technical-design-v0.1.md), [ADRs](docs/adr/README.md), [contracts](docs/contracts/fcs-reconcile/input-contract.md), [security](docs/security/README.md), [governance](docs/governance/README.md), specs |
| `dist/` | Build output: self-contained skill packages (not committed) |

Inside a single skill (using `fcs-reconcile` as the example): `SKILL.md` (AI entry point) · `SKILL_META.yaml` (catalog metadata) · `scripts/` (deterministic execution, the data plane) · `references/` (AI runtime reference, the control plane) · `agents/` (per-agent configuration) · `examples/` (demo data and sample results) · `tests/` (unit / property / boundary / golden / security).

**Deterministic code belongs in `scripts/`; anything AI reads belongs in `SKILL.md` / `references/`** — the two must not blur. That is how control-plane/data-plane separation is enforced in practice. Full structural design and rationale: [docs/specs/2026-07-23-project-structure-design.md](docs/specs/2026-07-23-project-structure-design.md).

## Development

Requires Python ≥ 3.11 and [uv](https://docs.astral.sh/uv/).

```bash
# Dependencies and unified tooling (uv workspace); uv.lock is the single source of truth
uv sync

# Full test suite (toolkit-level + per-skill)
uv run pytest

# Just one skill's tests
uv run pytest skills/fcs-reconcile/tests

# Lint / type check (mypy strict)
uv run ruff check .
uv run mypy .

# Regenerate the demo data and sample result
python3 skills/fcs-reconcile/examples/gen_reconcile_demo.py
python3 skills/fcs-reconcile/examples/gen_reconcile_result.py
```

Run the reconciliation engine directly (config fields in the [input contract](docs/contracts/fcs-reconcile/input-contract.md)):

```bash
python skills/fcs-reconcile/scripts/reconcile.py --config <config.yaml>
```

## Roadmap

| Version | Theme | Status |
| --- | --- | --- |
| v0.1 | Security foundation + reconciliation reference implementation | ✅ Released |
| **v0.2** | **Multi-agent installation + unified versioning** | ✅ Current |
| v0.3 | Second finance skill (prerequisite: the first skill completes real-user validation) | Planned |
| v0.4 | Cross-platform distribution: finish FT-11 item-by-item verification for Codex and Claude Code first, then extend to GitHub Copilot / Cursor / Gemini CLI; signed releases and SBOM | Planned |
| v0.5 | Toolkit governance: skill catalog, unified quality gates, dev templates, release states, contribution review, deprecation and rollback | Planned |
| v1.0 | Stable free toolkit: ≥3 skills validated with real users, core security controls independently checked, stable contracts | Planned |

> **The roadmap is the plan; the [CHANGELOG](CHANGELOG.md) is the fact.** When they disagree, the CHANGELOG wins ([versioning.md §6](docs/governance/versioning.md)).

## Contributing

To develop or customize, start with [CONTRIBUTING.md](CONTRIBUTING.md) (the FT-12 submission checklist for new skills, the three review dimensions, greenlight criteria) and [docs/governance/versioning.md](docs/governance/versioning.md) (sources of truth and bump timing for all four version layers). The three easiest traps:

1. **Never relax deterministic validation, security isolation, or auditability** — rigor has veto power and outranks any convenience.
2. **`rule_version` / `contract_version` only increment once published**; the runtime version number comes solely from `scripts/version.py`, never as a literal scattered through business code.
3. **A new skill means editing the three install prompts in the README** (name the new skill, update the "currently N" count) — otherwise the CI install-path guard blocks the change.

⚠ Whether community-contributed skills are accepted, and who performs the finance / security / code reviews, is still undecided (PRD §10.4 open questions ⑨⑩).

## Security

Please do **not** report vulnerabilities through public issues, and do not attach real financial data to a report — send de-identified samples only. The private reporting channel is still to be determined; see [SECURITY.md](SECURITY.md).

## License

**[MIT License](LICENSE)** — free to use, modify, distribute, sell, and sublicense; just keep the copyright and license notice. Full text in [`LICENSE`](LICENSE).

Beyond the license there is one commitment that **isn't in the license text but is equally non-negotiable**: this toolkit does not collect, sell, or train on your financial data ([PRD §1.3](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md)). MIT governs how the code may be used; it says nothing about data. That commitment is backed by engineering instead — network blocked at run time, raw detail kept out of the model, no transaction detail in logs — all checkable item by item (see [Why you can trust it](#why-you-can-trust-it)).

The software is provided "as is", without warranty of any kind. Reconciliation results **always require your human review** — that is both the license's disclaimer and this toolkit's design premise.
