# finance-copilot-skills 项目结构设计（长期可维护）

> 所属项目：`finance-copilot-skills`
> 文档版本：v0.1　｜　编制日期：2026-07-23　｜　状态：待评审
> 上游文档：
> - [Finance-Copilot-Skills-PRD-v0.2](../prd/Finance-Copilot-Skills-PRD-v0.2.md)（§1.1 形态、§4 原则、§5 架构、§6 功能需求、§7 安全、§10 治理）
> - [`fcs-reconcile` 技术设计 v0.1](../design/fcs-reconcile-technical-design-v0.1.md)（§2.2 模块划分）
>
> 本文档定义**仓库/项目的组织结构**（目录布局、约定、构建与治理形态），面向长期可维护。不定义业务算法（见技术设计）与逐字段契约（见下游规格）。

---

## 一、目标与范围

**目标**：为工具集提供一个稳定、可长期演进的仓库骨架，使其能：
- 承载多个"小而专"、可独立安装/升级/卸载的财务 Skill；
- 把 PRD 的安全底线（控制/数据平面分离、本地隔离、可核验、供应链）落到目录与流程约定上；
- 在遵守 PRD "不过早抽象" 的前提下，预留清晰的"生长点"，让新增能力不需推翻结构。

**范围内**：顶层目录布局、单个 Skill 内部结构、共享代码的组织与自包含发布机制、文档治理布局、构建/发布/校验工具的位置、CI 与供应链约定、长期演进路径。

**范围外**：对账算法与状态机（技术设计已定）、逐字段 schema、AI 提示词、各平台适配的实现细节。

---

## 二、关键决策（ADR 摘要）

| # | 决策 | 选择 | 理由 |
|---|---|---|---|
| D1 | 结构的"时间范围" | **折中：骨架定位置** | 搭稳定的长期骨架并预留"位置 + 约定"，但不提前写共享代码、不提前铺多 Skill 脚手架。兼顾"长期可维护"与 PRD "经 ≥2 Skill 验证后才抽象"。 |
| D2 | 共享代码复用方式 | **自包含发布 + 单一源同步** | monorepo 内共享代码有唯一源（`packages/`）；发布时同步/vendor 进每个 Skill，产出**完全自包含**的发布包。同时满足 FT-02 独立安装、§1.1 "装一个不强制装全套"、§7.2 整包哈希/签名/SBOM。 |
| D3 | 顶层仓库组织 | **按角色分层的 monorepo** | `skills/ packages/ tools/ tests/ docs/ dist/` 职责清晰、可扩展、最契合 D2；优于扁平布局（根目录易乱）与平台分发布局（违反 DRY 与 NFR-08）。 |
| D4 | 单个 Skill 内部 `scripts/` 组织 | **平铺模块，不做包化** | 保留技术设计 §2.2 的模块拆分（单一职责、可独立测试），但不建 `__init__.py`/子包。贴合 Agent Skills "丢进平台即可跑" 的执行方式，规避 `sys.path`/导入路径脆弱性，契合 D2 自包含。 |

冲突仲裁沿用 PRD §1.2：**严谨性一票否决**。任何结构演化不得为便利而放松安全与可核验约束。

---

## 三、顶层结构

```
finance-copilot-skills/
├── README.md                    # 工具集定位、免费红线、数据不交换原则
├── LICENSE                       # MIT License（PRD §10.4 ①② 已定）
├── CONTRIBUTING.md               # 贡献流程 + 财务/安全/代码三审（PRD 待办 ⑨⑩）
├── SECURITY.md                   # 漏洞报告渠道、严重度分级、响应时限（§10.2）
├── CHANGELOG.md                  # 工具集级发布记录
├── .gitignore                    # 忽略 dist/、临时数据、任何凭据
│
├── skills/                       # 各 Skill 开发源（一 Skill 一目录）
│   └── fcs-reconcile/            #   首个参考实现（见 §四）
│
├── packages/                     # 共享库唯一源【v0.1 暂空，仅占位 + 约定】
│   └── README.md                 #   抽象准则：经 ≥2 个 Skill 验证后才落此
│
├── tools/                        # 工具集级工程化（非业务代码）
│   ├── build/                    #   自包含打包：把 packages/ 同步进 Skill → dist/
│   ├── release/                  #   版本 / 哈希 / 签名 / SBOM / 发布状态
│   ├── verify/                   #   安全基线：网络隔离、日志泄露扫描、哈希校验
│   └── new-skill/                #   脚手架：按 FT-12 生成新 Skill 骨架
│
├── tests/                        # 工具集级测试（跨 Skill，非单 Skill 内部）
│   ├── triggering/               #   触发 / 非触发 / 相邻 Skill 冲突（FT-03）
│   ├── cross_platform/           #   平台发现/调用/权限/网络矩阵（FT-11）
│   └── supply_chain/             #   依赖锁定、哈希、签名验证（§7.2）
│
├── docs/                         # 治理与规格（保留已有 prd/ design/）
│   ├── prd/                      #   ✔ 已有
│   ├── design/                   #   ✔ 已有（技术设计蓝图）
│   ├── adr/                      #   架构决策记录（技术设计 §11 的 ADR 落此）
│   ├── contracts/                #   输入输出契约（版本化，权威源）
│   ├── security/                 #   威胁模型、安全基线、数据流与隐私设计
│   ├── governance/               #   立项条件、发布状态、弃用/回滚、平台矩阵、Skill 目录
│   └── specs/                    #   brainstorming/plan 产出（含本文档）
│
├── dist/                         # 构建产物：自包含 Skill 包【.gitignore】
│
├── pyproject.toml                # 根：统一 lint/format/type/test 配置（uv workspace）
├── uv.lock                       # 锁定依赖 + 哈希（可换 pip-tools --generate-hashes）
└── .github/workflows/            # CI：回归、安全基线、构建、发布门禁
```

**结构 → 约束映射：**

| 结构选择 | 对应 PRD 约束 / 决策 |
|---|---|
| `skills/` 每个独立、release 出自包含包 | FT-02 独立安装、§1.1 装一个不强制装全套 |
| `packages/` 现仅放 README（占位 + 约定） | D1；PRD "经 ≥2 Skill 验证后才抽象" |
| `tools/build` 发布时把共享码同步进 Skill | D2 自包含 + 单一源同步 |
| `tools/release` 出哈希/签名/SBOM | §7.2 软件供应链、FT-06 完整性 |
| PM/设计/契约文档全在 `docs/`，不进 Skill 运行目录 | §5.2 "Skill 运行目录不放 PRD/ADR 等" |
| `dist/` 被 gitignore | 工作区约定 "不编辑构建产物" |

---

## 四、单个 Skill 内部结构（以 `fcs-reconcile` 落地）

```
skills/fcs-reconcile/
├── SKILL.md                     # 必需：name / description / 触发规范 / 功能 / 限制 / 数据处理声明
├── SKILL_META.yaml              # 目录元数据：中文名/隐私等级/版本/支持平台/发布状态（FT-01）
├── agents/                      # 平台专属配置（不侵入业务核心，NFR-08）
│   ├── openai.yaml              #   Codex（P0）
│   └── claude-code.md           #   Claude Code（P0）
├── scripts/                     # ★ 数据平面：本地确定性执行（平铺模块，无 __init__.py / 无子包）
│   ├── reconcile.py             #   薄入口：解析参数 → 编排各模块 → 写结果
│   ├── config.py                #   字段映射与规则加载校验 → ReconcileConfig
│   ├── io_reader.py             #   只读打开、表头定位、源文件 SHA-256
│   ├── normalizer.py            #   金额(Decimal)/日期/编号/方向标准化
│   ├── matcher.py               #   分阶段确定性匹配
│   ├── classifier.py            #   状态归类 + 优先级
│   ├── reporter.py              #   生成 7 张中文工作表
│   ├── manifest.py              #   运行清单（不含明细）
│   ├── integrity.py             #   输入哈希前后校验、拒绝覆盖输入
│   ├── guard.py                 #   网络隔离 + 日志脱敏封装
│   └── summary.py               #   汇总字典 —— 唯一可进 AI 上下文的出口
├── references/                  # 控制平面：给 AI 运行时读的规则/术语（人可读）
│   ├── matching-rules.md        #   匹配阶段 + 自动确认铁律
│   └── field-glossary.md        #   中文财务术语与字段释义
├── assets/                      # 结果工作簿模板/样式（可选）
├── tests/                       # 本 Skill 测试（随 Skill 演进；release 时剥离）
│   ├── conftest.py              #   把 scripts/ 注入 sys.path，使平铺模块可被导入
│   ├── unit/                    #   各模块单元测试
│   ├── property/                #   勾稽恒等式、左右对称、无重复占用
│   ├── golden/{inputs,expected} #   黄金答案：脱敏输入 → 期望汇总/计数/勾稽
│   ├── boundary/                #   空编号/非法金额/危险长编号/多候选/容差边界
│   └── security/                #   网络隔离、日志泄露、源文件完整性
├── requirements.txt             # 运行时依赖（哈希锁定，可离线装 → FT-05 "不在运行期装依赖"）
└── CHANGELOG.md                 # 本 Skill：Skill 版本 / 规则版本 / 契约版本 / 回滚点
```

**关键取舍：**
- **`scripts/` 平铺模块、不包化（D4）**：保留 9 模块单一职责与可独立测试；入口 `reconcile.py` 与兄弟模块同目录，`import matcher` 即可（运行时 `sys.path[0]` 为 `scripts/`）；测试侧用 `tests/conftest.py` 把 `scripts/` 注入 `sys.path`。将来 vendor 共享码亦平铺进 `scripts/`（或 `scripts/_vendor/`），维持自包含。
- **契约不放 Skill 目录**，而在 `docs/contracts/fcs-reconcile/`：遵守 "运行目录不放 PM/规格文档"，同时让契约成为版本化、可评审的治理工件（FT-12 提交项引用它）。
- **`references/` 留在 Skill 内**：AI 运行时要读（控制平面），属自包含一部分。
- **`tests/` 与 Skill 同目录、release 时剥离**：开发期共演进，发布包只留运行所需 + SBOM/哈希/签名。

---

## 五、控制平面 / 数据平面 → 目录映射

PRD §5.1 的平面分离在结构上的落点：

- **控制平面（AI 可见）** = `SKILL.md` + `references/` + `agents/`
- **数据平面（仅本地、离线）** = `scripts/`
- **两平面唯一的桥** = `scripts/summary.py` 输出的汇总字典；原始明细/DataFrame/单元格绝不越界进模型上下文。

`normalizer` / `matcher` / `classifier` 全程在本地内存操作，`guard.py` 统一封装网络隔离与日志脱敏。

---

## 六、构建 / 同步 / 发布流程

```
开发期（monorepo，DRY）
  skills/<skill>/scripts/*.py  ── import fcs_core.xxx ──▶  packages/fcs-core/  (uv workspace 可编辑)
                                                            ▲ v0.1 为空，无 import

发布期（tools/build，产出自包含包）
  读取 skills/<skill>/  ──▶  把它用到的 packages/ 代码 vendor 进 bundle 的 scripts/
                         ──▶  剥离 tests/ 等开发件  ──▶  dist/<skill>/  ← 完全自包含

签名期（tools/release）
  对 dist/<skill>/ 整包：算 SHA-256 · 生成 SBOM · 签名 · 打发布状态标签
```

- **v0.1 现状**：`packages/` 为空 → vendor 步骤 no-op，`dist/fcs-reconcile/` ≈ 直接拷贝。**管线与位置先立，等第 2 个 Skill 让共享码"够格"抽象时自动生效**（D1 的精髓）。
- **产物特性**：每个 `dist/<skill>/` 是可独立哈希、签名、SBOM 的完整工件，一次满足 FT-02 / FT-06 / §7.2。

---

## 七、docs/ 治理组织

| PRD §10.5 / FT-12 要求的文档 | 归入 |
|---|---|
| 立项书、功能/非功能需求规格、需求追踪矩阵、分阶段计划 | `docs/specs/` |
| 安全威胁模型、数据流与隐私设计 | `docs/security/` |
| Skill 开发规范、安全基线、测试评测规范、跨平台规范、发布/签名/SBOM 规范 | `docs/governance/` |
| 输入输出契约（版本化，权威源） | `docs/contracts/<skill>/` |
| RFC | `docs/adr/`（ADR）；如需提案态可加 `docs/rfc/` |
| `fcs-reconcile` 技术设计 | `docs/design/`（✔ 已有） |
| Skill 目录（FT-01，随数量增长再落地） | `docs/governance/catalog.md`（可由 `SKILL_META.yaml` 生成） |

**发布状态机**（§10.2）：`Experimental → Preview → Stable → Deprecated → Retired`，记录在每个 `SKILL_META.yaml` 的 `status` 字段，规范在 `docs/governance/`。

---

## 八、tools/ + 根配置 + 供应链 / CI

- **`tools/verify`**（本地可跑，亦进 CI）：网络隔离测试（拦出站）、日志泄露扫描、源文件前后哈希一致、依赖哈希校验 —— 对应 §9 安全硬目标（未授权网络 0、日志泄露 0、源文件非预期修改 0）。
- **`tools/new-skill`**：按 FT-12 生成新 Skill 骨架 + 待补文档清单。
- **根 `pyproject.toml`**：uv workspace，统一 `ruff`(lint+format)·`mypy`(type)·`pytest`(test)，全仓一致。
- **`uv.lock`**：全仓依赖的**唯一锁定真源**（版本 + 哈希，§7.2 硬要求）；如更熟 `pip-tools --generate-hashes` 亦可，位置不变。
- **依赖两层关系（消歧）**：根 `uv.lock` 服务开发/CI 全仓；每个 Skill 的 `requirements.txt` 是该 Skill **运行时依赖子集**，由 `tools/build` 从锁定真源**导出并带哈希**（非手工维护），供发布包离线安装。二者同源，避免漂移。
- **`.github/workflows/`**：CI 门禁 —— 自动化测试 100% 通过、`tools/verify` 安全基线、`tools/build` 构建、发布前**独立前向测试**（§10.1，测试者不预知答案）。

---

## 九、长期演进：生长点 + 新增 Skill 流程

**"生长点"清单**（现在空/占位，明确将来长什么 —— D1 的精髓）：

| 位置 | 现在 | 触发条件 → 将来 |
|---|---|---|
| `packages/` | 只有 README | 第 2 个 Skill 出现且复用被验证 → 抽象共享库 |
| `skills/` | 仅 `fcs-reconcile` | 真实需求验证通过 → 平行新增，**不改已有 Skill**（NFR-07） |
| `docs/governance/catalog.md` | 无 | Skill 数量增长 → 生成式目录 |
| 离线安装包（vendored wheels） | 无 | 高敏离线模式落地（PRD 待办 ⑥、§7.2 P1） |
| `agents/` 各平台配置 | Codex + Claude Code | FT-11 P1/P2 平台逐个正式验证后新增 |

**新增 Skill 流程**（FT-12，由 `tools/new-skill` 起步）：
`tools/new-skill` 生成骨架 → 补 `docs/`（需求调研 / PRD / 契约 / 安全边界 / 技术设计 / ADR）→ 实现 `scripts/` → 脱敏测试数据 + 黄金答案 → 自动化测试 → 独立前向测试 → 定发布状态 + 回滚说明。

结构天然满足"新增不改旧"（NFR-07）：`skills/` 平行扩展，`packages/` 契约只增不破坏。

---

## 十、结构 ↔ PRD 需求追溯

| 需求 | 结构落点 |
|---|---|
| FT-02 独立安装 | `skills/<skill>/` + `dist/<skill>/` 自包含包 |
| FT-05 本地隔离（不在运行期装依赖） | `scripts/guard.py` + 每 Skill `requirements.txt`（离线可装） |
| FT-06 文件完整性 | `scripts/integrity.py` + `tools/verify` 哈希校验 |
| FT-08 运行清单 | `scripts/manifest.py` |
| FT-11 跨平台 | `agents/` + `tests/cross_platform/` |
| FT-12 扩展机制 | `tools/new-skill` + `docs/`（契约/安全/设计/ADR） |
| NFR-07 可扩展（不改旧） | `skills/` 平行 + `packages/` 稳定契约 |
| NFR-08 可移植（平台不侵入核心） | `agents/`(平台) 与 `scripts/`(核心) 分离 |
| NFR-09 可维护（版本化/回滚） | 每 Skill `CHANGELOG.md` + `SKILL_META.yaml` + `docs/governance/` |
| §7.2 供应链 | `uv.lock` + `tools/release`(SBOM/签名/哈希) + `tests/supply_chain/` |
| §5.1 平面分离 | 控制面(`SKILL.md`/`references`/`agents`) vs 数据面(`scripts`)，桥=`summary.py` |

---

## 十一、非目标 / 暂不做（守住 D1）

- 不在 v0.1 建任何第 2 个 Skill 的目录。
- 不在 `packages/` 放任何共享代码（仅 README 约定）。
- 不预建离线安装包、多平台适配（Codex/Claude Code 之外）、生成式 Skill 目录。
- `tools/build` 的 vendor 逻辑先做到 no-op 可用即可，不为尚不存在的共享码过度设计。

---

## 十二、待确认项（依赖 PRD 待办）

- ~~**许可证**（PRD 待办 ①②）~~ **已定**：MIT License（2026-08-04），见 [LICENSE](../../LICENSE)。
- **依赖管理工具**：默认 `uv`（lockfile 带哈希）；若团队偏好 `pip-tools`，位置与约定不变。
- **贡献与审核主体**（PRD 待办 ⑨⑩）：`CONTRIBUTING.md` 中的三审流程待明确责任人。
- **完全离线安装包**（PRD 待办 ⑥）：是否提供、何时提供，作为生长点保留。
