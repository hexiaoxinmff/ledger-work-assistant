# finance-copilot-skills 分阶段开发计划

> 所属项目：`finance-copilot-skills`
> 文档版本：v0.1　｜　编制日期：2026-08-04　｜　状态：待评审
> 上游文档：[Finance-Copilot-Skills-PRD-v0.2](../prd/Finance-Copilot-Skills-PRD-v0.2.md)
> 对应交付项：PRD §10.5 后续文档清单最后一项「分阶段开发计划」
> 基线版本：**0.2.2**（2026-08-04 发布，`fcs-reconcile` 单 Skill，92 项测试全绿）

---

# 一、结论先行

| 问题 | 结论 |
|---|---|
| 下一个版本做什么 | **v0.3.0「参考实现转正」：清 P0 欠账**，不做第二个 Skill。 |
| 为什么不按路线图先做第二个 Skill | PRD §六把 FT-11 的 Codex / Claude Code 列为 **P0**（「缺则产品不成立或不安全」），至今 `platforms.verified` 为空；独立前向测试仍 `pending`；FT-03 的触发测试目录只有 `.gitkeep`。**P0 未清就扩品类，等于在未验证的地基上加层。** 依据 PRD §1.2「严谨性一票否决」。 |
| 最硬的一条现实 | **本项目当前不满足自己定的发布门禁。** [tools/release/README.md](../../tools/release/README.md) 写明发布前置为「自动化测试 100% 通过 + `tools/verify` 安全基线通过 + 独立前向测试通过」，后两项一项都没有，而 v0.1.0~v0.2.2 四个版本已经发出去了。v0.3.0 的首要目的就是让门禁与事实重新对齐。 |
| 路线图要不要改 | 要。原 v0.3~v0.5 各顺延一位，PRD §8.3 须回改（这是第二次顺延，依据 [versioning.md](../governance/versioning.md) §6「路线图是计划、CHANGELOG 是事实」）。 |

---

# 二、现状基线与欠账盘点

## 2.1 已完成（截至 0.2.2）

| 版本 | 主题 | 落地物 |
|---|---|---|
| v0.1.0 | 安全底座与对账参考实现 | `fcs-reconcile` 13 个平铺模块 933 行；7 张中文工作表；运行清单；unit / property / golden / security 四类测试 |
| v0.2.0 | 多代理安装与版本统一 | 三段中文安装提示词；[安装矩阵](../governance/agent-install.md)路径表 + 9 项验证项清单；[四层版本规划](../governance/versioning.md) + 2 个漂移守卫 |
| v0.2.1 | 质量门禁清零 | `ruff` / `mypy strict` / `pytest` 全绿；补打 `v0.1.0` tag |
| v0.2.2 | 许可证 | MIT；PRD §10.4 ①②④ 结案 |

## 2.2 欠账逐项盘点（对照 PRD 编号）

**图例**：❌ 未做　｜　🟡 部分做了但不完整　｜　⏳ 有外部依赖，非纯工程

### P0（PRD §六定义：缺则产品不成立或不安全）

| 项 | 状态 | 事实依据 | 归属阶段 |
|---|:---:|---|:---:|
| **FT-11 · Codex + Claude Code 逐项正式验证** | ❌ | `SKILL_META.yaml` `platforms.verified: []`；[agent-install.md](../governance/agent-install.md) §4 的 9 项验证项 × 2 平台 = 18 项，一项未测 | ⏳ A |
| **独立前向测试**（§10.1） | ❌ | `SKILL_META.yaml` `tests.forward: pending` | ⏳ A |
| **FT-03 · 触发 / 非触发 / 相邻 Skill 测试** | ❌ | `tests/triggering/` 只有 `.gitkeep` | A |
| **NFR-05 · 逐单元格可重复性守卫** | 🟡 | `tests/golden/expected/` 只有 `.gitkeep`。黄金答案目前是 `test_e2e_golden.py` 里内联的 summary 计数断言，**结果工作簿与运行清单的逐单元格期望值并未落盘** | A |
| **§9 安全硬目标的工具集级校验** | 🟡 | Skill 级 `tests/security/` 有 2 个用例；但 `tools/verify/run.py` 仍是骨架，CI 的 `security-baseline` job 是 `echo` 占位 | A |

> **FT-04 / FT-05 / FT-06 / FT-07 / FT-08 / FT-09 与 NFR-01~NFR-06 已在 v0.1 落地**，
> 由 `guard.py` / `integrity.py` / `manifest.py` / `reporter.py` 与 92 项测试覆盖，不在欠账内。

### P1

| 项 | 状态 | 事实依据 | 归属阶段 |
|---|:---:|---|:---:|
| §7.2 软件供应链：依赖哈希 | ❌ | `requirements.txt` 由 `uv export --no-hashes` 生成，文件头自陈「正式发布时改由 tools/build 导出并附带哈希」 | A（前置）/ B |
| §7.2：SBOM、发布包 SHA-256、发布签名 | ❌ | `tools/build` / `tools/release` 均只有 README | B |
| §10.2 漏洞响应：联系人、渠道、分级、时限 | ❌ | [SECURITY.md](../../SECURITY.md) 四处「待定」 | A（成本极低） |
| FT-02 · 独立安装的发布包形态 | 🟡 | 提示词安装可用；`dist/<skill>/` 自包含打包未实现 | B |
| FT-01 · Skill 目录（catalog） | 🟡 | 各 Skill 有 `SKILL_META.yaml`，缺汇总生成 | E |
| FT-10 · 用户反馈机制 | ❌ | 未做，且卡在 PRD §10.4 ⑤「由谁维护」 | E（待决策解锁） |
| FT-11 · P1 平台（Copilot / Cursor / Gemini CLI） | ❌ | — | D |
| NFR-07 · 公共组件可复用性验证 | ❌ | `packages/` 为空（有意的生长点）。**需要第 2 个 Skill 才能验证** | C |
| `tools/new-skill/create.py` | ❌ | 骨架待实现 | C（前置） |

### 未决策项（PRD §10.4，会阻塞对应阶段）

③ 免费范围是否含永久更新　⑤ 反馈入口由谁维护　⑥ 是否提供完全离线安装包　⑦ 首批正式支持哪些操作系统　⑧ 哪些平台正式支持 / 仅兼容　⑨ 是否接受社区贡献 Skill　⑩ 若接受由谁审核　⑪ 咨询服务与免费工具集如何隔离

**阻塞关系见 §五决策门。**

---

# 三、阶段划分

```text
A  v0.3.0  P0 欠账清零，参考实现转正        ← 下一个版本，本文档展开到任务级
│          Experimental → Preview
├─ B  v0.4.0  供应链与发布加固
│  └─ C  v0.5.0  第二个财务 Skill          ← 原路线图 v0.3，顺延
│     ├─ D  v0.6.0  跨平台扩展              ← 原路线图 v0.4，顺延
│     └─ E  v0.7.0  工具集治理              ← 原路线图 v0.5，顺延
└──────── F  v1.0.0  稳定免费工具集
```

**依赖说明**：B 依赖 A（`tools/verify` 是 `tools/release` 的前置门禁）；C 依赖 A（PRD §8.3 原文：第二个 Skill 的前置是「第一个 Skill 完成真实用户验证」）；D、E 依赖 C（跨平台矩阵与 Skill 目录在多 Skill 下才有意义）。B 与 C 之间无强依赖，若 C 的真实用户验证需要等待，B 可先行。

## 3.1 路线图顺延声明

| 原路线图（PRD §8.3） | 本计划 | 说明 |
|---|---|---|
| — | **v0.3 P0 欠账清零** | 新插入 |
| — | **v0.4 供应链与发布加固** | 从原 v0.4「跨平台分发」中拆出供应链部分独立 |
| v0.3 第二个财务 Skill | v0.5 | 顺延一位 |
| v0.4 跨平台分发 | v0.6 | 顺延；其中「Codex / Claude Code 正式验证」部分**提前到 v0.3** |
| v0.5 工具集治理 | v0.7 | 顺延一位 |
| v1.0 稳定免费工具集 | v1.0 | 不变 |

> 这是继 v0.2 之后的**第二次顺延**。versioning.md §6 已规定处理方式：以 CHANGELOG 为准并回改路线图。
> **主题内容未改，只改编号**——阶段 A8 须回改 PRD §8.3 表格并保留本说明。

---

# 四、阶段 A（v0.3.0）任务级展开

**目标**：把 P0 欠账清零，使 `fcs-reconcile` 满足自身定义的发布门禁，发布状态由 `Experimental` 升 `Preview`。

**退出条件**（缺一不可）：

> ⚠ 第一条已于 2026-08-11 按 §4.0 的降级决定修订：`tests.forward` 记为 `self-tested`
> 而非 `passing`，`verified` 依据「使用验证」而非逐项走查。**原文保留在下方删除线中**，
> 因为它记录的是当初的标准——改的是本次发布的判据，不是把标准改掉当作从未存在。

- `SKILL_META.yaml`：`platforms.verified: [claude-code, codex]`、~~`tests.forward: passing`~~ → `tests.forward: self-tested`、`status: Preview`
- `tools/verify/run.py` 5 项校验全通过，且在 CI 的 `security-baseline` job 中真实执行（非占位）
- `tests/triggering/` 与 `tests/golden/expected/` 不再是空目录
- `uv run ruff check . && uv run mypy . && uv run pytest` 全绿
- 按 [versioning.md](../governance/versioning.md) §5 完成七步发布（含 GitHub Release）

## 4.0 执行进度（2026-08-04 更新）

| 任务 | 状态 | 提交 | 与计划的偏差 |
|---|:---:|---|---|
| A0 漏洞报告渠道 | ✅ 文档部分完成 | `4645763` | ⚠ **PVR 未开启**，需 owner 权限，见 §八交接 |
| A1 触发边界守卫 | ✅ | `b8e950e` | 无。9 项守卫，5 条负路径实测 |
| A2 逐单元格黄金答案 | ✅ | `81bbc19` | 无。3 条负路径实测 |
| A3 依赖哈希 | ✅ | `6f96797` | **提前到 A0 之前执行**——A0 的供应链状态表要写"依赖哈希 ✅"，得先让它为真 |
| A4 安全基线 + CI | ✅ | `fa5f7fc` | **5 项变 6 项**（加「执行成功」前置）；`checks/` 目录改单文件 `checks.py`，6 个函数不值得包化 |
| A5 独立前向测试 | ⚠ **降级结案** | `A8` | **未执行**。`tests.forward` 记为 `self-tested` 而非 `passing`，见下 |
| A6 Claude Code 实测 | ⚠ **降级结案** | `A8` | 未做 9 项逐项走查，改以「使用验证」填入 `verified` |
| A7 Codex 实测 | ⚠ **降级结案** | `A8` | 同 A6 |
| A8 状态升级与发布 | ✅ | `A8` | 已解除阻塞，见下 |

**门禁现状**：`ruff` / `mypy strict` / `pytest` / `tools/verify --all`（6/6）全绿。

### A5~A7 的降级决定（2026-08-11）

**决定**：项目维护者判断多项目实际使用已构成足够证据，**不再把逐项走查与独立前向测试
作为 0.3.0 的发布卡点**。A8 照常执行。

**这不是把没做的事记成做了**——三项的实际状态如实落在了四个地方：

| 位置 | 如实记的内容 |
|---|---|
| `SKILL_META.yaml` | `forward: self-tested`（**不是** `passing`） |
| `tests/cross_platform/records/` | 两份记录，逐项标注证据来源，未确认项单独列出待补测清单 |
| `CHANGELOG` 已知限制 | 第 1、2 条 |
| README（中英） | 支持级别分档表格 + `Preview` 状态说明 |

**未覆盖的是同一组 3 项**（两个平台一致）：权限确认、运行期网络拦截、错误处理。
它们的共同点是**只在异常分支出现**，日常对账永远走不到——这正是「使用验证」与
「逐项走查」的实质差别，不是严格程度之差，是覆盖面之差。

**A5 与 A6/A7 的性质不同，不可混为一谈**：A6/A7 缺的是"没构造异常场景"，补做即可；
A5 缺的是**执行者身份**——PRD §10.1 定义前向测试为"不预知答案的独立执行者"，开发者
越熟悉这个 Skill 就越不能代表陌生用户。**这一条不会因为多用几次而被满足**，只能靠
换人执行。所以 `forward` 用了 `self-tested` 这个新取值，而不是 `passing`。

**守卫相应改写**：`test_verified_platforms_stay_empty_until_matrix_verified` →
`test_verified_platforms_have_records`（凭记录放行）+ 新增
`test_verification_records_declare_their_level`（记录须自陈等级）。
⚠ 机器只能检查记录**存在**且等级**已填**，检查不了记录**说得实不实**——
这一层由 `records/README.md` 的书面约定承担，不再有机器兜底。

### 执行中发现的新事实

1. **xlsx 输出字节不可重复**。跨进程隔 3 秒的两次运行，输出文件 SHA-256 会分叉
   （zip 条目时间戳 + `docProps/core.xml` 创建时间）；同进程内快速两次一致只是被秒级
   精度掩盖。含义：NFR-05 的「相同输入产生相同结果」在**内容级**成立、**字节级**不成立，
   运行清单里 `outputs[].sha256` 只能用于事后防篡改（FT-06），不能用来判断两次运行结果
   是否相同。已钉成显式测试
   `test_workbook_bytes_are_not_reproducible_across_runs`。

2. **负路径注入必须先断言模式命中**。验证守卫时有两次注入因模式没匹配而"通过"
   （`guard._blocked` 实际带类型标注、sed 用了顿号而原文是逗号），差点把"注入没生效"
   误判成"校验器失效"。此后注入脚本一律先 `assert old in text` 再替换。

### A2 核对中发现的 3 处契约与实现偏差（未修，待定夺）

逐张核对快照时发现，**这些是既有偏差，不是本次引入的**。快照已钉住当前实现，
将来修任何一处都会让快照红——这正是它该有的行为。

| # | 偏差 | 依据 |
|---|---|---|
| ① | 结果工作簿的「隐私运行摘要」只复现 4 项（运行模式/原始数据进模型/网络访问/源文件修改），PRD §5.3 的运行前确认界面有 8 项，缺「将读取 N 个文件·写入 M 个」「终端输出交易明细」「临时文件」「输入完整性」 | PRD §5.3 要求"同一份字段在运行前展示、在结果中作为隐私运行摘要复现" |
| ② | 「运行参数」表只有 4 项（规则/契约版本、金额容差、日期容差），缺契约要求的输入路径、字段映射、文件哈希 | [output-contract.md](../contracts/fcs-reconcile/output-contract.md) §结果工作簿："运行参数 \| 复现所需 \| 输入、字段映射、配置、规则/契约版本、文件哈希" |
| ③ | 输出契约正文写「见下方 11 个复核字段」，实际列了 12 个 | 同上，文档笔误 |

③ 是文档笔误，随手可改。①② 是实现缺字段，**修它们会改变结果工作簿的内容**——
按 [versioning.md](../governance/versioning.md) §3 属"契约新增可选字段（向后兼容）"，
应 bump `contract_version` 到 `1.1`。建议并入 A8 一起做，或单列为 A9；不建议留到阶段 B，
因为 A8 发布时若不修，就得在 CHANGELOG 的已知限制里写明这三条。

## 4.0.1 门禁减负（2026-08-04 追加，计划外）

**起因**：新增 Skill 的交付负担过重，不适合前期快速迭代。

**诊断**：摩擦不在速度上（全量门禁本地 1.6s、CI 17s），在**连带修改面**——新增一个
Skill 触发 27 条守卫、要碰 10 个位置；FT-12 十项被当成了开工门槛。

**处置原则**：区分「标准严格」与「操作繁琐」。前者是产品立身之本，后者该用工具消除。
放松守卫会让"版本号漂移只体现在审计证据里""安装路径写错时技能一个都不出现且无报错"
这类问题重新变得不可发现——那正是这些守卫存在的理由。

| 做法 | 内容 |
|---|---|
| **补工具**（不动任何标准） | 实现 `tools/new-skill/create.py`（本就在规划中、一直未落地）。一条命令生成骨架 + 追加 corpus 节 + 导出带哈希依赖，**跑完 47 条守卫全绿、零手工修改** |
| **状态分级** | FT-12 十项拆成 Experimental / Preview / Stable 三段（[CONTRIBUTING.md](../../CONTRIBUTING.md)）。Experimental 阶段不要求 PRD、契约、技术设计、ADR、前向测试、README 点名 |
| **判据改进** | 「是否对外可安装」由 `platforms.compatible` 是否非空判定，**不由发布状态判定**——`fcs-reconcile` 至今是 Experimental 却已对外安装，PRD §10.2 的 Experimental 只意味着"不承诺稳定"，与可否安装正交 |
| **双向守卫** | `compatible` 非空 → 必须进 README 提示词；为空 → 不得出现在提示词里。一个字段驱动两个方向，杜绝"声称可装却没写进安装说明"与其反面 |

**未放松的部分**：安全基线 6 项、确定性误判 0、黄金答案快照、金额 `Decimal`、
触发边界守卫。触发边界之所以不豁免——误触发会让用户在错误的 Skill 上处理财务数据，
是安全问题而非文档问题；且脚手架已把它的成本降为零。

**净效果**：新增一个 Skill 从「碰 10 个位置 + 满足 27 条守卫 + 交 FT-12 十项」
变为「一条命令 + 填 description 与语料 + 写实现」。

## 4.1 任务依赖与并行度

```text
A0 漏洞渠道 ─┐
A1 触发守卫 ─┤
A2 黄金答案 ─┼─→ A8 守卫改写 + 状态升级 + 发布
A3 依赖哈希 ─┤
      └→ A4 tools/verify ─┘
A5 前向测试 ⏳ ─┘
A6 Claude Code 实测 ⏳ ─┘
A7 Codex 实测 ⏳ ─┘
```

**A0~A4 是纯工程，可立即开始并行推进**（A4 依赖 A3 的带哈希 `requirements.txt`）。
**A5~A7 有外部依赖**——A5 需要一位不参与开发的测试者，A6/A7 需要在真实宿主里逐项操作。这三项决定阶段 A 的实际工期，**建议第一天就先启动 A5 的测试者约定**，不要排在最后。

---

### Task A0：漏洞报告渠道定稿

**为什么排第一**：仓库已有 4 个公开 GitHub Release，却没有任何私密漏洞报告渠道——研究者只能发公开 issue，等于强制 0-day 公开披露。成本约 10 分钟，收益是消除一个真实暴露。PRD §10.2 明确要求「安全联系人、私密漏洞报告渠道、严重程度分级、响应时间目标」。

**Files:**
- Modify: `SECURITY.md`
- Modify: `.github/`（新增 `SECURITY.md` 不必要，GitHub 会读根目录的）

- [ ] **Step 1: 开启 GitHub Private Vulnerability Reporting**

仓库 Settings → Code security and analysis → Private vulnerability reporting → Enable。
或：`gh api -X PUT repos/{owner}/{repo}/private-vulnerability-reporting`

- [ ] **Step 2: 填实 SECURITY.md 的四处「待定」**

替换 `## 漏洞报告` 与 `## 响应目标` 两节：报告渠道写明「GitHub Security Advisory 私密报告」并给出链接；安全联系人给出邮箱；响应时限填实际能承诺的值。

> **给值的原则：宁可承诺得保守，也不要写做不到的数字。** 这是单人维护的免费项目，
> 建议「严重/高：7 个自然日内确认，30 日内修复或给出缓解方案；中/低：30 日内确认」。
> 承诺 24 小时响应然后做不到，比承诺 7 天更伤信任。

- [ ] **Step 3: 提交**

```bash
git add SECURITY.md
git commit -m "docs(security): 漏洞报告渠道与响应时限定稿，PRD §10.2 结案"
```

---

### Task A1：触发语料与边界守卫（FT-03）

**Files:**
- Create: `tests/triggering/corpus.yaml`
- Create: `tests/triggering/test_trigger_boundary.py`
- Modify: `tests/README.md`（把 `triggering/` 的「占位」改为实际用例说明）

**先划清这个测试能守什么、不能守什么**——这决定它是真守卫还是自欺：

| | 谁来验 |
|---|---|
| 「自然语言 X 会不会真的唤起本 Skill」 | **宿主行为，pytest 无法断言**。归 FT-11 第 3 项，由 A6 / A7 人工实测 |
| 「SKILL.md 的 `description` 是否覆盖了声称支持的场景、是否明确排除了不支持的场景」 | **本任务**。这是可机器化的部分 |

> 写一个假装能测触发的 pytest（比如用关键词匹配模拟宿主路由）比不写更糟——
> 它会让 `tests.triggering` 显示 passing，掩盖真实的 FT-11 缺口。

**Interfaces:**
- `corpus.yaml` 结构：

```yaml
# 触发边界语料。新增 Skill 时在此追加一节，不改测试代码。
fcs-reconcile:
  should_trigger:            # 应命中的真实用户说法
    - 帮我核对银行流水和收付款台账
    - 应收账款和回款对不上，帮我找差异
    - 两个系统的交易明细核对一下
  should_not_trigger:        # 不应命中，且须能说出该归谁
    - {text: 帮我把这张表的日期格式统一了, belongs_to: fcs-clean}
    - {text: 生成一份月度管理报表,         belongs_to: fcs-report}
    - {text: 这笔业务要不要交增值税,       belongs_to: 不做（PRD §2.5 税务结论）}
    - {text: 登录网银把流水下载下来,       belongs_to: 不做（PRD §2.5 自动登录）}
  boundary_keywords:         # description 中必须出现的边界词
    must_contain: [对账, 核对, 差异, 本地隔离, 禁网]
    must_exclude_scope: [凭证过账, 报表生成, 税务判断]
```

- [ ] **Step 1: 写失败测试**

`tests/triggering/test_trigger_boundary.py` 断言四条：

1. 每个 `skills/*/SKILL_META.yaml` 在 `corpus.yaml` 里都有对应节（新增 Skill 不写语料就红）；
2. `SKILL.md` frontmatter 的 `description` 含全部 `must_contain` 词；
3. `description` 或正文「不应触发」段落含全部 `must_exclude_scope` 词；
4. 每条 `should_not_trigger` 的 `belongs_to` 要么是已存在的 Skill 名，要么以「不做」开头并引用 PRD 条款——**防止边界被写成一句无处可去的空话**。

- [ ] **Step 2: 运行确认失败**

```bash
uv run pytest tests/triggering/ -v          # Expected: FAIL（corpus.yaml 不存在）
```

- [ ] **Step 3: 建 corpus.yaml 与测试实现，跑通**

```bash
uv run pytest tests/triggering/ -v          # Expected: PASS
```

- [ ] **Step 4: 更新 tests/README.md 表格中 `triggering/` 一行的「当前用例」**

- [ ] **Step 5: 提交**

```bash
git add tests/triggering/ tests/README.md
git commit -m "test(triggering): FT-03 触发边界语料与守卫，明确区分可机器化部分与 FT-11 人工实测"
```

---

### Task A2：结果工作簿逐单元格黄金答案（NFR-05）

**Files:**
- Create: `skills/fcs-reconcile/tests/golden/expected/result.snapshot.json`
- Create: `skills/fcs-reconcile/tests/golden/expected/manifest.snapshot.json`
- Modify: `skills/fcs-reconcile/tests/golden/test_e2e_golden.py`
- Create: `skills/fcs-reconcile/tests/golden/regen_snapshots.py`

**为什么必须做**：[engine-plan](2026-07-23-fcs-reconcile-engine-plan.md) 的 Global Constraints 写的是「相同输入 + 配置 + `rule_version` → **逐单元格一致**结果」，PRD NFR-05 同义。当前测试只断言了 8 个 summary 计数与两个勾稽布尔值——**reporter 把某列写错顺序、把「判断依据」文案改掉、少写一张表，现有测试全都不会红**。这是 92 项测试里最大的一处覆盖空洞。

**Interfaces:**
- `regen_snapshots.py`：跑一次对账 → 把 xlsx 7 张表读成 `{sheet: [[cell,...],...]}`、把 manifest 读成 dict → 剔除易变字段（`run_id`、`run_at`、绝对路径、`input_files[].path`）→ 写 JSON。**只在规则或契约版本有意变更时手动执行**。
- `test_e2e_golden.py` 新增两个用例：`test_workbook_matches_snapshot`、`test_manifest_matches_snapshot`。

- [ ] **Step 1: 写快照对比测试（先失败）**

```python
def test_workbook_matches_snapshot(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """逐单元格比对，任何一格变化都要求显式重生成快照（NFR-05）。"""
    ...
    actual = _dump_workbook(out)            # {sheet_name: [[cell, ...], ...]}
    expected = json.loads((HERE / "expected" / "result.snapshot.json").read_text("utf-8"))
    assert actual == expected               # 失败时 pytest 会指出具体是哪张表哪一格
```

- [ ] **Step 2: 运行确认失败**

```bash
uv run pytest skills/fcs-reconcile/tests/golden/ -v   # Expected: FAIL（快照文件不存在）
```

- [ ] **Step 3: 实现 `regen_snapshots.py` 并生成快照**

```bash
uv run python skills/fcs-reconcile/tests/golden/regen_snapshots.py
```

- [ ] **Step 4: 人工逐张核对快照内容**

⚠ **这一步不能跳。** 快照测试的价值全部建立在「首次生成的快照是对的」之上；
若首次快照本身就带 bug，测试会把 bug 钉死为期望值。逐张检查 7 张表的表头、
状态用词、优先级、判断依据文案是否与[输出契约](../contracts/fcs-reconcile/output-contract.md)一致。

- [ ] **Step 5: 跑通并确认确定性**

```bash
uv run pytest skills/fcs-reconcile/tests/golden/ -v   # Expected: PASS
uv run pytest skills/fcs-reconcile/tests/golden/ -v   # 再跑一次，仍 PASS（无易变字段泄漏）
```

- [ ] **Step 6: 在 `regen_snapshots.py` 顶部写明重生成的前置条件**

「只有当 `rule_version` 或 `contract_version` 有意 bump 时才重生成，且必须在 PR 描述里
说明每一处差异的来源。因回归失败而重生成快照 = 掩盖回归。」

- [ ] **Step 7: 提交**

```bash
git add skills/fcs-reconcile/tests/golden/
git commit -m "test(golden): 结果工作簿与运行清单逐单元格快照，补齐 NFR-05 可重复性守卫"
```

---

### Task A3：`requirements.txt` 带哈希导出

**Files:**
- Modify: `skills/fcs-reconcile/requirements.txt`
- Create: `tests/supply_chain/test_requirements_hashes.py`

**为什么在阶段 A 而不在阶段 B**：A4 的 `tools/verify` 有一项校验是「依赖哈希校验」，没有哈希这一项就跑不了。只做「导出带哈希」这一件，SBOM / 签名 / 发布包留阶段 B。

- [ ] **Step 1: 导出带哈希清单**

```bash
uv export --no-dev --no-emit-project --format requirements-txt \
  -o skills/fcs-reconcile/requirements.txt
```

保留文件头注释，把「正式发布时改由 tools/build 导出并附带哈希」改为已落地的说明。

- [ ] **Step 2: 补守卫测试**

`tests/supply_chain/test_requirements_hashes.py` 断言：每个非注释、非空行的依赖都带 `--hash=sha256:`；`requirements.txt` 里的包名与版本集合 ⊆ `uv.lock`。**防的是「改了 uv.lock 忘了重导出」的漂移**，与已有两个漂移守卫同类。

- [ ] **Step 3: 跑通**

```bash
uv run pytest tests/supply_chain/ -v        # Expected: PASS
```

- [ ] **Step 4: 验证离线可安装**

```bash
python -m venv /tmp/fcs-offline && /tmp/fcs-offline/bin/pip install \
  --require-hashes -r skills/fcs-reconcile/requirements.txt
```

> 注意 `numpy` 按 `python_full_version` 分叉（<3.12 取 2.4.6、≥3.12 取 2.5.1），
> 两个分支的哈希都要在清单里，否则换 Python 版本安装会失败。这与 CI 固定 3.11 是同一个坑
> （见 [ci.yml](../../.github/workflows/ci.yml) 注释）。

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/requirements.txt tests/supply_chain/test_requirements_hashes.py
git commit -m "feat(supply-chain): requirements.txt 带依赖哈希导出并加漂移守卫"
```

---

### Task A4：`tools/verify` 安全基线实现 + CI 启用

**Files:**
- Create: `tools/verify/run.py`
- Create: `tools/verify/checks/` （5 个校验模块）
- Modify: `.github/workflows/ci.yml`
- Modify: `tools/verify/README.md`（去掉「骨架待实现」）

**与 Skill 级 `tests/security/` 的分工**（不是重复造轮子）：

| | 定位 |
|---|---|
| `skills/<skill>/tests/security/` | **白盒单元级**：直接 import `guard` / `integrity`，断言函数行为 |
| `tools/verify/run.py` | **黑盒工具集级**：对任意 `skills/<skill>/` 跑，只看外部可观测证据（进程有无出站连接、日志文件内容、源文件哈希、产物清单）。新增 Skill 时无需改代码即可纳入校验 |

**Interfaces:**
- `run.py --skill <name>` / `--all`；任一校验失败 → 非零退出码 + 中文失败原因（不含单元格内容）。
- 5 项校验（对应 [PRD §9](../prd/Finance-Copilot-Skills-PRD-v0.2.md) 安全硬目标）：

| # | 校验 | 判据 | 实现要点 |
|---|---|---|---|
| 1 | 网络隔离 | 未授权网络请求 = 0 | 用 socket 层探针包裹一次真实 demo 运行，断言零次出站 `connect` |
| 2 | 日志泄露 | 敏感数据泄露 = 0 | 捕获 stdout/stderr 与日志文件，用 demo 数据里的编号 / 金额 / 对方名称做**反向查找**（这些值必须一个都不出现） |
| 3 | 源文件完整性 | 非预期修改 = 0 | 运行前后对全部输入求 SHA-256 |
| 4 | 依赖哈希 | 未锁定 / 高危依赖 = 0 | 校验 `requirements.txt` 全部带 hash（依赖 A3）；高危漏洞扫描**本阶段只报告不阻断**，理由见下 |
| 5 | 运行清单完整性 | 完整率 = 100% | manifest 必备字段齐全，且**不含**交易明细字段 |

> **第 4 项的漏洞扫描为什么先不阻断**：漏洞库要联网拉取，会让 CI 结果随外部数据源变化而
> 波动（今天绿明天红，代码一行没改）。阶段 A 先输出报告，阶段 B 随 SBOM 一起定阻断策略。
> **这个「先不阻断」必须写进 CHANGELOG 已知限制**，不能只留在代码注释里。

- [ ] **Step 1: 实现 5 个校验模块 + `run.py` 编排**

- [ ] **Step 2: 本地跑通**

```bash
uv run python tools/verify/run.py --skill fcs-reconcile   # Expected: 5/5 通过，退出码 0
```

- [ ] **Step 3: 构造负路径，确认能真的挡住**

⚠ **这一步不能跳**——一个永远返回通过的校验器比没有校验器更危险。逐项验证：

```bash
# 临时改 guard.block_network 为 no-op → 校验 1 必须失败
# 临时在 reconcile 里 print 一个真实金额 → 校验 2 必须失败
# 临时删掉 requirements.txt 的一行 hash → 校验 4 必须失败
```

- [ ] **Step 4: CI 启用**

`.github/workflows/ci.yml` 的 `security-baseline` job：删掉 `Placeholder` 步骤，改为

```yaml
      - name: Sync deps (locked + hashes)
        run: uv sync --frozen
      - name: Security baseline
        run: uv run python tools/verify/run.py --all
```

> 该 job 当前缺 `uv sync` 步骤（占位阶段用不上），改真跑时必须补，否则 `uv run` 会现装依赖。

- [ ] **Step 5: 提交并确认 CI 双 job 全绿**

```bash
git add tools/verify/ .github/workflows/ci.yml
git commit -m "feat(verify): 安全基线 5 项校验实现并在 CI 中启用，替换占位步骤"
```

---

### Task A5 ⏳：独立前向测试

**Files:**
- Create: `skills/fcs-reconcile/tests/forward/README.md`（测试包说明）
- Create: `skills/fcs-reconcile/tests/forward/任务书.md`（交给测试者，**不含答案**）
- Create: `skills/fcs-reconcile/tests/forward/2026-08-XX-report.md`（结果记录）

**外部依赖**：需要一位**不参与开发**的执行者。PRD §10.1 原文：「测试者只获得 Skill 目录、原始任务、测试文件与平台环境，**不得**提前知道预期答案与开发者已知问题。」

**测试者资格与信息隔离**（这是本任务最容易做废的地方）：

- 执行者不得读过 `docs/design/`、`docs/contracts/`、`tests/golden/`、本计划；
- 任务书用财务业务语言描述目标（「核对这两份表，找出对不上的地方」），**不得**提示状态名、工作表结构、字段映射方式；
- 已知限制（如「容差不放宽自动确认」）**不提前告知**——测试者是否会因此困惑，本身就是要观测的结果；
- 全程只允许问「我该点哪里」类操作问题，不允许问「这个结果对不对」。

**准备物**：一组与 `tests/golden/inputs/` **不同**的脱敏数据（复用黄金答案数据等于测试者在验证一个已被守卫的路径），覆盖：正常匹配、金额差异、单边、重复编号、多候选冲突、数据质量问题六类。可基于 `examples/gen_reconcile_demo.py` 改造。

- [ ] **Step 1: 约定测试者与时间**（**第一天就做，不要排在最后**）

- [ ] **Step 2: 造前向测试数据集（与 golden 不同）**

- [ ] **Step 3: 写任务书**（业务语言、无答案、无已知限制）

- [ ] **Step 4: 执行并记录**

记录项：能否独立完成、耗时、卡在哪一步、有无误解结果含义、有无把「疑似匹配」当成「已匹配」、
最终结果是否正确、对输出可理解性打分（PRD §9 指标「结果可理解性 ≥ 4/5」）。

- [ ] **Step 5: 归档报告并更新元数据**

```yaml
# SKILL_META.yaml
tests:
  forward: passing        # 或 failing —— 失败就是失败，据实记录并转 issue
```

> **前向测试失败不是阶段 A 的失败，是它的产出。** 若测试者卡住或误读结果，
> 修完再测比记一句 passing 有价值得多。这种情况下 A8 的发布顺延，不放宽结论。

- [ ] **Step 6: 提交**

```bash
git add skills/fcs-reconcile/tests/forward/ skills/fcs-reconcile/SKILL_META.yaml
git commit -m "test(forward): 独立前向测试执行与报告归档，tests.forward 转 passing"
```

---

### Task A6 ⏳：FT-11 · Claude Code 9 项逐项实测

**Files:**
- Create: `tests/cross_platform/records/claude-code-0.3.0.md`

**执行环境**：干净的 Claude Code 会话，按 README 的 Claude Code 段提示词安装到 `~/.claude/skills/`，**新开会话**后开始（已开会话不重扫 skills 目录，见 [agent-install.md](../governance/agent-install.md) §6）。

**逐项判据取自 [agent-install.md](../governance/agent-install.md) §4，不重述**。记录格式每项四栏：`验证项 | 实际操作 | 观测结果 | 通过/失败`。

- [ ] **Step 1: 按提示词安装，记录是否有歧义或缺步**
- [ ] **Step 2~10: 逐项执行 9 项验证并记录**（第 3 项「自动触发」用 A1 `corpus.yaml` 的 `should_trigger` 语料逐条测，并用 `should_not_trigger` 语料确认不误触发）
- [ ] **Step 11: 归档记录**

> **9 项全过才算该平台正式验证。** 任一项失败 → 记录失败详情、开 issue、修复后重测，
> **不得**部分通过就填进 `platforms.verified`。这正是 `test_verified_platforms_stay_empty_until_matrix_verified`
> 那条守卫在保护的东西。

```bash
git add tests/cross_platform/records/claude-code-0.3.0.md
git commit -m "test(cross-platform): Claude Code FT-11 九项验证记录"
```

---

### Task A7 ⏳：FT-11 · Codex 9 项逐项实测

同 A6，目标目录 `~/.codex/skills/`，产出 `tests/cross_platform/records/codex-0.3.0.md`。

**预期差异点**（提前想清楚，避免把平台差异误判为缺陷）：Codex 的权限确认交互与 Claude Code 不同（对应验证项 6）；Python 解释器选择方式不同（验证项 5，注意 agent-install.md §5 的「装依赖的解释器必须与运行 Skill 的解释器是同一个」）。

```bash
git add tests/cross_platform/records/codex-0.3.0.md
git commit -m "test(cross-platform): Codex FT-11 九项验证记录"
```

---

### Task A8：守卫改写、状态升级与 v0.3.0 发布

**前置**：A0~A7 全部完成且全部通过。

**Files:**
- Modify: `tests/cross_platform/test_install_paths.py` ⚠ **会挡住发布，必须先改**
- Modify: `skills/fcs-reconcile/SKILL_META.yaml`
- Modify: `pyproject.toml`、`skills/fcs-reconcile/scripts/version.py`、`skills/fcs-reconcile/SKILL.md`
- Modify: `CHANGELOG.md`、`skills/fcs-reconcile/CHANGELOG.md`
- Modify: `docs/prd/Finance-Copilot-Skills-PRD-v0.2.md` §8.3、`docs/governance/agent-install.md` §3、`README.md`、`README.en.md`

- [ ] **Step 1: 改写平台验证守卫**

`test_verified_platforms_stay_empty_until_matrix_verified()`（[test_install_paths.py:105](../../tests/cross_platform/test_install_paths.py#L105)）当前**无条件**断言 `verified` 为空。改为「每个填进 `verified` 的平台，`tests/cross_platform/records/` 下必须有对应记录文件」——守卫的意图不变（不许无据自称已验证），只是从「一律禁止」升级为「凭证据放行」。函数名一并改为 `test_verified_platforms_have_records`。

同时复核 `test_readme_does_not_overclaim_verification()`：它断言 README 必含「格式兼容」。WorkBuddy 仍是格式兼容，该断言继续成立，但 README 措辞需区分两档，不能再一句话说三家都是格式兼容。

- [ ] **Step 2: 更新 `SKILL_META.yaml`**

```yaml
skill_version: "0.3.0"
status: Preview                          # Experimental → Preview
platforms:
  verified: [claude-code, codex]
  compatible: [workbuddy]                # ⚠ 已有守卫断言 compatible 恰为三家，须同步改
tests:
  forward: passing
```

> **为什么是 Preview 不是 Stable**：PRD §10.2 定义 Stable = 「契约稳定，完成正式测试」。
> 正式测试完成了，但「契约稳定」需要真实用户跑过至少一个业务周期来证明——
> 那是阶段 C 的前置工作。**这里不抢跑一级。**

- [ ] **Step 3: 版本号六处同步至 0.3.0**

`pyproject.toml`、`SKILL_META.yaml`、`scripts/version.py`、`SKILL.md`、根 `CHANGELOG.md`、Skill `CHANGELOG.md`（漂移守卫会逐条断言）。

- [ ] **Step 4: 写 CHANGELOG（两份）**

按 versioning.md §5 第 3 步记录：Skill / 规则 / 契约 / 依赖版本、支持平台、安全测试状态、已知限制、回滚版本。

**已知限制必须写进去的三条**：① SBOM、发布包签名与 SHA-256 未落地（阶段 B）；② `tools/verify` 的依赖漏洞扫描只报告不阻断；③ WorkBuddy 仍为格式兼容。

**`rule_version` 与 `contract_version` 均不变**（本版不改任何对账行为），须明写「相同输入的对账结果与 0.2.x 完全一致」。

- [ ] **Step 5: 回改上游文档**

| 文件 | 改什么 |
|---|---|
| PRD §8.3 | 路线图表格按本文档 §3.1 顺延，保留顺延说明（这是第二次） |
| PRD §10.4 | 若 A0 一并明确了安全联系人，相关待办结案 |
| agent-install.md §3 | 「当前三家均为格式兼容，`platforms.verified` 为空」→ 改为两家已正式验证、WorkBuddy 仍格式兼容 |
| README.md / README.en.md | 支持级别分两档表述；`fcs-reconcile` 状态 Experimental → Preview |
| tests/README.md | `triggering/` 与 `cross_platform/` 的用例列更新 |

- [ ] **Step 6: 全量门禁**

```bash
uv run ruff check . && uv run mypy . && uv run pytest
uv run python tools/verify/run.py --all
```

- [ ] **Step 7: 发布（versioning.md §5 七步，一步都不少）**

```bash
git tag -a v0.3.0 -m "v0.3.0 — P0 欠账清零，fcs-reconcile 转 Preview"
git push origin main --tags
gh release create v0.3.0 --verify-tag --latest \
  --title "v0.3.0 — P0 欠账清零，参考实现转 Preview" --notes-file <notes.md>
```

> **tag 不等于 Release**（versioning.md §5 第 6 步 / §7）。正文相对链接须改写为指向 `v0.3.0` 的绝对 URL。

---

# 五、阶段 B~F 概要

> 展开到任务级的时机：**该阶段的前一个阶段发布后**。提前展开会基于过时假设。

## 阶段 B · v0.4.0 供应链与发布加固

**目标**：让「正式版本」这四个字有可核验的含义（PRD §7.2）。

| 交付物 | 说明 |
|---|---|
| `tools/build/build.py` | `skills/<skill>/` → `dist/<skill>/` 自包含包；剥离 `tests/`；`packages/` 为空时 vendor 步骤 no-op |
| SBOM | 每个发布包一份（CycloneDX 或 SPDX，二选一并记 ADR） |
| 发布包 SHA-256 + 签名 | `tools/release/release.py`；签名方案（GPG / Sigstore）须记 ADR |
| 依赖漏洞阻断策略 | 把 A4 第 4 项从「只报告」转为「按严重度阻断」 |
| `tools/release` 前置门禁自动化 | 把「测试 100% + 安全基线 + 前向测试」三条做成脚本检查，而非人工记忆 |

**退出条件**：`dist/fcs-reconcile/` 可在干净机器上离线安装并跑通；发布产物含 SBOM、哈希、签名；三条前置门禁由脚本校验。

**决策门**：PRD §10.4 ⑥「是否提供完全离线安装包」——影响 `tools/build` 是否需要打包 wheel 依赖。**阶段 B 启动前必须决。**

## 阶段 C · v0.5.0 第二个财务 Skill

**前置（PRD §8.3 原文）**：第一个 Skill 完成**真实用户验证**。注意这与阶段 A 的前向测试不是一回事——前向测试是「陌生人能否用对」，真实用户验证是「财务人员在真实业务周期里是否愿意重复使用」（PRD §9：次业务周期重复使用率 ≥ 60%）。

**候选**：`fcs-clean` 或 `fcs-check`，**按真实需求验证结果二选一**，不预先锁定。
[fcs-invoice-check 需求调研](2026-08-04-fcs-invoice-check-demand-research.md) 已给出一个反面样本——线索来自营销软文、无具体用户，因此**存档不立项**。同一把尺子用于本阶段选型。

**连带触发**（[CONTRIBUTING.md](../../CONTRIBUTING.md) 提交清单 + [versioning.md](../governance/versioning.md) §3.2）：

- 按 versioning.md §3.2 **解耦 `skill_version`** 与工具集版本；
- 删除 `tests/supply_chain/test_version_consistency.py::test_single_skill_stage_versions_are_aligned`；
- README 三段安装提示词点名新 Skill 并修正「当前 N 个」（`test_prompts_cover_every_installable_skill` 会挡住漏改）；
- `tools/new-skill/create.py` 需先实现（否则骨架靠手抄，必然漂移）。

**退出条件**：新 Skill 走完 FT-12 十项交付；`packages/` 是否新增共享库有明确结论（**NFR-07 的真正检验点**——若两个 Skill 之间抽不出共享契约，说明抽象时机未到，记录理由比强行抽象更有价值）。

## 阶段 D · v0.6.0 跨平台扩展

**目标**：FT-11 的 P1 平台——GitHub Copilot、Cursor、Gemini CLI。

复用 A6/A7 已跑顺的 9 项验证流程与记录模板；路径表扩充；平台兼容性矩阵成文。

**决策门**：PRD §10.4 ⑦「首批正式支持哪些操作系统」、⑧「哪些平台正式支持 / 仅兼容」。

## 阶段 E · v0.7.0 工具集治理

| 交付物 | 对应 |
|---|---|
| Skill 目录（catalog，由各 `SKILL_META.yaml` 生成） | FT-01 |
| 统一质量门禁与开发模板 | NFR-09 |
| 贡献审核流程（三审责任人落实） | CONTRIBUTING「三审（职责待明确）」 |
| 弃用与回滚机制 | PRD §10.2 状态机 Deprecated / Retired |
| 用户反馈入口 | FT-10 |

**决策门**：PRD §10.4 ⑤（反馈入口谁维护）、⑨⑩（是否接受社区贡献、谁审核）、③（免费范围是否含永久更新）、⑪（咨询服务如何隔离）。**这四项不决，阶段 E 无法开工**——它们定义的正是这个阶段要建的流程本身。

## 阶段 F · v1.0.0 稳定免费工具集

**放行条件（PRD §8.3 原文，逐条核）**：

- [ ] 至少 3 个经真实用户验证的 Skill
- [ ] 核心安全控制通过**独立**检查（非自查）
- [ ] 支持多个主流平台
- [ ] 工具集契约稳定
- [ ] 有持续反馈与回归评测机制
- [ ] 不依赖收集用户财务数据维持运行

> 按当前节奏，「3 个经真实用户验证的 Skill」是最长的一条路径——阶段 C 只产出第 2 个。
> **v1.0 不是时间问题，是这一条的问题**，不要用时间倒推去压缩它。

---

# 六、验收门禁矩阵

每个阶段发布前逐条核，任一不过则不发布。

| 门禁 | 依据 | 检查方式 | A | B | C | D | E | F |
|---|---|---|:-:|:-:|:-:|:-:|:-:|:-:|
| `ruff` + `mypy strict` + `pytest` 全绿 | NFR-09 | `uv run ruff check . && uv run mypy . && uv run pytest` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 安全基线 5 项通过 | §9 硬目标 | `uv run python tools/verify/run.py --all` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 版本号跨 6 处一致 | versioning §4 | 漂移守卫（自动） | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| README 与路径表一致 | FT-11 | 漂移守卫（自动） | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 触发边界语料覆盖每个 Skill | FT-03 | 漂移守卫（自动） | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 逐单元格黄金答案通过 | NFR-05 | 快照测试（自动） | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 独立前向测试通过 | §10.1 | 人工，有报告归档 | ⚠A | — | ✓ | — | — | ✓ |
| FT-11 九项逐平台验证 | FT-11 | 人工，有记录归档 | ⚠A | — | — | ✓ | — | ✓ |
| 发布包哈希 + 签名 + SBOM | §7.2 | `tools/release` | — | ✓ | ✓ | ✓ | ✓ | ✓ |
| CHANGELOG 记全 8 项 | §10.2 | 人工复核 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| GitHub Release 已建 | versioning §5.6 | 看 `/releases` 页面 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |

> **⚠A** = 阶段 A 按 §4.0 的降级决定放行，未按本行的原判据执行：前向测试记为
> `self-tested`（非独立执行者），平台验证为「使用验证」（9 项中 3 项未在宿主内确认）。
> **本行判据本身不变**——阶段 C 与 F 仍按原判据核，阶段 A 是一次有记录的例外，
> 不是把门槛改低。补做后回改此处。

> 「人工」的三项目前没有机器守卫，靠流程约束。versioning.md §7 记过一次同类教训：
> 发布流程当时只写到「打 tag」，照做到底也不会产生 Release，四个版本因此长期无 Release。
> **流程里没写的步骤等于不会发生**——所以这三项都要求落归档文件，让漏做在仓库里看得见。

---

# 七、风险与应对

| 风险 | 影响 | 应对 |
|---|---|---|
| **A5 前向测试找不到合适执行者** | 阶段 A 无限期挂起，连带阻塞 C | 降级方案：找一位同事在**信息隔离**条件下执行（不读 design / contracts / golden / 本计划），在报告里注明隔离程度。**不接受的降级**：开发者自测后记 passing——那是自证，不是前向测试 |
| **A6/A7 实测发现宿主行为不达标**（如权限确认不展示、禁网不生效） | 无法转 Preview | 据实记录失败、开 issue、修复后重测。**不得**部分通过就填 `verified`——这正是那条守卫在防的 |
| **A2 首次快照本身带 bug** | bug 被钉死为期望值，且后续所有回归都以错为准 | A2 Step 4 强制人工逐张核对；`regen_snapshots.py` 顶部写死「因回归失败而重生成 = 掩盖回归」 |
| **A4 校验器永远返回通过** | 安全基线形同虚设，且比没有更危险（给出虚假保证） | A4 Step 3 强制构造负路径，逐项确认能真的挡住 |
| **依赖漏洞扫描让 CI 随外部数据源波动** | 门禁失去可信度，团队开始习惯性忽略红灯 | 阶段 A 只报告不阻断，且写进 CHANGELOG 已知限制；阶段 B 随 SBOM 定阻断策略 |
| **PRD §10.4 的 8 项待决问题一直不决** | 阻塞 B（⑥）、D（⑦⑧）、E（③⑤⑨⑩⑪） | §五各阶段已标决策门。建议在阶段 A 发布同期集中决 ⑥⑦⑧ 三项（成本低、阻塞面大） |
| **第二次路线图顺延引发编号混乱** | 交叉引用失效 | 照 v0.2 顺延的既有做法：**只改编号不改主题**，在 PRD §8.3 保留顺延说明；§10.4 编号沿用「保留不重排」惯例 |
| **单人维护带宽不足** | 阶段拖长 | 阶段划分已按「可独立发布」切分，每个阶段自身完整可交付；宁可拉长间隔，不合并阶段 |

**回滚**：每个阶段的回滚点是上一个 tag（versioning.md §5「回滚是切 tag，不是改历史条目」）。阶段 A 的回滚版本为 `0.2.2`——回滚会把 `platforms.verified` 退回空、`status` 退回 `Experimental`，须在 CHANGELOG 明写。

---

# 八、下一步与交接

**阶段 A 已于 2026-08-11 发布完成**（v0.3.0）。A5~A7 按 §4.0 降级结案，未执行的部分
转为下表的待补测项——**它们从"发布卡点"变成了"已记录的欠账"，没有消失。**

| # | 待补测 | 优先级 | 落点 |
|---|---|---|---|
| 1 | 两平台的第 6/7/9 项（权限确认、网络拦截、错误处理） | 高 | `records/` 对应记录的待补测清单 |
| 2 | Codex 第 6 项权限确认 | **最高** | 计划曾预判它与 Claude Code 有差异，而该差异从未被任何证据触及 |
| 3 | 独立前向测试（换人执行） | 高 | 阶段 C 的门禁仍要求它；`forward` 转 `passing` 的唯一途径 |
| 4 | 结果工作簿 2 处契约偏差（隐私摘要 4/8 项、运行参数缺 3 项） | 中 | 须 bump `contract_version` 至 1.1，随阶段 B 或单独版本 |

> **第 3 项对阶段 C 是硬前置**：C 的前置是"第一个 Skill 完成真实用户验证"，而真实用户
> 验证比前向测试更进一步（要求财务人员在真实业务周期里重复使用）。前向测试都没做，
> 真实用户验证无从谈起。**这一条最终会拦住 C，早做早好。**

---

以下为阶段 A 执行期间的原始交接记录，保留备查：

| # | 事项 | 为什么交接 | 怎么做 |
|---|---|---|---|
| 1 | **开启 GitHub Private Vulnerability Reporting** | 需 admin 权限，当前无。[SECURITY.md](../../SECURITY.md) 已改为降级流程（先开 issue 只说"发现安全问题"、不写细节），**不再是"已承诺未兑现"**，但降级方案仍暴露"存在未修复漏洞"这一事实 | 拿到 admin 权限后：Settings → Code security → Private vulnerability reporting → Enable，并把 SECURITY.md 的降级说明改回私密渠道 |
| 2 | **A5 独立前向测试**：约定执行者 | PRD §10.1 要求执行者不预知答案，开发者自测不算 | 见 §四 Task A5 的资格与信息隔离要求。**这是唯一有不可控外部依赖的任务，建议最先谈** |
| 3 | **A6/A7 平台实测** | 需在真实 Claude Code / Codex 会话里逐项操作，9 项 × 2 平台 | 语料已备好在 `tests/triggering/corpus.yaml`，可直接当实测脚本念 |
| 4 | **定夺 §4.0 的 3 处契约偏差** | 修不修影响 A8 是发布 `contract_version` 1.1 还是在已知限制里写明 | 建议：③ 随手改；①② 并入 A8 并 bump 契约版本 |

完成 2、3 后即可执行 A8（守卫改写 → 状态升级 → v0.3.0 发布）。阶段 A 发布后，再展开阶段 B 的任务级计划。

> 事项 1 与 2、3 无依赖。它曾是唯一一处"文档已承诺、事实未兑现"——得知 PVR 短期
> 开不了之后，**改的是文档而不是把承诺挂着**：SECURITY.md 现在如实写降级流程与它的
> 缺点。拿到权限后再改回，两次改动都是一段文字的事。

> 本计划定义开发顺序与验收门禁，不改变 PRD 定义的产品方向。
> 与 PRD 冲突时以 PRD 为准；与 CHANGELOG 记载的事实冲突时以 CHANGELOG 为准（versioning.md §6）。
