# fcs-reconcile 对账引擎 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 实现 `fcs-reconcile` 的本地确定性对账引擎：读取左右两表 → 标准化 → 分阶段匹配 → 分类 → 勾稽汇总 → 生成 7 张中文工作簿与运行清单，并保证误判率 0、结果可重复、本地隔离。

**Architecture:** 平铺模块（不包化，见结构设计 D4）位于 `skills/fcs-reconcile/scripts/`。数据流管线：`config → io_reader(+sha256) → normalizer → matcher → classifier → summary(勾稽) → reporter/manifest`，由 `reconcile.py` 薄编排。所有金额用 `Decimal`，pandas 仅作表格 IO/分组；仅 `summary` 字典可上交 AI，原始行不越界。

**Tech Stack:** Python 3.11+ · pandas（表格 IO/分组）· `decimal.Decimal`（金额）· openpyxl（写 Excel）· pytest（测试）· ruff/mypy（质量）· uv（依赖锁定）。

## Global Constraints

> 每个任务的要求都隐含包含本节。取值逐字来自 PRD / 技术设计。

- **Python** ≥ 3.11。
- **金额**一律 `decimal.Decimal`，**禁止**参与 `float` 运算；读取时金额列以字符串载入（`dtype=str`），统一 `quantize` 到 2 位小数（可配置 `amount_scale`）。
- **确定性**：相同输入 + 配置 + `rule_version` → 逐单元格一致结果；无随机、无浮点、无依赖字典遍历顺序；所有分组/排序键固定，全程按 `(no, amount, row_id)` 稳定排序。
- **误判 0**：进入「已自动匹配」当且仅当 **候选唯一** 且 **规则完全满足**（金额差严格 `== 0`，或复合键逐字段全等）。**容差只做差异分级，绝不放宽自动确认。**
- **本地隔离**：不发起任何出站网络请求；不修改源文件（只读打开）；不打印交易明细；日志只记状态计数与错误码。
- **控制/数据平面**：仅 `summary` 字典可返回上层/AI；`DataFrame`、`StdRow`、结果明细绝不序列化进模型上下文。
- **状态**全部中文业务语言（无英文状态码）：`已自动匹配 / 疑似匹配 / 金额差异 / 左侧单边 / 右侧单边 / 重复编号 / 多候选冲突 / 数据质量问题`。
- **文件完整性**：`output.path` 不得等于任一输入路径；读取前后校验输入 SHA-256 一致。
- **契约**：`contract_version=1.0`，`rule_version=1.0`（见 `docs/contracts/fcs-reconcile/`）。
- **不变量（贯穿匹配/勾稽）**：每个左侧 `StdRow` 恰好出现在一个 outcome 的 `left`，每个右侧 `StdRow` 恰好出现在一个 outcome 的 `right`。此不变量保证数量勾稽恒成立，并使金额勾稽成为真实一致性校验。

---

## 文件结构（本计划涉及）

均在 `skills/fcs-reconcile/scripts/`（平铺）与 `skills/fcs-reconcile/tests/`：

| 文件 | 职责 |
|---|---|
| `scripts/models.py` | **新增**：共享数据类型（`Status` 枚举、`StdRow`、`MatchOutcome`、`ResultItem`、优先级/去向表） |
| `scripts/guard.py` | 网络隔离 + 脱敏日志 |
| `scripts/integrity.py` | SHA-256、拒绝覆盖输入、前后哈希一致 |
| `scripts/config.py` | 配置数据类 + 加载校验 |
| `scripts/io_reader.py` | 读取 xlsx/csv（金额列 str）、表头、只读、哈希 |
| `scripts/normalizer.py` | 金额/日期/编号/方向标准化 + 组装 `StdRow` |
| `scripts/matcher.py` | 主键与复合键分阶段确定性匹配 |
| `scripts/classifier.py` | outcome → 业务状态富化（优先级/判断依据/去向表） |
| `scripts/summary.py` | 汇总字典 + 数量/金额勾稽 |
| `scripts/manifest.py` | 运行清单 JSON（不含明细） |
| `scripts/reporter.py` | 7 张中文工作表 |
| `scripts/reconcile.py` | 薄编排 + CLI |

---

### Task 0: 环境、共享类型与测试骨架

**Files:**
- Modify: `pyproject.toml`（加依赖）
- Create: `skills/fcs-reconcile/scripts/models.py`
- Create: `skills/fcs-reconcile/tests/unit/test_models.py`

**Interfaces:**
- Produces: `Status`(Enum), `StdRow`, `MatchOutcome`, `ResultItem` 数据类；`PRIORITY`, `SHEET` 映射。供后续所有任务导入（`import models`）。

- [ ] **Step 1: 建分支并安装依赖**

```bash
git checkout -b feat/fcs-reconcile-engine
uv add pandas openpyxl pyyaml
uv add --dev pytest ruff mypy
uv lock
```

- [ ] **Step 2: 写共享类型的失败测试**

Create `skills/fcs-reconcile/tests/unit/test_models.py`:
```python
from decimal import Decimal
from datetime import date
import models


def test_status_values_are_chinese():
    assert models.Status.AUTO_MATCHED.value == "已自动匹配"
    assert models.Status.DATA_QUALITY.value == "数据质量问题"


def test_stdrow_is_frozen_and_hashable():
    r = models.StdRow(row_id=0, source_row=2, no="A1", amount=Decimal("1.00"),
                      date=date(2026, 1, 1), counterparty="X", direction_raw="收")
    assert r.quality_flags == ()
    assert hash(r)  # frozen dataclass 可哈希


def test_priority_and_sheet_cover_all_statuses():
    for s in models.Status:
        assert s in models.PRIORITY
        assert s in models.SHEET
```

- [ ] **Step 3: 运行测试确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_models.py -v`
Expected: FAIL（`ModuleNotFoundError: No module named 'models'`）

- [ ] **Step 4: 实现 models.py**

Create `skills/fcs-reconcile/scripts/models.py`:
```python
"""共享数据类型（平铺模块，不包化）。"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from enum import Enum


class Status(str, Enum):
    AUTO_MATCHED = "已自动匹配"
    SUSPECT = "疑似匹配"
    AMOUNT_DIFF = "金额差异"
    LEFT_ONLY = "左侧单边"
    RIGHT_ONLY = "右侧单边"
    DUP_NO = "重复编号"
    MULTI_CANDIDATE = "多候选冲突"
    DATA_QUALITY = "数据质量问题"


@dataclass(frozen=True)
class StdRow:
    row_id: int                       # 读取顺序稳定分配（同侧唯一）
    source_row: int                   # 源文件行号（审计追溯）
    no: str | None
    amount: Decimal | None            # 方向归一后的带符号金额；None=解析失败
    date: date | None
    counterparty: str | None
    direction_raw: str | None         # 归一前原始方向（审计）
    quality_flags: tuple[str, ...] = ()


@dataclass(frozen=True)
class MatchOutcome:
    status: Status
    left: StdRow | None = None
    right: StdRow | None = None
    amount_diff: Decimal | None = None    # 有配对时 = left.amount - right.amount
    candidates: tuple[StdRow, ...] = ()   # 冲突时的竞争候选（上下文）
    rule: str = ""                        # 命中规则标识（审计）


@dataclass(frozen=True)
class ResultItem:
    status: Status
    priority: str
    sheet: str
    no: str | None
    amount_left: Decimal | None
    amount_right: Decimal | None
    amount_diff: Decimal | None
    basis: str                            # 判断依据
    suggested_action: str                 # 建议动作
    left_source_row: int | None
    right_source_row: int | None
    candidates: tuple[StdRow, ...] = ()


PRIORITY: dict[Status, str] = {
    Status.AUTO_MATCHED: "—",
    Status.SUSPECT: "高",
    Status.AMOUNT_DIFF: "高",
    Status.MULTI_CANDIDATE: "高",
    Status.DATA_QUALITY: "高",
    Status.LEFT_ONLY: "中",
    Status.RIGHT_ONLY: "中",
    Status.DUP_NO: "中",
}

SHEET: dict[Status, str] = {
    Status.AUTO_MATCHED: "已匹配",
    Status.SUSPECT: "待处理事项",
    Status.AMOUNT_DIFF: "待处理事项",
    Status.LEFT_ONLY: "待处理事项",
    Status.RIGHT_ONLY: "待处理事项",
    Status.DUP_NO: "重复与冲突",
    Status.MULTI_CANDIDATE: "重复与冲突",
    Status.DATA_QUALITY: "数据质量",
}
```

- [ ] **Step 5: 运行测试确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_models.py -v`
Expected: PASS（3 passed）

- [ ] **Step 6: 提交**

```bash
git add pyproject.toml uv.lock skills/fcs-reconcile/scripts/models.py skills/fcs-reconcile/tests/unit/test_models.py
git commit -m "feat(fcs-reconcile): 共享类型与测试环境"
```

---

### Task 1: guard —— 网络隔离与脱敏日志

**Files:**
- Modify: `scripts/guard.py`
- Test: `tests/security/test_guard.py`

**Interfaces:**
- Produces: `NetworkDisabledError(Exception)`；`block_network() -> None`；`get_logger(name: str) -> logging.Logger`。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/security/test_guard.py`:
```python
import socket
import pytest
import guard


def test_block_network_forbids_outbound(monkeypatch):
    guard.block_network()
    with pytest.raises(guard.NetworkDisabledError):
        socket.socket().connect(("127.0.0.1", 9))


def test_get_logger_returns_logger():
    log = guard.get_logger("fcs")
    assert log.name == "fcs"
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/security/test_guard.py -v`
Expected: FAIL（`AttributeError: module 'guard' has no attribute 'block_network'`）

- [ ] **Step 3: 实现 guard.py**

Replace `skills/fcs-reconcile/scripts/guard.py` 内容：
```python
"""guard —— 网络隔离与脱敏日志的统一封装（FT-05 / NFR-02）。"""
from __future__ import annotations

import logging
import socket


class NetworkDisabledError(RuntimeError):
    """在本地隔离模式下发起出站连接时抛出。"""


def block_network() -> None:
    """禁用出站网络：任何 socket.connect 直接抛错。幂等。"""
    def _blocked(*_args, **_kwargs):
        raise NetworkDisabledError("本地隔离模式：已禁用网络访问")

    socket.socket.connect = _blocked          # type: ignore[method-assign]
    socket.socket.connect_ex = _blocked        # type: ignore[method-assign]


def get_logger(name: str) -> logging.Logger:
    """返回仅记录状态计数/错误码的 logger（不得传入交易明细）。"""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/security/test_guard.py -v`
Expected: PASS（2 passed）

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/guard.py skills/fcs-reconcile/tests/security/test_guard.py
git commit -m "feat(fcs-reconcile): guard 网络隔离与日志"
```

---

### Task 2: integrity —— 文件完整性

**Files:**
- Modify: `scripts/integrity.py`
- Test: `tests/unit/test_integrity.py`

**Interfaces:**
- Produces: `sha256_of(path: str) -> str`；`assert_output_not_overwrites_input(output_path: str, input_paths: list[str]) -> None`（违反抛 `ValueError`）；`verify_unchanged(before: dict[str, str], after: dict[str, str]) -> None`（不一致抛 `ValueError`）。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_integrity.py`:
```python
import pytest
import integrity


def test_sha256_stable(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("hello")
    assert integrity.sha256_of(str(f)) == integrity.sha256_of(str(f))
    assert len(integrity.sha256_of(str(f))) == 64


def test_output_cannot_overwrite_input(tmp_path):
    inp = tmp_path / "in.xlsx"
    inp.write_text("x")
    with pytest.raises(ValueError):
        integrity.assert_output_not_overwrites_input(str(inp), [str(inp)])


def test_verify_unchanged_detects_change():
    with pytest.raises(ValueError):
        integrity.verify_unchanged({"a": "h1"}, {"a": "h2"})
    integrity.verify_unchanged({"a": "h1"}, {"a": "h1"})  # 一致：不抛
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_integrity.py -v`
Expected: FAIL（属性不存在）

- [ ] **Step 3: 实现 integrity.py**

Replace `skills/fcs-reconcile/scripts/integrity.py`:
```python
"""integrity —— 文件完整性校验（FT-06）。"""
from __future__ import annotations

import hashlib
import os


def sha256_of(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def assert_output_not_overwrites_input(output_path: str, input_paths: list[str]) -> None:
    out = os.path.realpath(output_path)
    for p in input_paths:
        if os.path.realpath(p) == out:
            raise ValueError(f"输出路径不得覆盖输入文件：{output_path}")


def verify_unchanged(before: dict[str, str], after: dict[str, str]) -> None:
    for path, h in before.items():
        if after.get(path) != h:
            raise ValueError(f"源文件运行前后哈希不一致（疑似被修改）：{path}")
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_integrity.py -v`
Expected: PASS（3 passed）

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/integrity.py skills/fcs-reconcile/tests/unit/test_integrity.py
git commit -m "feat(fcs-reconcile): integrity 文件完整性"
```

---

### Task 3: config —— 配置数据类与加载校验

**Files:**
- Modify: `scripts/config.py`
- Test: `tests/unit/test_config.py`

**Interfaces:**
- Consumes: `integrity.assert_output_not_overwrites_input`。
- Produces: `FieldMap`, `TableSpec`, `MatchConfig`, `ReconcileConfig`（均 frozen dataclass）；`ConfigError(Exception)`；`load_config(path: str) -> ReconcileConfig`。
  - `MatchConfig` 字段：`primary_key: str="no"`, `composite_keys: tuple[str,...]=()`, `amount_tolerance: Decimal=Decimal("0.00")`, `date_tolerance_days: int=0`, `direction_rule: str="signed"`, `amount_scale: int=2`。
  - `ReconcileConfig` 字段：`left: TableSpec`, `right: TableSpec`, `match: MatchConfig`, `output_path: str`, `rule_version: str`, `contract_version: str`。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_config.py`:
```python
from decimal import Decimal
import pytest
import config

VALID = """
left:  {{file: "{L}", sheet: null, header_row: 0, fields: {{no: 单号, amount: 金额, date: 日期, counterparty: 对方, direction: 方向}}}}
right: {{file: "{R}", sheet: null, header_row: 0, fields: {{no: 流水号, amount: 发生额, date: 日期, counterparty: 户名, direction: 借贷}}}}
match: {{primary_key: no, composite_keys: [], amount_tolerance: "0.00", date_tolerance_days: 0, direction_rule: signed, amount_scale: 2}}
output: {{path: "{O}"}}
rule_version: "1.0"
contract_version: "1.0"
"""


def _write(tmp_path, out_name="out.xlsx"):
    L = tmp_path / "left.xlsx"; L.write_text("x")
    R = tmp_path / "right.xlsx"; R.write_text("y")
    O = tmp_path / out_name
    cfg = tmp_path / "c.yaml"
    cfg.write_text(VALID.format(L=L, R=R, O=O))
    return cfg


def test_load_valid_config(tmp_path):
    c = config.load_config(str(_write(tmp_path)))
    assert c.match.amount_tolerance == Decimal("0.00")
    assert c.left.fields.no == "单号"
    assert c.contract_version == "1.0"


def test_reject_output_overwriting_input(tmp_path):
    with pytest.raises(config.ConfigError):
        config.load_config(str(_write(tmp_path, out_name="left.xlsx")))


def test_reject_bad_tolerance(tmp_path):
    cfg = _write(tmp_path)
    cfg.write_text(cfg.read_text().replace('"0.00"', '"abc"'))
    with pytest.raises(config.ConfigError):
        config.load_config(str(cfg))
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_config.py -v`
Expected: FAIL（`ConfigError`/`load_config` 不存在）

- [ ] **Step 3: 实现 config.py**

Replace `skills/fcs-reconcile/scripts/config.py`:
```python
"""config —— 字段映射与规则配置的加载与校验（技术设计 §3）。"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

import yaml  # PyYAML 随 pandas 生态常见；若未装，Task 0 用 `uv add pyyaml`

import integrity


class ConfigError(ValueError):
    """配置非法：字段缺失/类型不可解析/输出覆盖输入等。"""


@dataclass(frozen=True)
class FieldMap:
    no: str
    amount: str
    date: str | None
    counterparty: str | None
    direction: str | None


@dataclass(frozen=True)
class TableSpec:
    file: str
    sheet: str | None
    header_row: int
    fields: FieldMap


@dataclass(frozen=True)
class MatchConfig:
    primary_key: str = "no"
    composite_keys: tuple[str, ...] = ()
    amount_tolerance: Decimal = Decimal("0.00")
    date_tolerance_days: int = 0
    direction_rule: str = "signed"
    amount_scale: int = 2


@dataclass(frozen=True)
class ReconcileConfig:
    left: TableSpec
    right: TableSpec
    match: MatchConfig
    output_path: str
    rule_version: str
    contract_version: str


def _table(raw: dict, side: str) -> TableSpec:
    try:
        f = raw["fields"]
        return TableSpec(
            file=raw["file"],
            sheet=raw.get("sheet"),
            header_row=int(raw.get("header_row", 0)),
            fields=FieldMap(no=f["no"], amount=f["amount"], date=f.get("date"),
                            counterparty=f.get("counterparty"), direction=f.get("direction")),
        )
    except (KeyError, TypeError, ValueError) as e:
        raise ConfigError(f"{side} 表配置非法：{e}") from e


def load_config(path: str) -> ReconcileConfig:
    with open(path, encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)
    if not isinstance(raw, dict):
        raise ConfigError("配置根节点必须为映射")

    left = _table(raw.get("left", {}), "左")
    right = _table(raw.get("right", {}), "右")
    m = raw.get("match", {})
    try:
        tol = Decimal(str(m.get("amount_tolerance", "0.00")))
    except InvalidOperation as e:
        raise ConfigError(f"amount_tolerance 非合法 Decimal：{m.get('amount_tolerance')}") from e
    if tol < 0:
        raise ConfigError("amount_tolerance 不得为负")

    match = MatchConfig(
        primary_key=m.get("primary_key", "no"),
        composite_keys=tuple(m.get("composite_keys", []) or ()),
        amount_tolerance=tol,
        date_tolerance_days=int(m.get("date_tolerance_days", 0)),
        direction_rule=m.get("direction_rule", "signed"),
        amount_scale=int(m.get("amount_scale", 2)),
    )
    output_path = (raw.get("output") or {}).get("path")
    if not output_path:
        raise ConfigError("缺少 output.path")

    try:
        integrity.assert_output_not_overwrites_input(output_path, [left.file, right.file])
    except ValueError as e:
        raise ConfigError(str(e)) from e

    return ReconcileConfig(left=left, right=right, match=match, output_path=output_path,
                           rule_version=str(raw.get("rule_version", "1.0")),
                           contract_version=str(raw.get("contract_version", "1.0")))
```

> 若 `yaml` 未安装：在 Task 0 追加 `uv add pyyaml` 并重跑 `uv lock`。

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_config.py -v`
Expected: PASS（3 passed）

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/config.py skills/fcs-reconcile/tests/unit/test_config.py pyproject.toml uv.lock
git commit -m "feat(fcs-reconcile): config 加载与校验"
```

---

### Task 4: io_reader —— 读取与哈希

**Files:**
- Modify: `scripts/io_reader.py`
- Test: `tests/unit/test_io_reader.py`

**Interfaces:**
- Consumes: `config.TableSpec`, `integrity.sha256_of`。
- Produces: `read_table(spec: config.TableSpec) -> tuple[pandas.DataFrame, str]`（返回 DataFrame 与源文件 sha256；金额列以 `str` 载入，只读打开，不写回）。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_io_reader.py`:
```python
import pandas as pd
import config
import io_reader


def _spec(path):
    return config.TableSpec(file=str(path), sheet=None, header_row=0,
                            fields=config.FieldMap(no="单号", amount="金额", date="日期",
                                                   counterparty="对方", direction="方向"))


def test_read_csv_amount_as_string(tmp_path):
    p = tmp_path / "l.csv"
    pd.DataFrame({"单号": ["A1"], "金额": ["1,234.50"], "日期": ["2026-01-01"],
                  "对方": ["X"], "方向": ["收"]}).to_csv(p, index=False)
    df, sha = io_reader.read_table(_spec(p))
    assert df.loc[0, "金额"] == "1,234.50"     # 未被转 float
    assert len(sha) == 64


def test_source_not_modified(tmp_path):
    p = tmp_path / "l.csv"
    pd.DataFrame({"单号": ["A1"], "金额": ["1.00"], "日期": ["2026-01-01"],
                  "对方": ["X"], "方向": ["收"]}).to_csv(p, index=False)
    before = __import__("integrity").sha256_of(str(p))
    io_reader.read_table(_spec(p))
    assert __import__("integrity").sha256_of(str(p)) == before
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_io_reader.py -v`
Expected: FAIL（`read_table` 不存在）

- [ ] **Step 3: 实现 io_reader.py**

Replace `skills/fcs-reconcile/scripts/io_reader.py`:
```python
"""io_reader —— 读取 xlsx/csv，金额列以字符串载入，计算源文件哈希（技术设计 §4.1）。"""
from __future__ import annotations

import os

import pandas as pd

import integrity
from config import TableSpec


def read_table(spec: TableSpec) -> tuple[pd.DataFrame, str]:
    sha = integrity.sha256_of(spec.file)
    # 金额列强制 str，隔离 float64 精度风险。
    str_cols = {c: str for c in [spec.fields.no, spec.fields.amount] if c}
    ext = os.path.splitext(spec.file)[1].lower()
    if ext in (".xlsx", ".xls"):
        df = pd.read_excel(spec.file, sheet_name=spec.sheet or 0,
                           header=spec.header_row, dtype=str_cols)
    else:
        df = pd.read_csv(spec.file, header=spec.header_row, dtype=str_cols)
    return df, sha
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_io_reader.py -v`
Expected: PASS（2 passed）

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/io_reader.py skills/fcs-reconcile/tests/unit/test_io_reader.py
git commit -m "feat(fcs-reconcile): io_reader 读取与哈希"
```

---

### Task 5: normalizer —— 金额（关键：Decimal，不入 float）

**Files:**
- Modify: `scripts/normalizer.py`
- Test: `tests/unit/test_normalizer_money.py`

**Interfaces:**
- Produces: `parse_amount(raw: str | None, scale: int) -> tuple[Decimal | None, str | None]`。返回 `(值, 质量标记)`；无法解析时返回 `(None, "非法金额")`。清洗千分位/货币符号/全角/空白；成功则 `quantize` 到 `scale` 位。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_normalizer_money.py`:
```python
from decimal import Decimal
import normalizer


def test_parse_thousands_and_currency():
    val, flag = normalizer.parse_amount("￥1,234.5", 2)
    assert val == Decimal("1234.50")
    assert flag is None


def test_parse_fullwidth_and_spaces():
    val, flag = normalizer.parse_amount("  １２．３４５ ", 2)
    assert val == Decimal("12.35")   # 四舍五入到 2 位（ROUND_HALF_UP）
    assert flag is None


def test_illegal_amount_flagged_not_guessed():
    val, flag = normalizer.parse_amount("待补", 2)
    assert val is None
    assert flag == "非法金额"


def test_empty_amount_flagged():
    assert normalizer.parse_amount(None, 2) == (None, "非法金额")
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_normalizer_money.py -v`
Expected: FAIL（`parse_amount` 不存在）

- [ ] **Step 3: 实现 parse_amount（在 normalizer.py 顶部）**

Replace `skills/fcs-reconcile/scripts/normalizer.py`（本任务先建立文件与 `parse_amount`；后续任务追加函数）：
```python
"""normalizer —— 金额/日期/编号/方向标准化（技术设计 §4）。金额绝不入 float。"""
from __future__ import annotations

import unicodedata
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation


def _clean(raw: str | None) -> str | None:
    if raw is None:
        return None
    s = unicodedata.normalize("NFKC", str(raw)).strip()   # 全角→半角
    return s or None


def parse_amount(raw: str | None, scale: int) -> tuple[Decimal | None, str | None]:
    s = _clean(raw)
    if s is None:
        return None, "非法金额"
    s = s.replace(",", "").replace("￥", "").replace("¥", "").replace("$", "")
    try:
        value = Decimal(s).quantize(Decimal(1).scaleb(-scale), rounding=ROUND_HALF_UP)  # 四舍五入
    except (InvalidOperation, ValueError):
        return None, "非法金额"
    return value, None
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_normalizer_money.py -v`
Expected: PASS（4 passed）

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/normalizer.py skills/fcs-reconcile/tests/unit/test_normalizer_money.py
git commit -m "feat(fcs-reconcile): normalizer 金额 Decimal 解析"
```

---

### Task 6: normalizer —— 日期 / 编号 / 方向

**Files:**
- Modify: `scripts/normalizer.py`
- Test: `tests/unit/test_normalizer_fields.py`

**Interfaces:**
- Produces:
  - `parse_date(raw: str | None) -> tuple[date | None, str | None]`（多格式；失败 → `(None, "非法日期")`）。
  - `normalize_no(raw: str | None) -> tuple[str | None, tuple[str, ...]]`（去空白/全角归一/保留前导零；危险长编号 → 标记 `"危险长编号"` 但保留原值；空 → 标记 `"空编号"`）。
  - `normalize_direction(amount: Decimal | None, direction_raw: str | None, rule: str) -> tuple[Decimal | None, str | None]`（`signed`：收/借为正、付/贷为负；缺失/越界 → `(amount, "方向缺失")`）。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_normalizer_fields.py`:
```python
from datetime import date
from decimal import Decimal
import normalizer


def test_parse_date_multi_format():
    assert normalizer.parse_date("2026-01-02")[0] == date(2026, 1, 2)
    assert normalizer.parse_date("2026/1/2")[0] == date(2026, 1, 2)
    assert normalizer.parse_date("bad") == (None, "非法日期")


def test_normalize_no_keeps_leading_zero():
    val, flags = normalizer.normalize_no("  007 ")
    assert val == "007" and flags == ()


def test_dangerous_long_number_flagged_not_fixed():
    val, flags = normalizer.normalize_no("1.23457E+17")
    assert val == "1.23457E+17"            # 保留原始文本，不"修复"
    assert "危险长编号" in flags


def test_empty_no_flagged():
    assert normalizer.normalize_no(" ") == (None, ("空编号",))


def test_direction_signed():
    assert normalizer.normalize_direction(Decimal("10.00"), "付", "signed") == (Decimal("-10.00"), None)
    assert normalizer.normalize_direction(Decimal("10.00"), "收", "signed") == (Decimal("10.00"), None)
    val, flag = normalizer.normalize_direction(Decimal("10.00"), None, "signed")
    assert flag == "方向缺失"
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_normalizer_fields.py -v`
Expected: FAIL

- [ ] **Step 3: 追加实现到 normalizer.py**

Append 到 `skills/fcs-reconcile/scripts/normalizer.py`:
```python
import re
from datetime import date, datetime

_DATE_FORMATS = ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d", "%Y%m%d")


def parse_date(raw: str | None) -> tuple[date | None, str | None]:
    s = _clean(raw)
    if s is None:
        return None, "非法日期"
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt).date(), None
        except ValueError:
            continue
    return None, "非法日期"


_SCI_RE = re.compile(r"^\d+(\.\d+)?[eE][+-]?\d+$")


def normalize_no(raw: str | None) -> tuple[str | None, tuple[str, ...]]:
    s = _clean(raw)
    if s is None:
        return None, ("空编号",)
    flags: tuple[str, ...] = ()
    if _SCI_RE.match(s) or (s.isdigit() and len(s) >= 16):
        flags = ("危险长编号",)   # 曾被 Excel 转科学计数法/丢精度，保留原值不修复
    return s, flags


_POSITIVE = {"收", "借", "收入", "借方"}
_NEGATIVE = {"付", "贷", "支出", "付款", "贷方"}


def normalize_direction(amount, direction_raw, rule):
    if rule != "signed" or amount is None:
        return amount, None
    d = _clean(direction_raw)
    if d in _POSITIVE:
        return abs(amount), None
    if d in _NEGATIVE:
        return -abs(amount), None
    return amount, "方向缺失"
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_normalizer_fields.py -v`
Expected: PASS（5 passed）

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/normalizer.py skills/fcs-reconcile/tests/unit/test_normalizer_fields.py
git commit -m "feat(fcs-reconcile): normalizer 日期/编号/方向"
```

---

### Task 7: normalizer —— 组装 StdRow

**Files:**
- Modify: `scripts/normalizer.py`
- Test: `tests/unit/test_normalizer_assemble.py`

**Interfaces:**
- Consumes: `parse_amount`, `parse_date`, `normalize_no`, `normalize_direction`, `config.FieldMap`, `config.MatchConfig`, `models.StdRow`。
- Produces: `normalize(df: pandas.DataFrame, fields: config.FieldMap, match: config.MatchConfig) -> list[models.StdRow]`。`row_id` 按行序 0..n-1；`source_row = header_row 之后的源行号`（此处用 `df.index + 2` 近似，表头占 1 行）；聚合各字段 `quality_flags`。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_normalizer_assemble.py`:
```python
from decimal import Decimal
import pandas as pd
import config, normalizer


def _fields():
    return config.FieldMap(no="单号", amount="金额", date="日期", counterparty="对方", direction="方向")


def _match():
    return config.MatchConfig()


def test_assemble_stdrows():
    df = pd.DataFrame({"单号": ["A1", " "], "金额": ["10.00", "bad"],
                       "日期": ["2026-01-01", "2026-01-02"], "对方": ["X", "Y"],
                       "方向": ["收", "付"]})
    rows = normalizer.normalize(df, _fields(), _match())
    assert len(rows) == 2
    assert rows[0].no == "A1" and rows[0].amount == Decimal("10.00")
    assert rows[0].row_id == 0
    # 第 2 行：空编号 + 非法金额 → 两个质量标记
    assert "空编号" in rows[1].quality_flags
    assert "非法金额" in rows[1].quality_flags
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_normalizer_assemble.py -v`
Expected: FAIL（`normalize` 不存在）

- [ ] **Step 3: 追加实现到 normalizer.py**

Append：
```python
from config import FieldMap, MatchConfig
from models import StdRow


def normalize(df, fields: FieldMap, match: MatchConfig) -> list[StdRow]:
    rows: list[StdRow] = []
    for i, (_, r) in enumerate(df.iterrows()):
        def cell(col):
            return r[col] if col and col in df.columns else None

        no, no_flags = normalize_no(cell(fields.no))
        amount, amt_flag = parse_amount(cell(fields.amount), match.amount_scale)
        d, date_flag = parse_date(cell(fields.date)) if fields.date else (None, None)
        amount, dir_flag = normalize_direction(amount, cell(fields.direction), match.direction_rule)
        flags = tuple(f for f in (*no_flags, amt_flag, date_flag, dir_flag) if f)
        rows.append(StdRow(
            row_id=i, source_row=i + 2, no=no, amount=amount, date=d,
            counterparty=(str(cell(fields.counterparty)).strip() if cell(fields.counterparty) is not None else None),
            direction_raw=(str(cell(fields.direction)).strip() if cell(fields.direction) is not None else None),
            quality_flags=flags,
        ))
    return rows
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_normalizer_assemble.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/normalizer.py skills/fcs-reconcile/tests/unit/test_normalizer_assemble.py
git commit -m "feat(fcs-reconcile): normalizer 组装 StdRow"
```

---

### Task 8: matcher —— 主键分阶段匹配（核心）

**Files:**
- Modify: `scripts/matcher.py`
- Test: `tests/unit/test_matcher_primary.py`, `tests/property/test_matcher_invariant.py`

**Interfaces:**
- Consumes: `models.StdRow`, `models.Status`, `models.MatchOutcome`, `config.MatchConfig`。
- Produces:
  - `match_primary(left, right, match) -> tuple[list[MatchOutcome], list[StdRow], list[StdRow]]`（返回：已产出的 outcome、以及未匹配的左/右剩余行）。
  - `match(left, right, match) -> list[MatchOutcome]`（本任务：仅 primary + 剩余行落为单边；Task 9 插入复合键）。
- **规则（Global Constraints 的落地）**：
  1. 含 `quality_flags` 的行 → 各自 `DATA_QUALITY`（单边 outcome），不参与匹配。
  2. 同侧 `no` 出现 ≥2 次：若两侧都存在该 `no` → 每个涉及行 `MULTI_CANDIDATE`；否则重复的一侧每行 `DUP_NO`。均带 `candidates`。
  3. `no` 两侧各唯一：`diff == 0` → `AUTO_MATCHED`；`0 < |diff| <= tol` 且 `tol > 0` → `SUSPECT`；否则 `AMOUNT_DIFF`。（`amount` 为 None 者已被质量分流）
  4. 剩余单边行返回给调用者（Task 9 处理复合键，最终落 `LEFT_ONLY`/`RIGHT_ONLY`）。
- 确定性：`no` 遍历按 `sorted()`；行内按 `row_id` 升序。

- [ ] **Step 1: 写失败测试（含不变量属性测试）**

Create `skills/fcs-reconcile/tests/unit/test_matcher_primary.py`:
```python
from decimal import Decimal
import config, matcher
from models import Status, StdRow


def row(rid, no, amt, side_flag=()):
    return StdRow(row_id=rid, source_row=rid + 2, no=no,
                  amount=(Decimal(amt) if amt is not None else None),
                  date=None, counterparty=None, direction_raw=None, quality_flags=side_flag)


def statuses(outcomes):
    return sorted(o.status for o in outcomes)


def test_unique_equal_auto_matched():
    out = matcher.match([row(0, "A1", "10.00")], [row(0, "A1", "10.00")], config.MatchConfig())
    assert [o.status for o in out] == [Status.AUTO_MATCHED]
    assert out[0].amount_diff == Decimal("0.00")


def test_tolerance_never_auto_confirms():
    m = config.MatchConfig(amount_tolerance=Decimal("1.00"))
    out = matcher.match([row(0, "A1", "10.00")], [row(0, "A1", "10.50")], m)
    assert out[0].status == Status.SUSPECT           # 容差内仍需人工，不自动放行


def test_amount_diff_beyond_tolerance():
    m = config.MatchConfig(amount_tolerance=Decimal("0.10"))
    out = matcher.match([row(0, "A1", "10.00")], [row(0, "A1", "12.00")], m)
    assert out[0].status == Status.AMOUNT_DIFF


def test_duplicate_no_same_side():
    out = matcher.match([row(0, "A1", "1"), row(1, "A1", "2")], [], config.MatchConfig())
    assert statuses(out) == [Status.DUP_NO, Status.DUP_NO]


def test_multi_candidate_conflict():
    out = matcher.match([row(0, "A1", "1")], [row(0, "A1", "1"), row(1, "A1", "1")], config.MatchConfig())
    assert Status.MULTI_CANDIDATE in {o.status for o in out}


def test_singletons_become_left_right_only():
    out = matcher.match([row(0, "L1", "1")], [row(0, "R1", "2")], config.MatchConfig())
    assert statuses(out) == [Status.LEFT_ONLY, Status.RIGHT_ONLY]


def test_quality_rows_bypass():
    out = matcher.match([row(0, None, None, side_flag=("空编号",))], [], config.MatchConfig())
    assert out[0].status == Status.DATA_QUALITY
```

Create `skills/fcs-reconcile/tests/property/test_matcher_invariant.py`:
```python
from decimal import Decimal
import config, matcher
from models import StdRow


def _rows(spec):
    return [StdRow(row_id=i, source_row=i + 2, no=no,
                   amount=Decimal(a), date=None, counterparty=None,
                   direction_raw=None) for i, (no, a) in enumerate(spec)]


def test_every_row_accounted_exactly_once():
    left = _rows([("A1", "1"), ("A2", "2"), ("A1", "9")])   # A1 重复
    right = _rows([("A1", "1"), ("B9", "5")])
    out = matcher.match(left, right, config.MatchConfig())
    left_ids = [o.left.row_id for o in out if o.left is not None]
    right_ids = [o.right.row_id for o in out if o.right is not None]
    assert sorted(left_ids) == [0, 1, 2]     # 每个左行恰好一次
    assert sorted(right_ids) == [0, 1]       # 每个右行恰好一次
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_matcher_primary.py skills/fcs-reconcile/tests/property/test_matcher_invariant.py -v`
Expected: FAIL（`match` 不存在）

- [ ] **Step 3: 实现 matcher.py**

Replace `skills/fcs-reconcile/scripts/matcher.py`:
```python
"""matcher —— 分阶段确定性匹配（技术设计 §5）。误判 0：唯一 + 完全满足才自动确认。"""
from __future__ import annotations

from collections import defaultdict
from decimal import Decimal

from config import MatchConfig
from models import MatchOutcome, StdRow, Status


def _by_no(rows: list[StdRow]) -> dict[str, list[StdRow]]:
    groups: dict[str, list[StdRow]] = defaultdict(list)
    for r in rows:
        groups[r.no].append(r)  # type: ignore[index]
    return groups


def match_primary(left: list[StdRow], right: list[StdRow], match: MatchConfig
                  ) -> tuple[list[MatchOutcome], list[StdRow], list[StdRow]]:
    outcomes: list[MatchOutcome] = []
    # 1) 质量分流
    l_ok = [r for r in left if not r.quality_flags]
    r_ok = [r for r in right if not r.quality_flags]
    for r in left:
        if r.quality_flags:
            outcomes.append(MatchOutcome(Status.DATA_QUALITY, left=r, rule="数据质量"))
    for r in right:
        if r.quality_flags:
            outcomes.append(MatchOutcome(Status.DATA_QUALITY, right=r, rule="数据质量"))

    lg, rg = _by_no(l_ok), _by_no(r_ok)
    left_leftover: list[StdRow] = []
    right_leftover: list[StdRow] = []
    tol = match.amount_tolerance

    for no in sorted(set(lg) | set(rg)):
        lc = sorted(lg.get(no, []), key=lambda r: r.row_id)
        rc = sorted(rg.get(no, []), key=lambda r: r.row_id)
        if len(lc) >= 2 or len(rc) >= 2:
            cands = tuple(lc + rc)
            if lc and rc:
                for r in lc:
                    outcomes.append(MatchOutcome(Status.MULTI_CANDIDATE, left=r, candidates=cands, rule="多候选"))
                for r in rc:
                    outcomes.append(MatchOutcome(Status.MULTI_CANDIDATE, right=r, candidates=cands, rule="多候选"))
            else:
                for r in lc:
                    outcomes.append(MatchOutcome(Status.DUP_NO, left=r, candidates=cands, rule="重复编号"))
                for r in rc:
                    outcomes.append(MatchOutcome(Status.DUP_NO, right=r, candidates=cands, rule="重复编号"))
            continue
        if len(lc) == 1 and len(rc) == 1:
            l, r = lc[0], rc[0]
            diff = (l.amount or Decimal(0)) - (r.amount or Decimal(0))
            if diff == 0:
                outcomes.append(MatchOutcome(Status.AUTO_MATCHED, left=l, right=r, amount_diff=diff, rule="主键唯一且金额相等"))
            elif tol > 0 and abs(diff) <= tol:
                outcomes.append(MatchOutcome(Status.SUSPECT, left=l, right=r, amount_diff=diff, rule="容差内差异"))
            else:
                outcomes.append(MatchOutcome(Status.AMOUNT_DIFF, left=l, right=r, amount_diff=diff, rule="金额超容差"))
        elif lc:
            left_leftover.extend(lc)
        elif rc:
            right_leftover.extend(rc)
    return outcomes, left_leftover, right_leftover


def match(left: list[StdRow], right: list[StdRow], match: MatchConfig) -> list[MatchOutcome]:
    outcomes, l_rest, r_rest = match_primary(left, right, match)
    # Task 9 将在此处插入复合键匹配；当前：剩余落单边。
    for r in sorted(l_rest, key=lambda x: x.row_id):
        outcomes.append(MatchOutcome(Status.LEFT_ONLY, left=r, rule="仅左侧存在"))
    for r in sorted(r_rest, key=lambda x: x.row_id):
        outcomes.append(MatchOutcome(Status.RIGHT_ONLY, right=r, rule="仅右侧存在"))
    return outcomes
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_matcher_primary.py skills/fcs-reconcile/tests/property/test_matcher_invariant.py -v`
Expected: PASS（8 passed）

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/matcher.py skills/fcs-reconcile/tests/unit/test_matcher_primary.py skills/fcs-reconcile/tests/property/test_matcher_invariant.py
git commit -m "feat(fcs-reconcile): matcher 主键分阶段匹配"
```

---

### Task 9: matcher —— 复合键阶段（互唯一 + 日期容差）

**Files:**
- Modify: `scripts/matcher.py`
- Test: `tests/unit/test_matcher_composite.py`

**Interfaces:**
- Produces: `match_composite(left_leftover, right_leftover, match) -> tuple[list[MatchOutcome], list[StdRow], list[StdRow]]`；并把 `match()` 改为在单边落地前调用它。
- **规则**：仅当 `match.composite_keys` 非空时启用。对剩余行，复合键 = 各 `composite_keys` 字段值元组（`date` 字段用日期容差近似：`|d_left - d_right| <= date_tolerance_days` 视为相等，其余字段严格相等）。**互唯一**才自动确认：某左行的合格右候选恰好 1 个，且该右候选的合格左候选也恰好 1 个 → `AUTO_MATCHED`（`rule="复合键唯一一致"`，`amount_diff=0`）。否则该行留作单边。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_matcher_composite.py`:
```python
from datetime import date
from decimal import Decimal
import config, matcher
from models import Status, StdRow


def row(rid, amt, d, cp):
    return StdRow(row_id=rid, source_row=rid + 2, no=f"N{rid}", amount=Decimal(amt),
                  date=d, counterparty=cp, direction_raw=None)


def test_composite_unique_auto_match():
    m = config.MatchConfig(composite_keys=("amount", "date", "counterparty"))
    left = [row(0, "10.00", date(2026, 1, 1), "X")]
    right = [row(9, "10.00", date(2026, 1, 1), "X")]
    out = matcher.match(left, right, m)
    assert [o.status for o in out] == [Status.AUTO_MATCHED]
    assert out[0].rule == "复合键唯一一致"


def test_composite_ambiguous_stays_single_sided():
    m = config.MatchConfig(composite_keys=("amount", "date", "counterparty"))
    left = [row(0, "10.00", date(2026, 1, 1), "X")]
    right = [row(8, "10.00", date(2026, 1, 1), "X"), row(9, "10.00", date(2026, 1, 1), "X")]
    out = matcher.match(left, right, m)
    # 左行有 2 个候选 → 不自动确认；全部落单边
    assert Status.AUTO_MATCHED not in {o.status for o in out}
    assert {o.status for o in out} == {Status.LEFT_ONLY, Status.RIGHT_ONLY}


def test_composite_disabled_when_no_keys():
    out = matcher.match([row(0, "10.00", date(2026, 1, 1), "X")],
                        [row(9, "10.00", date(2026, 1, 1), "X")], config.MatchConfig())
    assert {o.status for o in out} == {Status.LEFT_ONLY, Status.RIGHT_ONLY}
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_matcher_composite.py -v`
Expected: FAIL

- [ ] **Step 3: 追加 match_composite 并改写 match()**

在 `matcher.py` 追加，并把 `match()` 中"剩余落单边"前插入复合键：
```python
def _composite_equal(a: StdRow, b: StdRow, keys: tuple[str, ...], date_tol: int) -> bool:
    for k in keys:
        if k == "date":
            if a.date is None or b.date is None or abs((a.date - b.date).days) > date_tol:
                return False
        elif getattr(a, k) != getattr(b, k):
            return False
    return True


def match_composite(left_leftover, right_leftover, match
                    ) -> tuple[list[MatchOutcome], list[StdRow], list[StdRow]]:
    if not match.composite_keys:
        return [], list(left_leftover), list(right_leftover)
    keys, dtol = match.composite_keys, match.date_tolerance_days
    outcomes: list[MatchOutcome] = []
    matched_l: set[int] = set()
    matched_r: set[int] = set()
    for l in sorted(left_leftover, key=lambda x: x.row_id):
        rc = [r for r in right_leftover if r.row_id not in matched_r
              and _composite_equal(l, r, keys, dtol)]
        if len(rc) != 1:
            continue
        r = rc[0]
        lc = [x for x in left_leftover if x.row_id not in matched_l
              and _composite_equal(x, r, keys, dtol)]
        if len(lc) != 1:
            continue                      # 互唯一才放行
        matched_l.add(l.row_id)
        matched_r.add(r.row_id)
        from decimal import Decimal as _D
        outcomes.append(MatchOutcome(Status.AUTO_MATCHED, left=l, right=r,
                                     amount_diff=_D(0), rule="复合键唯一一致"))
    l_rest = [r for r in left_leftover if r.row_id not in matched_l]
    r_rest = [r for r in right_leftover if r.row_id not in matched_r]
    return outcomes, l_rest, r_rest
```

改写 `match()`：
```python
def match(left: list[StdRow], right: list[StdRow], match: MatchConfig) -> list[MatchOutcome]:
    outcomes, l_rest, r_rest = match_primary(left, right, match)
    comp, l_rest, r_rest = match_composite(l_rest, r_rest, match)
    outcomes.extend(comp)
    for r in sorted(l_rest, key=lambda x: x.row_id):
        outcomes.append(MatchOutcome(Status.LEFT_ONLY, left=r, rule="仅左侧存在"))
    for r in sorted(r_rest, key=lambda x: x.row_id):
        outcomes.append(MatchOutcome(Status.RIGHT_ONLY, right=r, rule="仅右侧存在"))
    return outcomes
```

- [ ] **Step 4: 运行确认通过（并回归 Task 8）**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_matcher_composite.py skills/fcs-reconcile/tests/unit/test_matcher_primary.py skills/fcs-reconcile/tests/property -v`
Expected: PASS（全部）

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/matcher.py skills/fcs-reconcile/tests/unit/test_matcher_composite.py
git commit -m "feat(fcs-reconcile): matcher 复合键互唯一匹配"
```

---

### Task 10: classifier —— 富化为业务结果项

**Files:**
- Modify: `scripts/classifier.py`
- Test: `tests/unit/test_classifier.py`

**Interfaces:**
- Consumes: `models.MatchOutcome`, `models.ResultItem`, `models.PRIORITY`, `models.SHEET`, `models.Status`。
- Produces: `classify(outcomes: list[MatchOutcome]) -> list[ResultItem]`（一 outcome → 一 ResultItem；填 `priority`/`sheet`/`amount_left`/`amount_right`/`amount_diff`/`basis`/`suggested_action`/来源行）。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_classifier.py`:
```python
from decimal import Decimal
import classifier
from models import MatchOutcome, StdRow, Status


def _r(rid, amt):
    return StdRow(row_id=rid, source_row=rid + 2, no="A1", amount=Decimal(amt),
                  date=None, counterparty=None, direction_raw=None)


def test_classify_amount_diff_fills_fields():
    o = MatchOutcome(Status.AMOUNT_DIFF, left=_r(0, "12.00"), right=_r(0, "10.00"),
                     amount_diff=Decimal("2.00"), rule="金额超容差")
    item = classifier.classify([o])[0]
    assert item.priority == "高"
    assert item.sheet == "待处理事项"
    assert item.amount_left == Decimal("12.00")
    assert item.amount_right == Decimal("10.00")
    assert item.amount_diff == Decimal("2.00")
    assert item.left_source_row == 2 and item.right_source_row == 2
    assert item.basis  # 非空判断依据


def test_classify_left_only():
    o = MatchOutcome(Status.LEFT_ONLY, left=_r(0, "5.00"), rule="仅左侧存在")
    item = classifier.classify([o])[0]
    assert item.sheet == "待处理事项" and item.priority == "中"
    assert item.amount_right is None
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_classifier.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 classifier.py**

Replace `skills/fcs-reconcile/scripts/classifier.py`:
```python
"""classifier —— 将匹配 outcome 富化为中文业务结果项（技术设计 §6）。"""
from __future__ import annotations

from models import MatchOutcome, PRIORITY, ResultItem, SHEET, Status

_ACTION = {
    Status.AUTO_MATCHED: "无需处理",
    Status.SUSPECT: "人工确认容差内差异是否可接受",
    Status.AMOUNT_DIFF: "核对金额差异来源",
    Status.LEFT_ONLY: "核对该笔是否漏记于右表",
    Status.RIGHT_ONLY: "核对该笔是否漏记于左表",
    Status.DUP_NO: "核对重复编号的真实对应关系",
    Status.MULTI_CANDIDATE: "人工从多个候选中选择正确对应",
    Status.DATA_QUALITY: "修正源数据质量问题后重跑",
}


def classify(outcomes: list[MatchOutcome]) -> list[ResultItem]:
    items: list[ResultItem] = []
    for o in outcomes:
        items.append(ResultItem(
            status=o.status,
            priority=PRIORITY[o.status],
            sheet=SHEET[o.status],
            no=(o.left.no if o.left else (o.right.no if o.right else None)),
            amount_left=(o.left.amount if o.left else None),
            amount_right=(o.right.amount if o.right else None),
            amount_diff=o.amount_diff,
            basis=o.rule,
            suggested_action=_ACTION[o.status],
            left_source_row=(o.left.source_row if o.left else None),
            right_source_row=(o.right.source_row if o.right else None),
            candidates=o.candidates,
        ))
    return items
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_classifier.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/classifier.py skills/fcs-reconcile/tests/unit/test_classifier.py
git commit -m "feat(fcs-reconcile): classifier 结果富化"
```

---

### Task 11: summary —— 汇总与勾稽（数量/金额）

**Files:**
- Modify: `scripts/summary.py`
- Test: `tests/unit/test_summary.py`, `tests/property/test_reconcile_identities.py`

**Interfaces:**
- Consumes: `models.MatchOutcome`, `models.Status`。
- Produces: `build_summary(outcomes, left_total_rows: int, right_total_rows: int) -> dict`。返回仅含汇总量（无明细）：`counts`（各状态计数）、`match_rate`、`quantity_reconciled`(bool)、`amount_reconciled`(bool)、`left_amount_total`/`right_amount_total`/`sum_amount_diff`（字符串化 Decimal）。
- **勾稽**：
  - 数量勾稽：`Σ(有 left 的 outcome) == left_total_rows` 且 `Σ(有 right 的 outcome) == right_total_rows`。
  - 金额勾稽：`Σ left.amount(有效) − Σ right.amount(有效) == Σ((left.amount or 0) − (right.amount or 0))`。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_summary.py`:
```python
from decimal import Decimal
import summary
from models import MatchOutcome, StdRow, Status


def _r(rid, amt):
    return StdRow(row_id=rid, source_row=rid + 2, no="A", amount=Decimal(amt),
                  date=None, counterparty=None, direction_raw=None)


def test_summary_counts_and_reconciliation():
    outs = [
        MatchOutcome(Status.AUTO_MATCHED, left=_r(0, "10.00"), right=_r(0, "10.00"), amount_diff=Decimal("0.00")),
        MatchOutcome(Status.LEFT_ONLY, left=_r(1, "5.00")),
    ]
    s = summary.build_summary(outs, left_total_rows=2, right_total_rows=1)
    assert s["counts"]["已自动匹配"] == 1
    assert s["counts"]["左侧单边"] == 1
    assert s["quantity_reconciled"] is True
    assert s["amount_reconciled"] is True
    assert s["left_amount_total"] == "15.00"
    assert s["right_amount_total"] == "10.00"
```

Create `skills/fcs-reconcile/tests/property/test_reconcile_identities.py`:
```python
from decimal import Decimal
import config, matcher, summary
from models import StdRow


def _rows(spec):
    return [StdRow(row_id=i, source_row=i + 2, no=no, amount=Decimal(a), date=None,
                   counterparty=None, direction_raw=None) for i, (no, a) in enumerate(spec)]


def test_identities_hold_on_mixed_input():
    left = _rows([("A1", "10.00"), ("A2", "20.00"), ("A1", "99.00")])
    right = _rows([("A1", "10.00"), ("B9", "7.00")])
    outs = matcher.match(left, right, config.MatchConfig())
    s = summary.build_summary(outs, len(left), len(right))
    assert s["quantity_reconciled"] is True
    assert s["amount_reconciled"] is True
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_summary.py skills/fcs-reconcile/tests/property/test_reconcile_identities.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 summary.py**

Replace `skills/fcs-reconcile/scripts/summary.py`:
```python
"""summary —— 汇总字典（唯一进 AI 出口）+ 勾稽（技术设计 §7.2）。无交易明细。"""
from __future__ import annotations

from collections import Counter
from decimal import Decimal

from models import MatchOutcome, Status


def build_summary(outcomes: list[MatchOutcome], left_total_rows: int, right_total_rows: int) -> dict:
    counts = Counter(o.status.value for o in outcomes)
    left_present = sum(1 for o in outcomes if o.left is not None)
    right_present = sum(1 for o in outcomes if o.right is not None)

    left_total = sum((o.left.amount for o in outcomes if o.left and o.left.amount is not None), Decimal(0))
    right_total = sum((o.right.amount for o in outcomes if o.right and o.right.amount is not None), Decimal(0))
    sum_diff = sum(((o.left.amount if o.left and o.left.amount else Decimal(0))
                    - (o.right.amount if o.right and o.right.amount else Decimal(0))
                    for o in outcomes), Decimal(0))

    total = len(outcomes)
    auto = counts.get(Status.AUTO_MATCHED.value, 0)
    return {
        "counts": {s.value: counts.get(s.value, 0) for s in Status},
        "match_rate": (f"{auto / total:.4f}" if total else "0"),
        "quantity_reconciled": left_present == left_total_rows and right_present == right_total_rows,
        "amount_reconciled": (left_total - right_total) == sum_diff,
        "left_amount_total": str(left_total),
        "right_amount_total": str(right_total),
        "sum_amount_diff": str(sum_diff),
    }
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_summary.py skills/fcs-reconcile/tests/property/test_reconcile_identities.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/summary.py skills/fcs-reconcile/tests/unit/test_summary.py skills/fcs-reconcile/tests/property/test_reconcile_identities.py
git commit -m "feat(fcs-reconcile): summary 汇总与勾稽"
```

---

### Task 12: manifest —— 运行清单（不含明细）

**Files:**
- Modify: `scripts/manifest.py`
- Test: `tests/unit/test_manifest.py`

**Interfaces:**
- Produces: `build_manifest(*, skill_version, rule_version, contract_version, run_id, run_at, inputs, outputs, field_mapping, config_dict, counts, warnings, errors) -> dict`；`write_manifest(manifest: dict, path: str) -> None`（写 UTF-8 JSON）。
- **约束**：清单**不得**含交易明细；`inputs`/`outputs` 仅 `{path, sha256}`。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_manifest.py`:
```python
import json
import manifest


def test_manifest_structure_no_details(tmp_path):
    m = manifest.build_manifest(
        skill_version="0.1.0", rule_version="1.0", contract_version="1.0",
        run_id="r1", run_at="2026-07-23T00:00:00",
        inputs=[{"path": "l.xlsx", "sha256": "h1"}],
        outputs=[{"path": "o.xlsx", "sha256": "h2"}],
        field_mapping={"left": {"no": "单号"}}, config_dict={"amount_tolerance": "0.00"},
        counts={"已自动匹配": 3}, warnings=0, errors=0)
    assert m["permissions"] == {"network": "disabled", "source_write": False}
    p = tmp_path / "manifest.json"
    manifest.write_manifest(m, str(p))
    loaded = json.loads(p.read_text(encoding="utf-8"))
    assert loaded["counts"]["已自动匹配"] == 3
    assert loaded["inputs"][0]["sha256"] == "h1"
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_manifest.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 manifest.py**

Replace `skills/fcs-reconcile/scripts/manifest.py`:
```python
"""manifest —— 机器可读运行清单（FT-08）。不含交易明细。"""
from __future__ import annotations

import json


def build_manifest(*, skill_version, rule_version, contract_version, run_id, run_at,
                   inputs, outputs, field_mapping, config_dict, counts, warnings, errors) -> dict:
    return {
        "skill": "fcs-reconcile",
        "skill_version": skill_version,
        "rule_version": rule_version,
        "contract_version": contract_version,
        "run_id": run_id,
        "run_at": run_at,
        "inputs": inputs,
        "outputs": outputs,
        "field_mapping": field_mapping,
        "config": config_dict,
        "permissions": {"network": "disabled", "source_write": False},
        "counts": counts,
        "warnings": warnings,
        "errors": errors,
    }


def write_manifest(manifest: dict, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_manifest.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/manifest.py skills/fcs-reconcile/tests/unit/test_manifest.py
git commit -m "feat(fcs-reconcile): manifest 运行清单"
```

---

### Task 13: reporter —— 7 张中文工作表

**Files:**
- Modify: `scripts/reporter.py`
- Test: `tests/unit/test_reporter.py`

**Interfaces:**
- Consumes: `models.ResultItem`（来自 `classifier.classify`）、`summary` 字典、`run_params` 字典。
- Produces: `write_workbook(items: list[ResultItem], summary: dict, run_params: dict, path: str) -> None`。生成 7 张工作表：`对账总览 / 待处理事项 / 已匹配 / 重复与冲突 / 数据质量 / 审计明细 / 运行参数`（列见 `docs/contracts/fcs-reconcile/output-contract.md`）；`对账总览` 含隐私运行摘要。

- [ ] **Step 1: 写失败测试**

Create `skills/fcs-reconcile/tests/unit/test_reporter.py`:
```python
from decimal import Decimal
from openpyxl import load_workbook
import reporter
from models import ResultItem, Status


def _item(status, sheet, priority):
    return ResultItem(status=status, priority=priority, sheet=sheet, no="A1",
                      amount_left=Decimal("10.00"), amount_right=Decimal("10.00"),
                      amount_diff=Decimal("0.00"), basis="x", suggested_action="y",
                      left_source_row=2, right_source_row=2)


def test_workbook_has_seven_named_sheets(tmp_path):
    items = [_item(Status.AUTO_MATCHED, "已匹配", "—")]
    s = {"counts": {"已自动匹配": 1}, "match_rate": "1.0000",
         "quantity_reconciled": True, "amount_reconciled": True,
         "left_amount_total": "10.00", "right_amount_total": "10.00", "sum_amount_diff": "0.00"}
    p = tmp_path / "out.xlsx"
    reporter.write_workbook(items, s, {"rule_version": "1.0"}, str(p))
    wb = load_workbook(str(p))
    assert wb.sheetnames == ["对账总览", "待处理事项", "已匹配", "重复与冲突",
                             "数据质量", "审计明细", "运行参数"]
    assert wb["对账总览"]["A1"].value is not None
```

- [ ] **Step 2: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_reporter.py -v`
Expected: FAIL

- [ ] **Step 3: 实现 reporter.py**

Replace `skills/fcs-reconcile/scripts/reporter.py`:
```python
"""reporter —— 生成 7 张中文工作表（技术设计 §7 / 输出契约）。"""
from __future__ import annotations

from openpyxl import Workbook

from models import ResultItem

_SHEETS = ["对账总览", "待处理事项", "已匹配", "重复与冲突", "数据质量", "审计明细", "运行参数"]
_PENDING_COLS = ["优先级", "问题类型", "业务编号", "左侧金额", "右侧金额", "金额差异",
                 "判断依据", "建议动作", "来源行", "复核状态", "复核人", "复核意见"]


def _rows_for(items, sheet):
    return [i for i in items if i.sheet == sheet]


def write_workbook(items: list[ResultItem], summary: dict, run_params: dict, path: str) -> None:
    wb = Workbook()
    ws = {name: (wb.active if idx == 0 else wb.create_sheet(name)) for idx, name in enumerate(_SHEETS)}
    ws["对账总览"].title = "对账总览"

    # 对账总览 + 隐私运行摘要
    ov = ws["对账总览"]
    ov.append(["对账总览"])
    ov.append(["匹配率", summary["match_rate"]])
    ov.append(["数量勾稽", "通过" if summary["quantity_reconciled"] else "不通过"])
    ov.append(["金额勾稽", "通过" if summary["amount_reconciled"] else "不通过"])
    ov.append(["左金额合计", summary["left_amount_total"]])
    ov.append(["右金额合计", summary["right_amount_total"]])
    for status, cnt in summary["counts"].items():
        ov.append([status, cnt])
    ov.append([])
    ov.append(["隐私运行摘要"])
    ov.append(["运行模式", "本地隔离"])
    ov.append(["原始数据进入模型", "否"])
    ov.append(["网络访问", "已禁用"])
    ov.append(["源文件修改", "否"])

    # 待处理事项
    pend = ws["待处理事项"]
    pend.append(_PENDING_COLS)
    for i in _rows_for(items, "待处理事项"):
        pend.append([i.priority, i.status.value, i.no, _s(i.amount_left), _s(i.amount_right),
                     _s(i.amount_diff), i.basis, i.suggested_action,
                     f"L{i.left_source_row or ''}/R{i.right_source_row or ''}", "待复核", "", ""])

    # 已匹配
    matched = ws["已匹配"]
    matched.append(["业务编号", "左侧金额", "右侧金额", "匹配依据", "来源行"])
    for i in _rows_for(items, "已匹配"):
        matched.append([i.no, _s(i.amount_left), _s(i.amount_right), i.basis,
                        f"L{i.left_source_row}/R{i.right_source_row}"])

    # 重复与冲突
    conf = ws["重复与冲突"]
    conf.append(["业务编号", "状态", "候选清单", "冲突原因"])
    for i in _rows_for(items, "重复与冲突"):
        cand = "; ".join(f"row{c.row_id}:{c.no}" for c in i.candidates)
        conf.append([i.no, i.status.value, cand, i.basis])

    # 数据质量
    dq = ws["数据质量"]
    dq.append(["问题类型", "业务编号", "来源行"])
    for i in _rows_for(items, "数据质量"):
        dq.append([i.status.value, i.no, f"L{i.left_source_row or ''}/R{i.right_source_row or ''}"])

    # 审计明细
    audit = ws["审计明细"]
    audit.append(["状态", "业务编号", "左侧金额", "右侧金额", "金额差异", "命中规则", "来源行"])
    for i in items:
        audit.append([i.status.value, i.no, _s(i.amount_left), _s(i.amount_right),
                      _s(i.amount_diff), i.basis,
                      f"L{i.left_source_row or ''}/R{i.right_source_row or ''}"])

    # 运行参数
    rp = ws["运行参数"]
    rp.append(["参数", "值"])
    for k, v in run_params.items():
        rp.append([k, str(v)])

    wb.save(path)


def _s(v) -> str:
    return "" if v is None else str(v)
```

- [ ] **Step 4: 运行确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests/unit/test_reporter.py -v`
Expected: PASS

- [ ] **Step 5: 提交**

```bash
git add skills/fcs-reconcile/scripts/reporter.py skills/fcs-reconcile/tests/unit/test_reporter.py
git commit -m "feat(fcs-reconcile): reporter 7 张中文工作表"
```

---

### Task 14: reconcile.py 编排 + CLI + 端到端/确定性/安全测试

**Files:**
- Modify: `scripts/reconcile.py`
- Test: `tests/golden/test_e2e_golden.py`, `tests/security/test_e2e_isolation.py`
- Create: `tests/golden/inputs/left.csv`, `tests/golden/inputs/right.csv`（脱敏样本）

**Interfaces:**
- Consumes: 以上全部模块。
- Produces: `run(config_obj, *, run_id: str, run_at: str) -> dict`（执行管线，写工作簿与清单，返回 `summary`）；`main(argv: list[str] | None) -> int`（CLI：`--config`，成功打印 summary 的 JSON，返回 0）。
- **顺序**：`guard.block_network()` → 读左右（记 sha256）→ normalize → match → classify → summary → 校验勾稽（不通过则 errors>0 并在 summary 标注）→ reporter 写工作簿（先校验 output 不覆盖输入）→ 复核输入 sha256 不变 → manifest。**只返回 summary**（不返回任何 StdRow/DataFrame）。

- [ ] **Step 1: 造脱敏黄金样本**

Create `skills/fcs-reconcile/tests/golden/inputs/left.csv`:
```csv
单号,金额,日期,对方,方向
A001,100.00,2026-01-01,甲公司,收
A002,200.00,2026-01-02,乙公司,收
A003,300.00,2026-01-03,丙公司,付
A004,50.00,2026-01-04,丁公司,收
```

Create `skills/fcs-reconcile/tests/golden/inputs/right.csv`:
```csv
流水号,发生额,日期,户名,借贷
A001,100.00,2026-01-01,甲公司,收
A002,200.50,2026-01-02,乙公司,收
A003,300.00,2026-01-03,丙公司,付
A009,80.00,2026-01-09,戊公司,收
```
> 预期：A001 已自动匹配；A002 金额差异（差 0.50，默认容差 0）；A003 已自动匹配；A004 左侧单边；A009 右侧单边。

- [ ] **Step 2: 写端到端黄金测试 + 确定性测试（失败）**

Create `skills/fcs-reconcile/tests/golden/test_e2e_golden.py`:
```python
import json
from pathlib import Path
import config as cfg_mod
import reconcile

HERE = Path(__file__).parent
INPUTS = HERE / "inputs"


def _make_config(tmp_path):
    out = tmp_path / "result.xlsx"
    yaml = f"""
left:  {{file: "{INPUTS / 'left.csv'}", sheet: null, header_row: 0, fields: {{no: 单号, amount: 金额, date: 日期, counterparty: 对方, direction: 方向}}}}
right: {{file: "{INPUTS / 'right.csv'}", sheet: null, header_row: 0, fields: {{no: 流水号, amount: 发生额, date: 日期, counterparty: 户名, direction: 借贷}}}}
match: {{primary_key: no, composite_keys: [], amount_tolerance: "0.00", date_tolerance_days: 0, direction_rule: signed, amount_scale: 2}}
output: {{path: "{out}"}}
rule_version: "1.0"
contract_version: "1.0"
"""
    p = tmp_path / "c.yaml"; p.write_text(yaml, encoding="utf-8")
    return cfg_mod.load_config(str(p)), out


def test_golden_counts_and_reconciliation(tmp_path):
    conf, out = _make_config(tmp_path)
    s = reconcile.run(conf, run_id="test", run_at="2026-07-23T00:00:00")
    assert s["counts"]["已自动匹配"] == 2
    assert s["counts"]["金额差异"] == 1
    assert s["counts"]["左侧单边"] == 1
    assert s["counts"]["右侧单边"] == 1
    assert s["quantity_reconciled"] is True
    assert s["amount_reconciled"] is True
    assert out.exists()


def test_determinism_same_summary_twice(tmp_path):
    conf, _ = _make_config(tmp_path)
    s1 = reconcile.run(conf, run_id="r1", run_at="t1")
    conf2, _ = _make_config(tmp_path)
    s2 = reconcile.run(conf2, run_id="r2", run_at="t2")
    assert json.dumps(s1, ensure_ascii=False, sort_keys=True) == \
           json.dumps(s2, ensure_ascii=False, sort_keys=True)   # run_id/时间不影响结果
```

Create `skills/fcs-reconcile/tests/security/test_e2e_isolation.py`:
```python
import socket
from pathlib import Path
import pytest
import config as cfg_mod
import reconcile
import guard

INPUTS = Path(__file__).parent.parent / "golden" / "inputs"


def test_source_files_unchanged_and_network_blocked(tmp_path):
    import integrity
    before = {str(INPUTS / f): integrity.sha256_of(str(INPUTS / f))
              for f in ("left.csv", "right.csv")}
    out = tmp_path / "r.xlsx"
    yaml = f"""
left:  {{file: "{INPUTS / 'left.csv'}", sheet: null, header_row: 0, fields: {{no: 单号, amount: 金额, date: 日期, counterparty: 对方, direction: 方向}}}}
right: {{file: "{INPUTS / 'right.csv'}", sheet: null, header_row: 0, fields: {{no: 流水号, amount: 发生额, date: 日期, counterparty: 户名, direction: 借贷}}}}
match: {{primary_key: no, composite_keys: [], amount_tolerance: "0.00", date_tolerance_days: 0, direction_rule: signed, amount_scale: 2}}
output: {{path: "{out}"}}
rule_version: "1.0"
contract_version: "1.0"
"""
    p = tmp_path / "c.yaml"; p.write_text(yaml, encoding="utf-8")
    reconcile.run(cfg_mod.load_config(str(p)), run_id="r", run_at="t")
    # 源文件未变
    for path, h in before.items():
        assert integrity.sha256_of(path) == h
    # 运行后网络仍被禁
    with pytest.raises(guard.NetworkDisabledError):
        socket.socket().connect(("127.0.0.1", 9))
```

- [ ] **Step 3: 运行确认失败**

Run: `uv run pytest skills/fcs-reconcile/tests/golden skills/fcs-reconcile/tests/security/test_e2e_isolation.py -v`
Expected: FAIL（`reconcile.run` 未实现）

- [ ] **Step 4: 实现 reconcile.py**

Replace `skills/fcs-reconcile/scripts/reconcile.py`:
```python
"""fcs-reconcile 入口（薄编排层）。仅 summary 上交上层；明细留本地。"""
from __future__ import annotations

import argparse
import json
import sys

import classifier
import config as config_mod
import guard
import integrity
import io_reader
import manifest as manifest_mod
import matcher
import normalizer
import reporter
import summary as summary_mod


def run(config_obj: config_mod.ReconcileConfig, *, run_id: str, run_at: str) -> dict:
    guard.block_network()

    left_df, left_sha = io_reader.read_table(config_obj.left)
    right_df, right_sha = io_reader.read_table(config_obj.right)
    before = {config_obj.left.file: left_sha, config_obj.right.file: right_sha}

    left_rows = normalizer.normalize(left_df, config_obj.left.fields, config_obj.match)
    right_rows = normalizer.normalize(right_df, config_obj.right.fields, config_obj.match)

    outcomes = matcher.match(left_rows, right_rows, config_obj.match)
    items = classifier.classify(outcomes)
    s = summary_mod.build_summary(outcomes, len(left_rows), len(right_rows))
    errors = 0 if (s["quantity_reconciled"] and s["amount_reconciled"]) else 1

    integrity.assert_output_not_overwrites_input(
        config_obj.output_path, [config_obj.left.file, config_obj.right.file])
    reporter.write_workbook(items, s, {
        "rule_version": config_obj.rule_version,
        "contract_version": config_obj.contract_version,
        "amount_tolerance": str(config_obj.match.amount_tolerance),
        "date_tolerance_days": config_obj.match.date_tolerance_days,
    }, config_obj.output_path)

    after = {config_obj.left.file: integrity.sha256_of(config_obj.left.file),
             config_obj.right.file: integrity.sha256_of(config_obj.right.file)}
    integrity.verify_unchanged(before, after)

    out_sha = integrity.sha256_of(config_obj.output_path)
    m = manifest_mod.build_manifest(
        skill_version="0.1.0", rule_version=config_obj.rule_version,
        contract_version=config_obj.contract_version, run_id=run_id, run_at=run_at,
        inputs=[{"path": config_obj.left.file, "sha256": left_sha},
                {"path": config_obj.right.file, "sha256": right_sha}],
        outputs=[{"path": config_obj.output_path, "sha256": out_sha}],
        field_mapping={"left": vars(config_obj.left.fields), "right": vars(config_obj.right.fields)},
        config_dict={"amount_tolerance": str(config_obj.match.amount_tolerance),
                     "date_tolerance_days": config_obj.match.date_tolerance_days},
        counts=s["counts"], warnings=0, errors=errors)
    manifest_mod.write_manifest(m, config_obj.output_path + ".manifest.json")
    return s


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="fcs-reconcile")
    parser.add_argument("--config", required=True)
    parser.add_argument("--run-id", default="cli")
    parser.add_argument("--run-at", default="")
    args = parser.parse_args(argv)
    conf = config_mod.load_config(args.config)
    s = run(conf, run_id=args.run_id, run_at=args.run_at)
    print(json.dumps(s, ensure_ascii=False))  # 仅 summary，无明细
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
```

- [ ] **Step 5: 运行全量测试确认通过**

Run: `uv run pytest skills/fcs-reconcile/tests -v`
Expected: PASS（全部）

- [ ] **Step 6: 提交**

```bash
git add skills/fcs-reconcile/scripts/reconcile.py skills/fcs-reconcile/tests/golden skills/fcs-reconcile/tests/security/test_e2e_isolation.py
git commit -m "feat(fcs-reconcile): 编排、CLI 与端到端/确定性/安全测试"
```

---

### Task 15: 收尾 —— 质量门禁与元数据

**Files:**
- Modify: `skills/fcs-reconcile/SKILL_META.yaml`, `skills/fcs-reconcile/CHANGELOG.md`, `skills/fcs-reconcile/requirements.txt`

- [ ] **Step 1: 跑 lint / 类型 / 全量测试**

Run:
```bash
uv run ruff check skills/fcs-reconcile
uv run mypy skills/fcs-reconcile/scripts
uv run pytest skills/fcs-reconcile/tests -q
```
Expected: 全部通过（如 mypy 对 pandas 缺 stubs 报错，可在 pyproject 的 `[tool.mypy]` 加 `[[tool.mypy.overrides]] module=["pandas.*"] ignore_missing_imports=true`）。

- [ ] **Step 2: 更新元数据与依赖清单**

- `SKILL_META.yaml`：`skill_version: "0.1.0"`，`tests.unit/property/golden/security` 从 `pending` 改为 `passing`。
- `CHANGELOG.md`：新增"实现对账引擎（Task 0–14），黄金/属性/安全测试通过"。
- `requirements.txt`：由 `uv export --no-hashes --no-dev` 生成直接依赖（正式发布时改由 `tools/build` 带哈希导出）。

- [ ] **Step 3: 提交并预备合并**

```bash
git add skills/fcs-reconcile/SKILL_META.yaml skills/fcs-reconcile/CHANGELOG.md skills/fcs-reconcile/requirements.txt pyproject.toml
git commit -m "chore(fcs-reconcile): 质量门禁与元数据更新至 0.1.0"
```

之后按 superpowers:finishing-a-development-branch 决定合并/PR。

---

## Self-Review

**1. Spec coverage（对照技术设计）**
- §2 管线/模块划分 → Task 1–14 逐模块覆盖 ✔
- §3 输入配置契约 → Task 3 ✔
- §4 标准化（金额/日期/编号/方向）→ Task 5–7 ✔
- §5 匹配（分阶段/铁律/容差语义/确定性）→ Task 8–9 + 属性/确定性测试 ✔
- §6 状态与分类 → Task 10（含优先级/去向表）✔
- §7 输出契约（7 表 + 复核字段 + 勾稽）→ Task 13 + Task 11 ✔
- §8 运行清单与完整性 → Task 12 + Task 2 + Task 14（前后哈希）✔
- §9 安全（网络隔离/日志脱敏/控制面）→ Task 1 + Task 14 安全测试；仅 summary 返回 ✔
- §10 测试（黄金/属性/边界/确定性/安全）→ Task 8/11/14 覆盖；**边界用例**（危险长编号、多候选、容差边界）见 Task 5/6/8/9 ✔

**2. Placeholder scan**：无 TODO/TBD；每个代码步骤均含完整代码。✔

**3. Type consistency**：`StdRow`/`MatchOutcome`/`ResultItem` 于 Task 0 定义，后续任务签名一致；`match()`/`match_primary()`/`match_composite()`/`build_summary()`/`classify()`/`write_workbook()`/`run()` 名称与参数在各任务间对齐。✔

> 已知留待执行时注意：`config.py` 依赖 `yaml`（PyYAML）；若 Task 0 未装则在 Task 3 前 `uv add pyyaml`。mypy 对 pandas 的 missing stubs 用 overrides 忽略。
