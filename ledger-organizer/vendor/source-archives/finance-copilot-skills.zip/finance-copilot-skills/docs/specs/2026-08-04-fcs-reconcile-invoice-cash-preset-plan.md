# `fcs-reconcile`「发票 ↔ 资金」预设开发计划

> 所属项目：`finance-copilot-skills`
> 文档版本：v0.1　｜　编制日期：2026-08-04　｜　状态：待评审
> 上游文档：[fcs-invoice-check 需求调研](2026-08-04-fcs-invoice-check-demand-research.md) §3.3、§十 第 2 步
> 关联计划：[分阶段开发计划](2026-08-04-staged-development-plan.md)（本计划是其阶段 B 的追加交付块）
> 基线版本：**0.2.2**；阶段 A（v0.3.0）执行中，剩 A5~A8

---

# 一、结论先行

| 问题 | 结论 |
|---|---|
| 调研 §3.3 的判断是否成立 | **一半成立**。「不新增 Skill」成立；「已能表达这一场景、只加配置预设不写代码」**已被实测证伪**，见 §二。 |
| 现有引擎直接跑发票↔资金会怎样 | **产出错误结论，而不是报错**。两种可能的配法：一种把「开票方 ≠ 收款方」静默判为「已匹配·无需处理」（确定性误判，违反 NFR-01）；另一种把它拆成两条方向相反的误导性建议。 |
| 因此必须先做什么 | 引擎新增一条**默认关闭**的对方名称比对规则（T1）。不做这一条，这个预设不该对外交付——它会给出虚假保证。 |
| 版本归属 | 随阶段 B 的 **v0.4.0** 一起发布，**不新增阶段编号、不触发第三次顺延**。理由见 §五。 |
| 版本号 | 工具集 / Skill **minor**；`rule_version` 1.0 → **1.1**（新增可选规则，默认不启用，既有结果不变）；`contract_version` 见 §五.2 的分支。 |
| 开工时点 | **A8 发布之后**。T1 会改 `reporter`，在 A8 前动它等于污染 v0.3.0 的发布内容。唯一可立即做的是 T0。 |
| 这次验证给 NFR-07 的真正结论 | 见 §八。比「公共组件能不能复用」更重要的一条：**跨场景复用时它不报错，而是静默给出错误答案**。 |

---

# 二、实测证据（本计划的地基）

调研 §3.3 写「`fcs-reconcile` 的配置项已能表达这一场景」。这一句未经运行验证，实测结果如下。

**输入**（4 类典型场景，`/tmp` 下临时数据，非仓库资产）：

```text
进项发票.csv   发票号码,价税合计,开票日期,销方名称
               INV001,1000.00,2026-03-01,甲科技有限公司     ← 票款一致
               INV002,2000.00,2026-03-02,乙贸易有限公司     ← 开票方 ≠ 收款方
               INV003,3000.00,2026-03-03,丁材料有限公司     ← 已开票未付款
银行付款.csv   交易流水号,发生额,交易日期,收款方名称
               B001,1000.00,2026-03-01,甲科技有限公司
               B002,2000.00,2026-03-02,丙个体经营户        ← 资金流向第三方
               B004,500.00,2026-03-04,戊服务有限公司        ← 已付款未开票
```

两侧编号体系不同（发票号 vs 银行流水号），主键阶段必然全部落空，匹配实际由复合键承担。因此只有两种配法：

## 2.1 配法 A：`composite_keys: [amount, date]`

```json
{"已自动匹配": 2, "左侧单边": 1, "右侧单边": 1, "match_rate": "0.5000"}
```

结果工作簿「已匹配」表实际内容：

```text
业务编号   左侧金额   右侧金额   匹配依据       来源行
INV001    1000.00   1000.00   复合键唯一一致   L2/R2
INV002    2000.00   2000.00   复合键唯一一致   L3/R3     ← 乙贸易开票、丙个体户收款
```

**INV002 被自动确认为「已匹配」，分类器给的建议动作是「无需处理」。** 而这正是三流合一要查的最典型风险——票款不一致、资金流向第三方。更糟的是：7 张工作表**没有任何一列显示对方名称**（`_PENDING_COLS` 12 列、「已匹配」5 列、「审计明细」7 列，全无往来单位），用户即使逐行看也无从发现。

这不是「能力缺失」，是**确定性误判**——PRD NFR-01 要求误判率 0。

## 2.2 配法 B：`composite_keys: [amount, date, counterparty]`

```json
{"已自动匹配": 1, "左侧单边": 2, "右侧单边": 2, "match_rate": "0.2000"}
```

「待处理事项」实际内容：

```text
中  左侧单边  INV002  2000.00  ...  仅左侧存在  核对该笔是否漏记于右表
中  右侧单边  B002    2000.00  ...  仅右侧存在  核对该笔是否漏记于左表
```

同一笔业务被拆成两条**方向相反且都是错的**建议：右表明明有这笔付款，左表明明有这张发票，真实问题是收款方换了人。用户照建议去「补记漏账」，会离真相更远。金额与日期完全相同的这一对散落在两个状态里，人工也很难看出它们本是一对。

## 2.3 两种配法的共同根因

| 位置 | 事实 |
|---|---|
| [matcher.py:62-79](../../skills/fcs-reconcile/scripts/matcher.py#L62-L79) | 主键阶段只比金额，不看 `counterparty` |
| [matcher.py:87-97](../../skills/fcs-reconcile/scripts/matcher.py#L87-L97) | `_composite_equal` 只按 `composite_keys` 逐字段严格相等；不在键里的字段完全不参与判断 |
| [models.py:43-56](../../skills/fcs-reconcile/scripts/models.py#L43-L56) | `ResultItem` 无 counterparty 字段——即使匹配阶段发现了差异，也传不到报表 |
| [reporter.py:9-11](../../skills/fcs-reconcile/scripts/reporter.py#L9-L11) | 7 张表无往来单位列 |

`counterparty` 在现有引擎里只有一个用途：作为复合键的**匹配键**。它从来不是**校验项**。银行流水对账场景下这够用（户名一致是常态，不一致就是匹配不上），发票场景下不够——**票款不一致恰恰是要报出来的那件事，不是「匹配不上」这件事**。

---

# 三、任务划分与依赖

```text
T0 回写调研文档的错误判断     ← 可立即做，纯文档
─────────────── A8 发布（v0.3.0）之后开工 ───────────────
T1 对方名称比对规则（引擎）─┬─→ T3 第二组黄金答案 ─┐
T2 预设与演示数据 ─────────┘                      ├─→ T5 契约、版本与发布
T4 触发边界扩展 ──────────────────────────────────┘
```

T1 是唯一的硬前置：T2 的预设 YAML 要写 `counterparty_rule`，T3 的期望值要包含「对方不一致」状态。T4 与 T1/T2 无代码耦合，可并行。

---

## Task T0：回写调研文档被证伪的判断

**为什么排第一且不能等**：调研 §3.3 现在写着「已能表达这一场景」「不新增 Skill，落地方式是加配置预设」，读者会据此以为这是个零代码工作。§二 的实测表明配置改不动这件事。留着它就是一处已知错误的事实陈述。

**Files:**
- Modify: [2026-08-04-fcs-invoice-check-demand-research.md](2026-08-04-fcs-invoice-check-demand-research.md) §3.3、§十

- [ ] **Step 1**：§3.3 把「已能表达这一场景」改为「可表达匹配，但**不能表达票款不一致**——`counterparty` 在现有引擎里只是匹配键、不是校验项」，并链接本计划 §二。
- [ ] **Step 2**：§十 第 2 步「零新增 Skill 即交付」保留（仍然成立），补一句「但需先扩展引擎一条可选规则，非纯配置工作，见本计划 T1」。
- [ ] **Step 3**：提交

```bash
git add docs/specs/2026-08-04-fcs-invoice-check-demand-research.md \
        docs/specs/2026-08-04-fcs-reconcile-invoice-cash-preset-plan.md
git commit -m "docs(specs): 发票↔资金预设开发计划；实测证伪调研 §3.3「纯配置即可」的判断"
```

---

## Task T1：可选的对方名称比对规则

**Files:**
- Modify: `skills/fcs-reconcile/scripts/config.py`（新增 `counterparty_rule` + 校验）
- Modify: `skills/fcs-reconcile/scripts/models.py`（新 `Status` + `PRIORITY` / `SHEET` + `ResultItem` 两字段）
- Modify: `skills/fcs-reconcile/scripts/matcher.py`（主键与复合键两阶段都要判）
- Modify: `skills/fcs-reconcile/scripts/classifier.py`（`_ACTION` 新条目 + 透传对方名称）
- Modify: `skills/fcs-reconcile/scripts/reporter.py`（3 张表加列）
- Modify: `skills/fcs-reconcile/tests/unit/test_config.py`、`test_matcher_primary.py`、`test_matcher_composite.py`、`test_classifier.py`、`test_reporter.py`
- Modify: `docs/contracts/fcs-reconcile/input-contract.md`、`output-contract.md`

### 设计要点（逐条都有取舍理由）

| 决定 | 内容与理由 |
|---|---|
| **默认关闭** | `match.counterparty_rule: ignore \| compare`，默认 `ignore` = 现有行为逐字节不变。不默认开启的理由：银行对账场景里户名写法差异是常态（「甲公司」vs「甲公司（北京）」），默认开启会让现有用户的匹配率暴跌，**把一个新场景的需求强加给所有既有用户**。 |
| **不做模糊匹配** | `compare` 模式下只做「相等 / 不相等」二分，不做简称还原、不去公司后缀、不算相似度。依据 PRD §4 确定性优先——模糊匹配会引入不确定判定，而这一格的结论直接关系到用户是否去核实一笔可疑资金。写法差异导致的误报是**安全方向的误报**，宁可多看一眼，不可漏掉第三方收款。 |
| **与 `composite_keys` 互斥** | `counterparty_rule: compare` 时 `counterparty` **不得**出现在 `composite_keys`，否则 `ConfigError`。二者同时启用逻辑上矛盾：进了匹配键就不可能出现「匹配上但不一致」。这正是发票场景要的分工——**用 amount+date 匹配，用 counterparty 校验**。 |
| **新状态归「待处理事项」且优先级「高」** | `COUNTERPARTY_DIFF = "对方不一致"`，`PRIORITY` 高、`SHEET` 待处理事项。票款不一致是三流合一的核心风险，与「金额差异」同级。 |
| **不做归一化（本次）** | `counterparty` 目前走 `_str_cell` 只 `strip()`，不过 `_clean` 的 NFKC 归一（`no` / `amount` / `date` / `direction` 都过）。这是既有的不一致，但**顺手统一会改变现有复合键匹配结果**（全角/半角差异消失后原本不匹配的可能匹配上），属规则语义变更。列为 §七 待定项，不并入本次。 |

### 匹配阶段的落点

- **主键阶段**（`match_primary`）：`len(lc)==1 and len(rc)==1 and diff==0` 时，若 `compare` 且两侧 counterparty 不等 → 改判 `COUNTERPARTY_DIFF`（而非 `AUTO_MATCHED`）。
- **复合键阶段**（`match_composite`）：互唯一匹配成功后追加同样判断。
- **两侧任一 counterparty 缺失**：按 `_composite_equal` 的既有立场处理——缺失不视为相等，改判 `COUNTERPARTY_DIFF` 并在判断依据里写明「对方名称缺失，无法确认」。**不静默放行**。

- [ ] **Step 1: 先写失败测试**

覆盖 4 条：`ignore` 下行为与现状完全一致；`compare` 下主键阶段命中改判；`compare` 下复合键阶段命中改判；`compare` + counterparty 进 composite_keys → `ConfigError`。

```bash
uv run pytest skills/fcs-reconcile/tests/unit/ -v    # Expected: FAIL
```

- [ ] **Step 2: 实现 6 个模块的改动**

- [ ] **Step 3: 报表加列**

「待处理事项」12 → 14 列（`左侧对方`、`右侧对方` 插在「金额差异」之后、「判断依据」之前）；「已匹配」5 → 7 列；「审计明细」7 → 9 列。

> **加列会让 A2 落的第一组快照红**，这是预期的，也正是它该有的行为。重生成时必须逐张核对，并在提交说明里写明差异只有两类：新增两列、`ignore` 下这两列取自源数据。**若出现第三类差异，说明改动越界了，回退重做。**

- [ ] **Step 4: 负路径确认——默认关闭真的没改变行为**

```bash
# 不重生成快照，直接跑第一组黄金答案：必须全绿（证明 ignore 模式下逐单元格未变）
uv run pytest skills/fcs-reconcile/tests/golden/ -v
```

⚠ 这一步在 Step 3 加列**之前**跑。加列之后它必然红（列数变了），届时该结论就验不了了。顺序不能颠倒。

- [ ] **Step 5: 重生成第一组快照并逐张核对**

```bash
uv run python skills/fcs-reconcile/tests/golden/regen_snapshots.py
git diff skills/fcs-reconcile/tests/golden/expected/    # 逐行看，确认只有上述两类差异
```

- [ ] **Step 6: 契约回改**

`input-contract.md` 的 `ReconcileConfig` 骨架加 `counterparty_rule` 与互斥校验说明；`output-contract.md` 的「人工复核字段」与「已匹配」「审计明细」列表加两列，并新增「对方不一致」状态说明。

- [ ] **Step 7: 提交**

```bash
git add skills/fcs-reconcile/ docs/contracts/fcs-reconcile/
git commit -m "feat(reconcile): 新增可选的对方名称比对规则（默认关闭），报表补往来单位列"
```

---

## Task T2：「发票 ↔ 资金」配置预设与演示数据

**Files:**
- Create: `skills/fcs-reconcile/examples/invoice-cash-preset.yaml`（带逐行注释的可直接改用配置）
- Create: `skills/fcs-reconcile/examples/gen_invoice_cash_demo.py`（脱敏演示数据生成）
- Modify: `skills/fcs-reconcile/examples/README.md`
- Modify: `skills/fcs-reconcile/references/matching-rules.md`（分阶段匹配表加「对方不一致」一行）

### 预设必须显式处理的 4 处输入前置

这些不是可选说明——任一处配错，结果就是**静默错误**而非报错。实测确认：

| # | 前置 | 配错的后果 |
|---|---|---|
| 1 | **`direction_rule: none`** | 发票导出没有收付方向列。若沿用对账场景默认的 `signed`，[config.py:59](../../skills/fcs-reconcile/scripts/config.py#L59) 会直接 `ConfigError` —— 这一处是 fail fast，是好的。 |
| 2 | **银行付款金额取绝对值** | `_composite_equal` 对 amount 严格相等。发票价税合计为正，若银行「发生额」导出带负号，两侧永不相等 → **全部报成双向单边**，看起来像「一笔都对不上」。 |
| 3 | **两侧 `no` 各映射到自己的唯一编号**（发票号码 / 银行流水号） | `no` 是必填字段。映射到日期或摘要会产生大量重复 `no` → 全部落入「重复编号 / 多候选冲突」。**两侧编号体系不同是本场景的预期状态**，不是配置错误，预设里要写明这一点，否则使用者会以为自己配错了。 |
| 4 | **`counterparty_rule: compare`**，且 `counterparty` 不进 `composite_keys` | 见 §二 的两种失败配法。这是本预设存在的核心理由。 |

### `date_tolerance_days` 的取舍要写进预设注释

先开票后付款是常态，日期容差不给就大量匹配不上。但放宽有代价：`match_composite` 要求**互唯一**才放行（[matcher.py:113-118](../../skills/fcs-reconcile/scripts/matcher.py#L113-L118)），同一供应商在容差窗口内的多笔等额付款会互相成为候选而全部落空，报成双向单边。预设给一个保守默认值并写明这条代价，同时在 T3 的黄金答案里钉一个「等额多笔」用例把这个行为固定住。

### 预设文档必须写明「产不出什么」

依调研 §五 的硬边界，预设头部注释逐条列出：不判断发票真伪、不查失控发票与走逃企业、不做进销项品类勾稽（那是 `fcs-invoice-check` 的范围且未立项）、不出任何税务定性结论、不测算补税与滞纳金。

> 这份预设最大的风险不是技术风险，是**被当成「税务自查工具」使用**。输出只能是「以下 N 组数据触发了规则 X，请人工核实」。

- [ ] **Step 1**：写 `invoice-cash-preset.yaml`，逐行注释上述 4 处前置与日期容差取舍
- [ ] **Step 2**：写 `gen_invoice_cash_demo.py`，生成 6 类场景的脱敏数据（与 T3 黄金答案输入**不同**的数据）
- [ ] **Step 3**：跑通预设并人工核对输出符合预期
- [ ] **Step 4**：更新 `examples/README.md` 与 `references/matching-rules.md`
- [ ] **Step 5**：提交

```bash
git add skills/fcs-reconcile/examples/ skills/fcs-reconcile/references/matching-rules.md
git commit -m "feat(reconcile): 发票↔资金配置预设与演示数据，含 4 处输入前置与硬边界说明"
```

---

## Task T3：第二组黄金答案（发票场景）

**Files:**
- Modify: `skills/fcs-reconcile/tests/golden/regen_snapshots.py`（参数化为多场景）
- Create: `skills/fcs-reconcile/tests/golden/inputs/invoice/{invoices.csv,payments.csv}`
- Create: `skills/fcs-reconcile/tests/golden/expected/invoice-result.snapshot.json`、`invoice-manifest.snapshot.json`
- Modify: `skills/fcs-reconcile/tests/golden/test_e2e_golden.py`（按场景参数化）

**先解决基础设施问题**：现在黄金答案是**单场景硬编码**——`make_config()` 写死一份 YAML、`WORKBOOK_SNAPSHOT` / `MANIFEST_SNAPSHOT` 是单一路径常量、5 个用例都直接调 `run_golden()`。直接加第二组会变成复制粘贴两份。

先引入一个 `GoldenCase`（场景名、输入文件、match 配置、两个快照路径），`make_config` / `run_golden` 收该参数，测试用 `@pytest.mark.parametrize` 遍历。**这是纯重构，第一组快照内容不得变化**——先只重构、跑通、确认全绿，再加第二组。

> 顺带记一处：[tools/verify/cases.py:52-77](../../tools/verify/cases.py#L52-L77) 内联了**第三份**同内容配置 YAML（`regen_snapshots` 的注释只提到「两处」）。本次不动它——安全基线是黑盒校验，与黄金答案的关注点不同，强行共用会把两个目的耦在一起。但在 `cases.py` 补一句注释指明它与 `regen_snapshots` 的配置是有意的两份。

### 6 类场景（对应 §二 的输入再扩两类）

票款一致自动匹配 · **对方不一致** · 已开票未付款 · 已付款未开票 · 容差窗口内等额多笔（多候选落空）· 数据质量问题（空销方名称）。

- [ ] **Step 1**：重构 `regen_snapshots.py` 为多场景，第一组快照不变，`pytest` 全绿
- [ ] **Step 2**：造发票场景输入数据（覆盖 6 类）
- [ ] **Step 3**：写第二组快照对比用例，确认失败（快照不存在）
- [ ] **Step 4**：生成快照
- [ ] **Step 5**：**人工逐张核对 7 张表**

⚠ 依 A2 的既有教训（[分阶段计划](2026-08-04-staged-development-plan.md) §四 Task A2 Step 4）：快照测试的价值全部建立在「首次快照是对的」之上。重点核对「对方不一致」那几行的判断依据与建议动作文案，以及等额多笔用例是否如预期落为单边。

- [ ] **Step 6**：连跑两次确认无易变字段泄漏
- [ ] **Step 7**：提交

```bash
git add skills/fcs-reconcile/tests/golden/
git commit -m "test(golden): 黄金答案参数化为多场景，新增发票↔资金 6 类场景逐单元格快照"
```

---

## Task T4：触发边界扩展（FT-03）

**Files:**
- Modify: `skills/fcs-reconcile/SKILL.md`（`description` + 正文「何时使用」）
- Modify: `tests/triggering/corpus.yaml`
- Modify: `tests/triggering/test_trigger_boundary.py` ⚠ **有一处正则缺陷会挡住本任务**
- Modify: `docs/prd/Finance-Copilot-Skills-PRD-v0.2.md` §8.2

### 两处会挡路的连带问题（实测确认）

| # | 问题 | 事实 |
|---|---|---|
| ① | **守卫正则认不出多段 Skill 名** | [test_trigger_boundary.py:29](../../tests/triggering/test_trigger_boundary.py#L29) 的 `SKILL_NAME = re.compile(r"fcs-[a-z]+")` 对 `fcs-invoice-check` 只提取出 `fcs-invoice`。corpus 里写 `belongs_to: fcs-invoice-check` 会被 `test_negative_cases_have_a_real_destination` 判为「去处不存在」。现有 4 个去处都是单段名，所以至今未暴露。改为 `fcs-[a-z]+(?:-[a-z]+)*`。 |
| ② | **PRD §8.2 候选清单不含 `fcs-invoice-check`** | 实测确认全文无此串。守卫的去处白名单从 PRD 正文提取，不补就红。 |

②的处置要谨慎：**加进 §8.2 候选清单 ≠ 立项**——§8.2 开头写明「后续方向必须经过独立需求验证，不因工具集扩展目标而自动立项」。补的这一行要写明「线索存档，未立项」并链接调研文档，避免读者误读为已排期。

### description 扩写的双向约束

加「发票与付款核对」是必须的——不写进 `description`，宿主在该场景下不会选中本 Skill（守卫 `test_description_covers_claimed_scope` 就是守这个）。但扩能力必须同时收边界：**单侧发票的结构特征扫描（进销项背离、异常开票特征）不归本 Skill**，依调研 §六 的触发边界。因此：

- `boundary_keywords.must_contain` 追加 `发票`
- `boundary_keywords.must_exclude_scope` 追加 `发票结构自查`（或同义表述），并在 `description` 里明确排除
- `should_trigger` 追加：`进项发票和银行付款记录对一下`、`看看每张发票的钱是不是真的付给了开票方`、`哪些发票已经开了但还没付款`
- `should_not_trigger` 追加：`查一下我们的进项和销项品类对不对得上`（→ `fcs-invoice-check`）、`看看哪些月份开票量突然暴增`（→ `fcs-invoice-check`）

- [ ] **Step 1**：修守卫正则，补 PRD §8.2 一行
- [ ] **Step 2**：改 `SKILL.md` 的 `description` 与正文「何时使用 / 不使用」
- [ ] **Step 3**：补 corpus 语料与边界关键词
- [ ] **Step 4**：跑通

```bash
uv run pytest tests/triggering/ -v          # Expected: PASS
```

- [ ] **Step 5**：提交

```bash
git add tests/triggering/ skills/fcs-reconcile/SKILL.md docs/prd/
git commit -m "test(triggering): 发票↔资金触发语料与边界；修守卫正则对多段 Skill 名的漏认"
```

---

## Task T5：契约版本、CHANGELOG 与发布

**前置**：T1~T4 全部完成；A8（v0.3.0）已发布。

**Files:**
- Modify: `skills/fcs-reconcile/SKILL_META.yaml`、`pyproject.toml`、`scripts/version.py`、`SKILL.md`
- Modify: 根 `CHANGELOG.md`、`skills/fcs-reconcile/CHANGELOG.md`
- Modify: [分阶段开发计划](2026-08-04-staged-development-plan.md) 阶段 B 交付物表 + §六门禁矩阵

- [ ] **Step 1**：版本号六处同步（漂移守卫会逐条断言）
- [ ] **Step 2**：`SKILL_META.yaml` 的 `rule_version: "1.1"`、`contract_version` 按 §五.2 定
- [ ] **Step 3**：CHANGELOG 两份，按 versioning.md §5 第 3 步记全 8 项

**已知限制必须写进去的两条**：① 对方名称比对不做归一化，写法差异会产生误报（安全方向，见 §七 待定项）；② 容差窗口内等额多笔仍落为双向单边，属 `match_composite` 互唯一约束的既有行为。

**必须明写**：`counterparty_rule` 默认 `ignore`，**既有配置的对账结果与 0.3.x 完全一致**；结果工作簿新增两列，旧下游若按列序号取值需调整。

- [ ] **Step 4**：全量门禁 + 发布（七步，见 versioning.md §5）

---

# 四、验收门禁

沿用[分阶段计划](2026-08-04-staged-development-plan.md) §六矩阵，本计划追加 3 条：

| 门禁 | 检查方式 |
|---|---|
| `counterparty_rule: ignore` 下既有对账结果逐单元格不变 | T1 Step 4（加列前跑第一组快照全绿） |
| 第一组快照重生成的差异**只有**「新增两列」一类 | T1 Step 5 人工逐行看 `git diff` |
| 发票场景 6 类全部有逐单元格期望值，且「对方不一致」不落入「已匹配」 | T3 第二组快照 |

---

# 五、版本与排期归属

## 5.1 为什么并入 v0.4.0 而不新增阶段

[分阶段计划](2026-08-04-staged-development-plan.md) 已把 v0.4.0 分给阶段 B（供应链与发布加固）。三个选项里选并入：

| 选项 | 评价 |
|---|---|
| 新插入 v0.4.0「对账场景扩展」，B~F 各顺延一位 | ❌ **第三次顺延**。§七风险表已把「路线图顺延引发编号混乱」列为风险，代价不划算 |
| 作为 v0.3.1 patch 发布 | ❌ 名不副实。versioning.md §3 表格里「新增面向用户的能力」明确是 minor，patch 会低报变更 |
| **并入 v0.4.0，作为阶段 B 的追加交付块** | ✅ **建议**。与供应链加固无强依赖，可并行开发、同批发布；单独发一版的价值不足以抵一次顺延的成本 |

阶段 B 的退出条件相应追加本计划 §四 的 3 条。

## 5.2 `contract_version` 的分支（取决于 A8 怎么处置）

[分阶段计划](2026-08-04-staged-development-plan.md) §4.0 记了 3 处待定夺的契约偏差，建议「①② 并入 A8 并 bump 到 1.1」。因此：

| A8 的处置 | 本次 `contract_version` |
|---|---|
| A8 修了 ①②，已发 `1.1` | 本次 → **`1.2`** |
| A8 未修，写进已知限制，仍是 `1.0` | 本次 → **`1.1`**，且**建议顺手把 ①② 一并修完**——同一份 `output-contract.md` 与 `reporter.py` 反正要动，分两次改两次核对快照，成本更高 |

**T5 开工前先确认 A8 的实际处置**，不要凭本表假设。

## 5.3 为什么 `rule_version` 是 1.1 而不是 2.0

versioning.md §3 表格里「匹配/分级/勾稽规则语义变化（相同输入结果可能不同）」对应规则**主**版本。字面看新增判定规则该升 2.0，但判据的括号是「相同输入结果可能不同」——本次默认 `ignore`，**既有配置的既有输入结果逐单元格不变**，只有显式开启新选项才不同。升 2.0 会让用户以为自己的历史对账结果需要重跑复核，这是错误的信号。故取「次」版本 1.1，并在 CHANGELOG 里写明这个判断理由。

---

# 六、风险与应对

| 风险 | 影响 | 应对 |
|---|---|---|
| **新规则默认开启，冲掉既有用户匹配率** | 银行户名写法差异被大量报成「对方不一致」，现有对账场景可用性下降 | 默认 `ignore`；T1 Step 4 在加列前用第一组快照实证「默认不改变行为」 |
| **第一组快照重生成掩盖回归** | 把 T1 引入的意外改动钉死为期望值 | Step 4 与 Step 5 的顺序不可颠倒；`git diff` 逐行核对，出现第三类差异即回退 |
| **预设被当成税务自查工具** | 工具本身成为风险源（调研 §五） | 预设头部注释与 `SKILL.md` 同时写明硬边界；输出语气约束沿用调研 §五 |
| **counterparty 写法差异导致误报过多** | 用户开始习惯性忽略「对方不一致」，等于该规则失效 | 本次不做归一化（不确定性成本更高），但**必须在真实数据上量一次误报率**——若过高，§七 的归一化待定项就要转为正式任务，而不是让用户忍 |
| **发票场景匹配率天然偏低被误读为工具缺陷** | 用户以为工具不好用 | 预设注释写明：两侧编号体系不同，匹配全靠 amount+date，匹配率低于银行对账是**预期**；`match_rate` 在本场景不是质量指标 |
| **T1 在 A8 发布前抢跑** | 污染 v0.3.0 发布内容，A2 快照红导致 A8 无法收尾 | §三 依赖图已标；T0 是唯一可提前做的任务 |

**回滚**：回滚点为 v0.3.0。回滚会同时退回报表两列与 `counterparty_rule`，须在 CHANGELOG 写明。

---

# 七、待定项（不并入本次，但要记着）

| # | 事项 | 为什么不并入 |
|---|---|---|
| 1 | **`counterparty` 的 NFKC 归一化** | 与 `no` / `amount` / `date` / `direction` 不一致（那四个都过 `_clean`）。但补上会改变现有复合键匹配结果，属规则语义变更，应与「误报率实测」一起决策 |
| 2 | **`tools/verify/cases.py` 是否为发票场景注册第二个基线用例** | `CASES` 现在是 `{skill: factory}`，一个 Skill 一个用例。发票场景与对账场景走同一份代码路径、安全属性相同，为它改 `CASES` 结构等于凭一个样本设计通用形态——正是 `cases.py` 文件头注释在克制的事 |
| 3 | **「应附未附凭证清单」** | 调研 §四 提到合同/物流单据只能输出待补清单。属新增输出块，与本次的匹配规则改动无关，待真实用户确认是否需要 |

---

# 八、这次验证给 NFR-07 的结论

[分阶段计划](2026-08-04-staged-development-plan.md) 阶段 C 把 NFR-07（共享能力通过稳定契约复用）的检验点定在「第二个 Skill 落地时能否抽出共享库」。本次跨场景复用提前给出了一条更硬的观察，建议回写进阶段 C：

> **`fcs-reconcile` 的契约在发票↔资金场景下不是「不够用」，是「静默给出错误答案」。**
>
> 配置项齐全、加载校验全过、勾稽全部通过、`match_rate` 0.5、退出码 0——一个把资金流向第三方判为「无需处理」的结果，在所有既有守卫下都是绿的。原因是 `counterparty` 在原场景里的角色（匹配键）与新场景需要的角色（校验项）不同，而契约只表达了字段**存在**，没表达字段的**语义角色**。
>
> 对阶段 C 的含义：判断公共组件能否复用，不能只看「配置项是否表达得下」，要看**换场景后错误结论是否会被现有守卫拦住**。本次是靠一次手工实跑发现的，92 项测试一条都没红。抽象共享库时，这类「同一字段在不同场景下语义角色不同」的地方，是最该先写守卫的地方。

---

> 本计划只定开发顺序与验收门禁，不改变 PRD 定义的产品方向与调研文档的立项结论——
> `fcs-invoice-check` 仍是**存档不立项**，本计划交付的是 `fcs-reconcile` 在发票场景下的能力扩展。
> 与 PRD 冲突时以 PRD 为准；与 CHANGELOG 记载的事实冲突时以 CHANGELOG 为准（versioning.md §6）。
