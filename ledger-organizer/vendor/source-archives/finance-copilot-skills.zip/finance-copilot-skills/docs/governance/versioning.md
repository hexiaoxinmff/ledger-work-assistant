# 统一版本规划

> 治理文档。对应 PRD §10.2「版本记录」、NFR-09「规则与输出契约版本化」。
> 本文件是版本号取值与 bump 时机的唯一依据；与其冲突的散落说明以本文件为准。

## 1. 为什么要"统一规划"

版本号在本仓库有四层含义（工具集、Skill、规则、契约），各自记在不同文件里。
四层各自演进本身是对的——**规则变了不等于契约变了**——但如果没有一处写清
"哪层什么时候动、事实源在哪"，就会出现同一个版本号在 `pyproject.toml`、
`SKILL_META.yaml`、运行清单与 CHANGELOG 里各写一份、改版本时只改一处的漂移。

运行清单（FT-08）把 `skill_version` / `rule_version` / `contract_version` 写进每次
运行的审计证据里；NFR-05 要求"相同输入、配置与规则版本必须产生相同结果"。
**版本号漂移会直接让审计证据失真**——这是本文件存在的理由，不是文档洁癖。

## 2. 四层版本与事实源

| 层 | 含义 | 事实源（唯一） | 派生位置 |
|---|---|---|---|
| **工具集版本** | 一次仓库级发布 | `pyproject.toml` `[project].version` | 根 `CHANGELOG.md` 最新条目、git tag `vX.Y.Z`、README |
| **Skill 版本** | 单个 Skill 面向用户的变更 | `skills/<skill>/SKILL_META.yaml` `skill_version` | 该 Skill 的 `CHANGELOG.md`、`scripts/version.py`、`SKILL.md`、运行清单 |
| **规则版本** | 匹配 / 分级 / 勾稽规则的语义 | `SKILL_META.yaml` `rule_version` | 运行配置 `rule_version`、运行清单、结果工作簿"运行参数"表 |
| **契约版本** | 输入 / 输出契约 | `SKILL_META.yaml` `contract_version` | `docs/contracts/<skill>/*.md`、运行清单、结果工作簿 |

## 3. 什么时候 bump 哪一层

工具集与 Skill 版本遵循[语义化版本](https://semver.org/lang/zh-CN/)；规则与契约版本用
`主.次` 两段。

| 变更 | 工具集 | Skill | 规则 | 契约 |
|---|:---:|:---:|:---:|:---:|
| 匹配/分级/勾稽规则语义变化（相同输入结果可能不同） | minor | minor | **主** | — |
| 规则参数默认值调整（结果可能不同但判定逻辑不变） | patch | patch | **次** | — |
| 输入或输出契约不兼容变更（旧配置/旧下游会失效） | **major**（1.0 前 minor） | **major**（1.0 前 minor） | — | **主** |
| 契约新增可选字段（向后兼容） | minor | minor | — | **次** |
| 新增 Skill / 新增面向用户的能力 | minor | minor | — | — |
| 缺陷修复，规则语义与契约都不变 | patch | patch | — | — |
| 安装方式、文档、元数据（不改任何运行行为） | minor 或 patch，见 §3.1 | 同工具集 | — | — |
| 仅内部重构、测试、CI（用户不可见） | 不 bump | 不 bump | — | — |

> **规则/契约版本一经发布只增不改。** 想"修正"某个已发布规则版本的语义，只能发新版本号——
> 已落盘的运行清单引用的是旧版本号，改写它等于篡改审计证据。

### 3.1 文档与安装方式变更算 minor 还是 patch

判据是**用户要不要为此重做一次动作**：

- 用户需要重新执行安装 / 升级动作（新增受支持的代理、安装路径或步骤变化）→ **minor**。
- 用户什么都不用做（措辞、错别字、内部链接）→ **patch**。

### 3.2 单 Skill 阶段：Skill 版本与工具集版本对齐

**当前仓库只有一个 Skill（`fcs-reconcile`），`skill_version` 与工具集版本保持同值。**
只有一个 Skill 时两者分叉没有信息量，只会让"用户看到的版本"与"运行清单里的版本"对不上。

**解耦条件（硬性）**：第 2 个 Skill 落地后立即解耦——那时工具集版本表示"发布批次"，
各 `skill_version` 独立演进（这正是 FT-02「每个 Skill 可独立安装、升级」的要求，
一个 Skill 的改动不应迫使另一个 Skill 改版本号）。解耦时须同步删除
`tests/supply_chain/test_version_consistency.py` 中标注了本节的那一条断言。

## 4. 漂移守卫

`tests/supply_chain/test_version_consistency.py` 是机器守卫，随 `uv run pytest` 在 CI 执行，
断言：

1. `pyproject.toml` 的版本 == 根 `CHANGELOG.md` 最新版本条目；
2. 每个 Skill：`SKILL_META.yaml` `skill_version` == 该 Skill `CHANGELOG.md` 最新条目
   == `scripts/version.py` 的 `SKILL_VERSION`（若该 Skill 有此模块）；
3. `SKILL.md` 正文提到的版本号与 `skill_version` 一致；
4. 所有版本号形如 `X.Y.Z`；根与各 Skill 的 CHANGELOG 里没有遗留的 `[未发布]` 占位；
5. §3.2 的单 Skill 对齐（仅在 Skill 数为 1 时生效）。

**运行期的 `skill_version` 只从 `scripts/version.py` 取**，不在业务代码里散写字面量——
`reconcile.py` 曾硬编码 `skill_version="0.1.0"`，与 `SKILL_META.yaml` 各写一份，
正是上面第 2 条要防的漂移。

## 5. 发布流程

1. 依 §3 定版本号，改 `pyproject.toml`；
2. 改各受影响 Skill 的 `SKILL_META.yaml`（`skill_version`，必要时 `rule_version` /
   `contract_version` / `status` / `platforms`）与 `scripts/version.py`；
3. 根 `CHANGELOG.md` 与各 Skill `CHANGELOG.md` 各加一条带日期的版本条目
   （格式见 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)），
   并记录 PRD §10.2 要求的：Skill / 规则 / 契约 / 依赖版本、支持平台、安全测试状态、
   已知限制、回滚版本；
4. 跑质量门禁 `uv run ruff check . && uv run mypy . && uv run pytest`；
5. 打 tag `vX.Y.Z`（工具集版本，带 `v` 前缀）；
6. **建 GitHub Release**：
   ```bash
   gh release create vX.Y.Z --verify-tag --latest \
     --title "vX.Y.Z — <主题>" --notes-file <notes.md>
   ```
   **tag 不等于 Release。** tag 是 git 对象，Release 是 GitHub 平台层的独立实体，必须显式
   创建；只打 tag 的话 `/releases` 页面与仓库首页的 Releases 栏都是空的，**使用者看不到
   任何版本号**（这正是 §7 记录的那次补建要解决的问题）。正文取根 `CHANGELOG.md` 对应版本
   的段落，两处要注意：
   - **相对链接必须改写为指向该 tag 的绝对 URL**。Release 正文不按仓库根解析相对路径，
     `[LICENSE](LICENSE)` 这类写法会失效；指向 tag 而非 `main`，读者看到的才是该版本发布
     当时的文件状态——这与运行清单钉住版本号是同一个道理。
   - 只有最新版本加 `--latest`，补建历史版本时用 `--latest=false`，否则首页的"最新版本"
     会被历史版本抢走。
7. 发布状态（`SKILL_META.yaml` `status`）按状态机 `Experimental → Preview → Stable →
   Deprecated → Retired` 单独演进，**与版本号无关**——`0.2.0` 仍可以是 `Experimental`。

**回滚点**：每个版本条目须写明可回滚到的上一个版本号。回滚是切 tag，不是改历史条目。

## 6. 与 PRD 路线图的关系

PRD §8.3 版本路线图里的 `v0.1` / `v0.2` … 指的是**工具集版本**，与本文件第一层同一含义。
路线图是计划、CHANGELOG 是事实；两者不一致时以 CHANGELOG 为准，并回改路线图说明顺延。

## 7. 已知版本历史的特殊情况

`v0.1.0`（2026-07-24，安全底座与对账参考实现）在工程上完成，但**当时未打 git tag**，
根 CHANGELOG 里长期停留在 `[未发布]`。`v0.2.0` 发布时把它追认为正式条目并补上日期。

`v0.1.0` 的 tag 已于 `v0.2.1` 发布时**补打**，指向 `f440f8d`。此前本节写的是"不做追加补打，
因为补一个日期与提交都对不上的 tag 比没有 tag 更容易误导"——复核后该顾虑不成立：
`f440f8d` 的提交日期是 2026-07-24，与 CHANGELOG 记载的 0.1.0 日期一致，且它是 0.2.0
工作开始前的最后一个提交，即 0.1.0 的工程收尾点，日期与提交都对得上。tag 说明里注明了
"于 2026-08-04 补打"，不伪装成当时所打。

**补打 tag 的判据**（后续遇到同类情况照此处理）：能唯一定位到该版本的收尾提交、且该提交
日期与 CHANGELOG 条目日期一致时，补打并在 tag 说明里注明补打日期；定位不到或日期矛盾时，
不补——此时缺 tag 比错 tag 更诚实。

`v0.1.0` ~ `v0.2.2` 四个版本的 **GitHub Release 于 2026-08-04 一次性补建**。此前四个 tag
都已推到远端，但一个 Release 都没有，`/releases` 页面与仓库首页的 Releases 栏因此长期为空，
**使用者看不到任何版本号**。原因不是漏做，而是 §5 发布流程当时只到"打 tag"、没有建 Release
这一步——照文档执行到底也不会产生 Release，故本次同时补上了 §5 第 6 步。补建的正文取自各版本
CHANGELOG 段落原文（未改写历史条目），相对链接绝对化到各自 tag，`v0.2.2` 标为 latest。

**这一致性没有机器守卫**（§4 的两个守卫都不含它）：断言"每个 CHANGELOG 条目都有对应 Release"
要联网调 GitHub API，会让离线开发与 CI 变得不确定，代价高于收益。它靠 §5 第 6 步的流程约束，
漏了就会在仓库首页直接看出来——这是少数"用眼睛比用断言更可靠"的一致性。
