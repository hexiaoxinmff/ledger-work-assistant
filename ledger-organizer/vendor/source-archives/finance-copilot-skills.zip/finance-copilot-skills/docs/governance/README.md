# docs/governance —— 治理文档

存放工具集级治理规范。已落地：

| 文档 | 内容 |
|---|---|
| [versioning.md](versioning.md) | **统一版本规划**：四层版本（工具集 / Skill / 规则 / 契约）的事实源与 bump 时机、单 Skill 阶段的对齐规则与解耦条件、漂移守卫、发布流程与回滚点 |
| [agent-install.md](agent-install.md) | **多代理安装矩阵**（FT-11）：各代理用户级/项目级 skills 路径表（**路径唯一事实源**）、"正式验证"与"仅格式兼容"的区分、9 项验证项清单、安装期联网与运行期禁网的界线 |

待落地：

- **立项条件**（PRD §10.2）：新 Skill 何时可立项。
- **发布状态机**：`Experimental → Preview → Stable → Deprecated → Retired`；
  各 Skill 当前状态记录在其 `SKILL_META.yaml` 的 `status` 字段
  （与版本号无关，见 [versioning.md](versioning.md) §5）。
- **弃用与回滚**：弃用期、停止维护流程（版本回滚见 [versioning.md](versioning.md) §5）。
- **测试与评测规范**：Skill 级 / 工具集级 / 独立前向测试（PRD §10.1）。
- **发布 / 签名 / SBOM 规范**：见 [tools/release](../../tools/release/)。
- **Skill 目录（catalog）**（FT-01）：随 Skill 数量增长再落地，可由各
  `SKILL_META.yaml` 生成为 `catalog.md`。
