# 多代理安装矩阵

> 治理文档。对应 FT-11「跨平台支持」、FT-02「独立安装」、NFR-08「可移植性」。
> **本文件的路径表是唯一事实源**，README 的安装提示词由它派生，
> 由 `tests/cross_platform/test_install_paths.py` 守卫两处一致。

## 1. 为什么安装统一走提示词

本工具集不提供安装脚本、不提供包管理器条目，安装方式统一是**一段贴给代理的提示词**。理由：

- **安装动作本身要可读、可审查**。安装脚本对使用者是黑盒；一段中文提示词，财务人员
  自己能看懂它要复制什么、往哪里写、动了哪些目录——与「可核验」原则一致。
- **不为分发引入新的信任面**。装脚本要么让用户 `curl | bash`，要么让仓库多一个需要签名与
  供应链保障的可执行产物（§7.2）。提示词不新增可执行物。
- **一套说明适配所有代理**。各代理的差异只落在"目标目录"这一个变量上（见 §2 路径表），
  换宿主就换一行路径，不必为每家维护一份安装器。
- **面向的是财务人员，不是工程师**。"复制这段话粘贴给它"比"打开终端执行以下命令"
  的完成率高得多，且不要求用户理解 shell。

**明确不做**：不提供 `install.sh` / `install.ps1`、不提供一键联网安装器、不在安装期
向任何服务上报安装事件。

## 2. 路径表

| 代理 | 用户级 skills 目录 | 项目级 skills 目录 | 支持级别 |
|---|---|---|:---:|
| Claude Code | `~/.claude/skills/` | `.claude/skills/` | 格式兼容 |
| Codex | `~/.codex/skills/` | `.codex/skills/` | 格式兼容 |
| WorkBuddy | `~/.workbuddy/skills/` | `.codebuddy/skills/` | 格式兼容 |

**WorkBuddy 的用户级与项目级目录名不对称**（`~/.workbuddy/` 对 `.codebuddy/`）：项目级沿用
其底层 CodeBuddy 内核的目录名。写成 `.workbuddy/skills/` 的表现是技能一个都不出现。

**几家的目录互不读取**：Codex 与 WorkBuddy 都不读 `.claude/skills/`，Claude Code 也不读
`.codex/skills/`。几家都用就各装一份。

**用别的宿主**：同一段提示词，把目标路径换成该宿主的 skills 目录。本工具集的 Skill 遵循
Agent Skills 通用格式（`SKILL.md` + `scripts/` + `references/`，NFR-08），不绑定单一宿主。

## 3. 支持级别的定义（FT-11）

- **逐项走查**：§4 的每一项都在该平台上单独构造、单独观测、单独记录，全部通过。
- **使用验证**：在该平台上反复实际使用并跑通，覆盖"正常路径必然经过"的验证项；
  未对每一项单独构造场景——**权限确认、网络拦截、错误处理这类只在异常分支出现的项，
  日常使用永远走不到**。
- **格式兼容**：Skill 目录结构符合该平台的 Agent Skills 约定、路径取自该平台公开约定，
  但**从未在该平台上实际运行过**。

前两档填 `platforms.verified` 并须在 `tests/cross_platform/records/` 留记录（由
`test_verified_platforms_have_records` 守卫）；第三档填 `platforms.compatible`。
`verified` 与 `compatible` **不互斥**——前者回答"验没验过"，后者回答"能不能装"。

### 当前状态（0.3.0）

| 平台 | 级别 | 记录 |
|---|---|---|
| Claude Code | 使用验证（9 项中 6 项覆盖） | [claude-code-0.3.0.md](../../tests/cross_platform/records/claude-code-0.3.0.md) |
| Codex | 使用验证（9 项中 6 项覆盖） | [codex-0.3.0.md](../../tests/cross_platform/records/codex-0.3.0.md) |
| WorkBuddy | 格式兼容 | — |

**未确认的 3 项在两个平台上是同一组**：第 6 项权限确认、第 7 项网络限制、第 9 项错误处理。
Codex 的第 6 项尤其值得补——§4 曾预判它的权限确认交互与 Claude Code 不同，而该差异恰好
落在未确认项里。

> **面向用户的文档必须把这两档分开写**，不得笼统写成"已支持/已验证"。README 的支持级别
> 表格由 `test_readme_does_not_overclaim_verification` 守卫：一旦 `verified` 非空，README
> 里就不许再出现"三家均为…"这类整体性表述。

## 4. 每平台验证项（FT-11，逐项实测后才算正式验证）

| # | 验证项 | 通过判据 |
|---|---|---|
| 1 | Skill 发现 | 装完新开会话，宿主能列出 `fcs-reconcile` |
| 2 | 手动调用 | 显式点名该 Skill 能进入其流程 |
| 3 | 自动触发 | 用"帮我核对银行流水和台账"这类自然语言能命中，且不误触发到相邻任务 |
| 4 | 文件访问 | 能读用户指定的 xlsx/csv，且只读这些路径 |
| 5 | Python 执行 | 能用装了依赖的解释器跑通 `scripts/reconcile.py` |
| 6 | 权限确认 | 运行前展示数据处理声明并等待用户确认 |
| 7 | 网络限制 | `guard.block_network()` 生效，运行期外连被拒 |
| 8 | 输出文件 | 结果工作簿与 `*.manifest.json` 落到指定位置 |
| 9 | 错误处理 | 配置非法/文件缺失时给可读中文错误，不泄露单元格内容 |

## 5. 运行时依赖：安装期联网，运行期禁网

`fcs-reconcile` 需要 `pandas`、`openpyxl`、`pyyaml`（清单见
`skills/fcs-reconcile/requirements.txt`，由 `uv.lock` 导出）。这与 FT-05「本地隔离执行：
不安装运行时依赖」**不冲突**，两者是不同阶段：

- **安装期**（一次性，需要网络）：克隆仓库、复制目录、`pip install -r requirements.txt`。
- **运行期**（每次对账，禁网）：`scripts/reconcile.py` 一进来就 `guard.block_network()`，
  不装任何东西、不联任何网。

装依赖的解释器必须**与后续运行 Skill 的解释器是同一个**。用虚拟环境时，得让宿主用该
环境的 python 跑脚本，否则表现为 `ModuleNotFoundError: pandas`。

## 6. 装错位置的表现

**技能一个都不出现，且没有任何报错。** 宿主不会因为"某个目录里没有 skill"而报错，
所以路径写错的唯一症状是安静地什么都没有。排查顺序：

1. 目标目录对不对（§2 路径表，注意 WorkBuddy 的不对称）；
2. 复制的是 `skills/` 的**子目录本身**，而不是把整个 `skills/` 目录套进去——多套一层，
   宿主会按目录层级命名，技能名变成 `skills:fcs-reconcile`；
3. 每个 Skill 目录是否整体复制（缺 `scripts/` 时能被发现但跑不了）；
4. 是否**新开了会话**——已开的会话不重新扫描 skills 目录。
