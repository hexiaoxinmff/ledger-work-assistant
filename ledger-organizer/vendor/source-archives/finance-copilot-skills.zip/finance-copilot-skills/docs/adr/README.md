# docs/adr —— 架构决策记录（ADR）

记录重要架构决策及其背景、选项与理由，一决策一文件：`NNNN-<slug>.md`。

- 项目结构相关决策（D1–D4）见
  [../specs/2026-07-23-project-structure-design.md](../specs/2026-07-23-project-structure-design.md) §二。
- `fcs-reconcile` 的关键技术决策见
  [../design/fcs-reconcile-technical-design-v0.1.md](../design/fcs-reconcile-technical-design-v0.1.md) §11。

后续可将上述决策拆为独立 ADR 文件，并在此索引。
