# docs/security —— 安全文档

存放工具集与各 Skill 的安全设计文档：

- 威胁模型（威胁范围见 PRD §7.2）
- 数据流与隐私设计（控制平面 / 数据平面边界，PRD §5.1）
- Skill 安全基线（禁网、日志脱敏、源文件完整性、供应链）

对外的漏洞报告与响应策略见仓库根 [SECURITY.md](../../SECURITY.md)。
安全基线的自动校验见 [tools/verify](../../tools/verify/)。
