# 工具集变更记录

本文件记录**工具集级**发布。各 Skill 自身的版本记录见其目录下的 `CHANGELOG.md`。
遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 与语义化版本。

> 版本层级（工具集 / Skill / 规则 / 契约）、bump 时机与发布流程见
> [docs/governance/versioning.md](docs/governance/versioning.md)。

## [0.3.0] — 2026-08-11

**P0 欠账清零，`fcs-reconcile` 从 `Experimental` 转 `Preview`。不动任何对账逻辑**——
`rule_version=1.0`、`contract_version=1.0` 均不变，相同输入 + 相同配置的对账结果与
0.2.x 完全一致（NFR-05）。

本版解掉的最实质问题是[分阶段开发计划](docs/specs/2026-08-04-staged-development-plan.md)
§一指出的那条：**项目此前不满足自己定的发布门禁**——`tools/release/README.md` 写明发布
前置为「测试 100% + 安全基线通过 + 前向测试通过」，而后两项一项都没有，四个版本却已发出。
现在安全基线是真跑的，前向测试的状态是如实标注的。

### 新增

- **`tools/verify` 安全基线 6 项校验**（PRD §9），并在 CI 的 `security-baseline` job 中
  真实执行，替换此前的 `echo` 占位。定位是**黑盒工具集级**——对任意 `skills/<skill>/` 跑，
  只看外部可观测证据（出站连接、日志内容、源文件哈希、产物清单），新增 Skill 无需改代码
  即可纳入。计划里是 5 项，实现时加了「执行成功」作为前置（校验器跑在一个根本没跑起来的
  流程上，其余 5 项会全部"通过"）。每项都构造过负路径确认能真的挡住。
- **触发边界守卫**（FT-03）：`tests/triggering/corpus.yaml` + `test_trigger_boundary.py`。
  ⚠ 它**测不了**"用户说这句话时宿主是否真的唤起了该 Skill"——那是宿主行为，pytest 观测
  不到。守的是可机器化的部分：`description` 是否覆盖声称支持的场景、是否排除了相邻领域、
  每条"不该我做"是否指向真实去处。
- **逐单元格黄金答案**（NFR-05）：结果工作簿 7 张表与运行清单的完整快照。此前测试只断言
  8 个 summary 计数——reporter 改错列序、改掉判断依据文案、少写一张表，全都不会红。
- **`requirements.txt` 带依赖哈希**，配合 `pip install --require-hashes` 可拒绝被篡改的
  分发包；漂移守卫断言"重新导出后与文件一致"（只锁版本号防不了同版本号内容被换掉）。
- **`tools/new-skill/create.py` 脚手架**：新增一个 Skill 从「碰 10 个位置 + 满足 27 条
  守卫」变为「一条命令 + 填 description 与语料 + 写实现」。**未放松任何标准**——放松的是
  操作繁琐度，安全基线、确定性误判 0、黄金答案、触发边界守卫一条都没动。
- **平台验证记录** `tests/cross_platform/records/`，含验证等级定义与逐项状态。

### 变更

- **`fcs-reconcile` 发布状态 `Experimental` → `Preview`**。不是 `Stable`：PRD §10.2 定义
  Stable = 契约稳定 + 完成正式测试，而"契约稳定"需真实用户跑过至少一个业务周期证明，
  那是后续阶段的前置。**这里不抢跑一级。**
- **`platforms.verified` 填入 `claude-code`、`codex`**，依据是开发者在多个真实项目中反复
  安装并跑通。**验证等级是「使用验证」而非「逐项走查」**，两者的差别见下方已知限制。
- **`tests.forward` 由 `pending` 改为 `self-tested`**，不是 `passing`——PRD §10.1 定义前向
  测试为"不预知答案的独立执行者"，开发者自测在定义上不满足。用一个诚实的取值，而不是
  把没做的事记成做了。
- **FT-12 提交清单按发布状态分级**（[CONTRIBUTING.md](CONTRIBUTING.md)）：Experimental 阶段
  不要求 PRD、契约、技术设计、ADR、前向测试。此前十项被当成了开工门槛。
- **「是否对外可安装」的判据改为 `platforms.compatible` 是否非空**，不再由发布状态判定——
  `fcs-reconcile` 长期是 Experimental 却已对外安装，PRD §10.2 的 Experimental 只意味着
  "不承诺稳定"，与可否安装正交。
- **`test_verified_platforms_stay_empty_until_matrix_verified` 改写为
  `test_verified_platforms_have_records`**：意图不变（不许无据自称已验证），从"一律禁止"
  升级为"凭证据放行"。新增 `test_verification_records_declare_their_level` 要求每份记录
  自陈验证等级——空着的记录会被默认读成"9 项都过了"，那是最坏的一种默认。
- [SECURITY.md](SECURITY.md) 改为如实的降级报告流程（见已知限制）。

### 发现的事实

- **xlsx 输出字节不可重复**。跨进程隔数秒的两次运行，输出文件 SHA-256 会分叉（zip 条目
  时间戳 + `docProps/core.xml` 创建时间）。含义：NFR-05 的"相同输入产生相同结果"在**内容
  级**成立、**字节级**不成立，运行清单里的 `outputs[].sha256` 只能用于事后防篡改（FT-06），
  不能用来判断两次运行结果是否相同。已钉成显式测试。
- **跨场景复用时引擎不报错，而是静默给出错误答案**。用现有配置项跑"发票↔资金"场景，会把
  "开票方 ≠ 收款方"判为「已匹配·无需处理」——那正是三流合一要查的最典型风险。详见
  [发票↔资金预设计划](docs/specs/2026-08-04-fcs-reconcile-invoice-cash-preset-plan.md) §二。
  这是给 NFR-07（公共组件可复用性）的一条实测结论。

### 发布信息

- **Skill 版本**：`fcs-reconcile` 0.3.0（与工具集版本对齐，第 2 个 Skill 落地后解耦）。
- **规则/契约版本**：`rule_version=1.0`、`contract_version=1.0`，**均不变**。相同输入的
  对账结果与 0.2.2 / 0.2.1 / 0.2.0 / 0.1.0 完全一致。
- **依赖版本**：`pandas`、`openpyxl`、`pyyaml`，清单由 `uv.lock` 导出并带 sha256 哈希。
- **支持平台**：`claude-code`、`codex` 已验证（**使用验证**级，见下）；`workbuddy` 仍为
  格式兼容。三家均提供整段可复制的安装提示词。
- **安全测试状态**：`ruff` / `mypy strict` / `pytest`（107 passed + 1 skipped）全绿；
  `tools/verify --all` 6/6 通过。
- **回滚版本**：`0.2.2`。⚠ 回滚会把 `platforms.verified` 退回空、`status` 退回
  `Experimental`、`tests.forward` 退回 `pending`。

### 已知限制

1. **平台验证是「使用验证」，不是「逐项走查」。** `agent-install.md` §4 的 9 项中，6 项由
   实际使用覆盖（发现、手动调用、自动触发、文件访问、Python 执行、输出文件），**3 项未在
   宿主内确认**：权限确认（含拒绝后是否正确中止）、运行期网络拦截、错误处理文案。这三项
   的共同点是**只在异常分支出现**，日常对账走不到。逐项状态与待补测清单见
   [tests/cross_platform/records/](tests/cross_platform/records/)。Codex 的权限确认交互
   与 Claude Code 存在预判差异，而该差异恰好落在未确认项上。
2. **独立前向测试（PRD §10.1）未执行。** `tests.forward: self-tested` 表示开发者自测，
   不表示陌生用户能独立用对。这是有意的发布决定，不是遗漏——把它从卡点降级为已知限制。
3. **SBOM、发布包 SHA-256 与发布签名未落地**（阶段 B）。
4. **依赖漏洞扫描只报告不阻断。** 漏洞库需联网拉取，会让 CI 结果随外部数据源波动（代码
   一行没改，今天绿明天红），门禁一旦不可信就会被习惯性忽略。阶段 B 随 SBOM 一起定阻断策略。
5. **GitHub Private Vulnerability Reporting 未开启**（需 admin 权限）。[SECURITY.md](SECURITY.md)
   已改为如实的降级流程——先开 issue 只说"发现安全问题"、不写细节。降级方案仍会暴露
   "存在未修复漏洞"这一事实。
6. **结果工作簿有 3 处与输出契约的既有偏差未修**（不是本版引入）：① 隐私运行摘要只复现
   4 项，PRD §5.3 的运行前确认界面有 8 项；② 「运行参数」表缺输入路径、字段映射、文件哈希；
   ③ 输出契约正文的"11 个复核字段"实为 12 个（本版已改，属文档笔误）。①② 修复会改变结果
   工作簿内容，按 versioning §3 属"契约新增可选字段"，须 bump `contract_version` 到 1.1——
   为保住本版"对账结果与 0.2.x 完全一致"这一保证，留待后续版本。
7. **WorkBuddy 仍为格式兼容**，未实际使用过。

## [0.2.2] — 2026-08-04

**许可证定为 MIT，PRD §10.4 的待办 ①②④ 一并落定。** 不动任何代码行为。

### 变更

- **[LICENSE](LICENSE) 替换为 MIT License 全文**（`Copyright (c) 2026 cxtx`）。此前是
  「许可证待定」占位文件，明确要求"请勿假定任何默认授权"——**在此之前本仓库实际上不可
  合法使用**，这是本版解掉的最实质的限制。MIT 允许自由使用、修改、分发、商用与再授权，
  条件只有一条：保留版权与许可声明。
- **PRD §10.4 三项待办结案**：① 核心代码全部开源、② 采用 MIT、④ 允许企业内部二次开发
  与商用。**原编号保留不重排**——CONTRIBUTING 与项目结构设计文档都按编号引用 §10.4，
  重排会静默改变那些引用的指向。
- `pyproject.toml` 补 `license = "MIT"` 与 `license-files = ["LICENSE"]`（PEP 639）。
- `SKILL_META.yaml` 补 `license: MIT` 字段。

### 新增

- **`skills/fcs-reconcile/LICENSE`（副本）**。安装方式是把 `skills/` 的子目录复制到宿主的
  skills 目录，**根仓库的 LICENSE 不会跟着走**，而 MIT 要求所有副本或实质部分都包含版权
  与许可声明。不放这一份，分发路径上的许可证就是不完整的。三段安装提示词的文件清单也
  相应加上 `LICENSE`，避免用户复制时漏掉。

### 说明：MIT 不覆盖数据承诺

MIT 约束的是**代码**的使用方式，对数据不作任何约定。PRD §1.3「免费不以数据为代价」
（不收集、不出售、不用于训练用户财务数据）是独立于许可证的产品承诺，由工程设计兜底——
运行期禁网、原始明细不进模型、日志不含交易明细，都可逐条检查。**许可证宽松不等于数据
承诺放松**，两者不在同一层。

### 发布信息

- **支持平台**：三家仍为「格式兼容」，`platforms.verified` 仍为空（FT-11 未执行）。
- **质量门禁**：`ruff check .`、`mypy .`、`pytest`（92 项）全部通过。
- **规则/契约版本**：`rule_version=1.0`、`contract_version=1.0` 均不变，相同输入的对账
  结果与 0.2.1 / 0.2.0 / 0.1.0 完全一致（NFR-05）。
- **已知限制**：FT-11 逐平台验证未执行；发布包签名与 SBOM 未落地；`requirements.txt`
  尚未带依赖哈希；`tools/verify` 安全基线脚本仍为骨架，CI 中未启用；漏洞报告渠道待定
  （[SECURITY.md](SECURITY.md)）。**许可证待定一项已解除。**
- **回滚版本**：`0.2.1`。注意回滚会把许可证退回「待定」占位状态。

## [0.2.1] — 2026-08-04

**本版把 CI 门禁修成全绿，并补上 `v0.1.0` 的 git tag。不动任何对账行为。**
`rule_version` 与 `contract_version` 均不变，相同输入 + 相同配置的对账结果与
0.2.0 / 0.1.0 完全一致（NFR-05）。

### 修复

- **`mypy .` 从 188 个错误清零，且未放宽任何规则**——`strict = true` 一字未改。
  逐项补齐类型标注而非降低门槛：42 个 `test_*` 函数补 `-> None`；29 个 fixture 参数
  标注为 `tmp_path: Path` / `monkeypatch: pytest.MonkeyPatch`；19 个测试与物料辅助
  函数补齐完整签名（`_rows`、`row`、`_spec`、`_write`、`_make_config`、`styled_header`
  等）；6 处 `s["counts"]["…"]` 嵌套取值改用 `cast(dict[str, int], …)` 收窄
  （`build_summary` 返回 `dict[str, object]`，与 `reconcile.py` 既有惯例一致）。
- **`ruff check .` 从 48 个错误清零**。其中真修的：`gen_reconcile_result.py` 中段的
  `from collections import defaultdict` 移回文件顶部（E402）、3 处 import 排序、
  1 处无占位符 f-string。examples 两个生成脚本里 5 组循环变量改名
  （`row` → `note_row` / `dq_row` / `audit_row` / `param_row`，`c` → `conf`）——
  同名变量承载不同类型是 mypy 报 `[assignment]` / `[index]` 的根因，改名后语义也更清楚。
- **补打 `v0.1.0` git tag**，指向 `f440f8d`（2026-07-24，与根 CHANGELOG 记载的 0.1.0
  日期一致，且是 0.2.0 工作开始前的最后一个提交）。versioning.md §7 原写"不做追加补打，
  因为日期与提交都对不上"——实际两者都对得上，该顾虑不成立，故补打并回改该节。

### 变更

- `pyproject.toml` 的 `[tool.ruff.lint.per-file-ignores]` 新增
  `"**/examples/**" = ["E501"]`。这是本版**唯一**放宽的规则，且只放宽行宽一项：
  教程物料脚本内嵌按列手工对齐的中文演示数据（台账/流水逐列对齐，便于读者核对），
  折行会破坏该对齐；`**/tests/**` 早已按同样理由放宽 E501。**类型检查不放宽**——
  mypy strict 对 `examples/` 同样生效且已全绿。
- 版本号统一至 **0.2.1**：`pyproject.toml`、`SKILL_META.yaml`、`scripts/version.py`、
  `SKILL.md` 与两份 CHANGELOG 同值（由版本漂移守卫断言）。

### 发布信息

- **支持平台**：claude-code / codex / workbuddy 仍均为「格式兼容」，`platforms.verified`
  仍为空——本版未执行 FT-11 的 9 项验证项。
- **质量门禁**：`ruff check .`、`mypy .`、`pytest`（92 项）**全部通过**，
  首次满足 versioning.md §5 发布流程第 4 步。
- **依赖版本**：未变（`pandas 3.0.5`、`openpyxl 3.1.5`、`pyyaml 6.0.3`）。
- **已知限制**：FT-11 逐平台验证未执行；发布包签名与 SBOM 未落地；`requirements.txt`
  尚未带依赖哈希；许可证仍待定（[LICENSE](LICENSE) 为占位）；`tools/verify` 安全基线
  脚本仍为骨架，CI 中未启用。
- **回滚版本**：`0.2.0`。本版未改规则、契约与任何运行时行为，回滚不影响结果可重复性。

## [0.2.0] — 2026-08-04

**本版把"怎么装"这件事补上了，并把散落的版本号收成一处。**

### 新增

- **多代理安装，统一走提示词**：README 新增「安装」章节，给 Claude Code、Codex、
  WorkBuddy 各一段可直接整段复制粘贴的中文安装提示词（三段各自完整，不需要用户手改
  路径），外加项目级安装、换宿主、装错位置排查与"装完试一下"说明。
  不提供安装脚本——安装动作对使用者应当可读可审查，且不为分发新增可执行产物（§7.2）。
- **多代理安装矩阵**：[docs/governance/agent-install.md](docs/governance/agent-install.md)
  —— 三家代理的用户级/项目级路径表（**这是路径的唯一事实源**，README 由它派生）、
  支持级别定义、FT-11 的 9 项验证项清单、依赖与"安装期联网/运行期禁网"的界线、
  装错位置的排查顺序。
- **统一版本规划**：[docs/governance/versioning.md](docs/governance/versioning.md)
  —— 四层版本的事实源与 bump 时机表、单 Skill 阶段 `skill_version` 与工具集版本对齐
  （及第 2 个 Skill 落地时的解耦条件）、漂移守卫、发布流程与回滚点。
- **版本漂移守卫**：`tests/supply_chain/test_version_consistency.py` —— 断言
  `pyproject.toml`、各 `SKILL_META.yaml`、`scripts/version.py`、`SKILL.md` 与两份
  CHANGELOG 的版本号完全一致，随 CI 执行。
- **安装路径守卫**：`tests/cross_platform/test_install_paths.py` —— 断言 README 的安装
  提示词与安装矩阵路径表一致，且每家代理都有完整可复制的提示词块。
- **中英双语 README**：`README.md`（简体中文，默认）与 `README.en.md`（English）互相链接。
  按「总览 → 设计理念 → 会做的/不做的 → 能力表 → 快速开始 → 怎么开口问 → 你会拿到什么 →
  为什么可信」重组，读者设定为不懂编程的财务人员而非工程师。新增内容：结果工作簿 7 张表
  的逐表说明与关键列、8 种中文结果状态、会被拦下的问法及其替代出口、一次对账从导出到交
  审计的端到端 10 步（标注每步归人还是归程序）、演示数据 7 类差异的预期表。
  三段安装提示词原样保留——安装路径守卫会把 README 里所有 ` ```text ` 块当作安装提示词
  校验，故其余示意块改用 ` ```plaintext `。

### 变更

- 版本号统一至 **0.2.0**：`pyproject.toml`、`skills/fcs-reconcile/SKILL_META.yaml`
  （`skill_version`）、`SKILL.md` 与两份 CHANGELOG 同值。
  `rule_version=1.0`、`contract_version=1.0` **不变**——本版未触碰匹配规则与输入输出契约，
  因此相同输入的对账结果与 0.1.0 完全一致（NFR-05）。
- `fcs-reconcile` 的 `platforms.compatible` 填入 `claude-code, codex, workbuddy`；
  `platforms.verified` **仍为空**——已提供安装路径不等于已验证，FT-11 的 9 项验证项尚未执行。
- `agents/` 平台配置补齐为三家（新增 `workbuddy.md`），统一记录安装位置与权限约定。
- PRD §8.3 版本路线图：v0.2 主题由「第二个财务 Skill」改为「多代理安装与版本统一」，
  第二个 Skill 顺延至 v0.3（依 versioning.md §6，路线图是计划、CHANGELOG 是事实）。
- 追认 `[0.1.0]`：此前根 CHANGELOG 停留在 `[未发布]`，现补为正式条目与日期。

### 修复

- `scripts/reconcile.py` 不再硬编码 `skill_version="0.1.0"`，改从新增的
  `scripts/version.py` 取。原写法与 `SKILL_META.yaml` 各存一份版本号，改版本时漏改一处
  就会让运行清单（FT-08）里的版本号与实际发布版本不符，直接损害 NFR-04 可审计性。

### 发布信息

- **支持平台**：claude-code / codex / workbuddy 均为「格式兼容」，无「正式验证」平台。
- **依赖版本**：`pandas 3.0.5`、`openpyxl 3.1.5`、`pyyaml 6.0.3`（锁定真源 `uv.lock`）。
- **安全测试状态**：`tests/security/` 通过（网络隔离、日志脱敏、源文件完整性、
  输出不覆盖输入）；`tools/verify` 安全基线脚本仍为骨架，CI 中未启用。
- **已知限制**：FT-11 逐平台验证未执行；发布包签名与 SBOM 未落地；
  `requirements.txt` 尚未带依赖哈希；许可证仍待定（[LICENSE](LICENSE) 为占位）。
  **CI 的 `ruff check` 与 `mypy` 两步未通过**：48 个 ruff 错误（43 个 E501 集中在
  `skills/fcs-reconcile/examples/` 的两个生成脚本，`pyproject.toml` 的 per-file-ignores
  只对 `**/tests/**` 放宽了 E501）与 188 个 mypy 错误（176 个 `no-untyped-def` /
  `no-untyped-call`，来自 `tests/` 与 `examples/` 未标注类型的函数，mypy `strict = true`）。
  `pytest` 92 项全部通过，确定性引擎、勾稽与安全控制均不受影响；是否为这两个目录放宽
  门禁属治理决策（"严谨性一票否决"下不宜顺手降标准），留待单独一轮处理。
- **回滚版本**：`0.1.0`。本版未改规则与契约，回滚不影响既有结果的可重复性。

## [0.1.0] — 2026-07-24

首个版本（工程完成于此日，当时未打 git tag，于 0.2.0 发布时追认）。

### 新增

- 建立仓库骨架：`skills/ packages/ tools/ tests/ docs/ .github/`。
- 项目结构设计文档：`docs/specs/2026-07-23-project-structure-design.md`。
- `fcs-reconcile` 对账参考实现：确定性引擎（config / io_reader / normalizer /
  matcher / classifier / summary / manifest / reporter / reconcile 编排与 CLI）、
  本地隔离与禁网、运行清单、7 表中文结果工作簿、演示数据与示例结果；
  单元 / 属性 / 黄金 / 安全测试通过。详见
  [skills/fcs-reconcile/CHANGELOG.md](skills/fcs-reconcile/CHANGELOG.md)。

### 发布信息

- **支持平台**：无（`platforms` 两项均为空）。
- **已知限制**：无安装说明；FT-11 平台验证未执行；许可证待定。
- **回滚版本**：无（首个版本）。
