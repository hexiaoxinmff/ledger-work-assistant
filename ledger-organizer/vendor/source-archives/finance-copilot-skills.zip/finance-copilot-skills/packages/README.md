# packages/ —— 共享库唯一源

**当前为空（仅本 README）。这是有意为之的"生长点"，不是遗漏。**

## 约定

- 本目录是工具集**共享代码的唯一源**（如未来的 `packages/fcs-core/`）。
- **抽象准则（PRD）**：公共能力**经至少 2 个 Skill 验证后**才抽象落此，禁止提前抽象或复制粘贴。
- 开发期各 Skill 通过 uv workspace 以可编辑方式引用共享库（`import fcs_core...`）。
- **发布期**由 [`tools/build`](../tools/build/) 把被引用的共享代码 **vendor 进每个 Skill 的
  `scripts/`**，使发布包完全自包含（"装一个 Skill 不强制装全套"，PRD §1.1 / FT-02）。

## 何时在此新增共享库

- 同一能力已在 ≥2 个 Skill 中出现且被验证；且
- 该能力有稳定契约、可独立测试；且
- 抽象后不会迫使已有 Skill 修改（NFR-07）。
