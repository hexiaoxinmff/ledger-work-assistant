# 贡献指南

> ⚠ 部分流程责任人待定（PRD §10.4 待办 ⑨⑩：是否接受社区贡献 Skill、由谁做财务/安全/代码审核）。

## 基本约定

- **小而专**：一个 PR 聚焦一个 Skill 或一处明确改动，不混合无关变更。
- **严谨性一票否决**：任何改动不得放松确定性校验、安全隔离或可核验性（PRD §1.2）。
- **确定性代码归 `scripts/`（数据平面），AI 可见内容归 `SKILL.md` / `references/`（控制平面）**，两者不得混淆。

## 新增 Skill 的提交清单（对应 FT-12）

**按发布状态分级，不是一次交齐十项。** FT-12 列的是一个 Skill **走到 Stable 为止**
累计要有的东西；把它当成开工门槛，会让"试一个想法"的成本高到没人愿意试，而 PRD §8.2
恰恰要求后续 Skill 必须先经真实需求验证——验证需要先做出可试的东西。

先跑脚手架，它把下面所有带 🔧 的项一次生成好：

```bash
uv run python tools/new-skill/create.py fcs-clean \
  --display 清洗 --description "清洗 Excel/CSV 财务明细，统一编号、金额与日期格式。"
```

### 阶段一 · Experimental（内部实验，不对外安装）

目标是**做出可试的东西**，此时 `platforms.compatible` 留空，不进 README。

- [ ] 🔧 目录骨架、`SKILL_META.yaml`、`CHANGELOG.md`、`version.py`、带哈希的 `requirements.txt`
- [ ] 🔧 `tests/triggering/corpus.yaml` 中本 Skill 一节 —— 把占位换成真实语料
- [ ] `SKILL.md` 的 `description` 写实 —— **宿主路由的唯一依据**，也是触发边界守卫唯一认的地方
- [ ] `scripts/` 实现 + 单元测试
- [ ] 在 `tools/verify/cases.py` 注册基线用例，`--all` 通过

**此阶段不要求**：PRD、输入输出契约、技术设计、ADR、前向测试、README 点名。

### 阶段二 · Preview（对外可安装，接口可能变）

- [ ] 输入输出契约（`docs/contracts/<skill>/`，版本化）
- [ ] 技术设计（`docs/design/`）—— 小 Skill 可与 PRD 合并为一份，不必拆两份文档
- [ ] 脱敏测试数据 + 黄金答案（`tests/golden/`，含逐单元格快照）
- [ ] 独立前向测试通过（测试者不预知答案，PRD §10.1）
- [ ] `SKILL_META.platforms.compatible` 填三家 **+ 两份 README 的三段提示词点名本 Skill**
      —— 这两处由 `tests/cross_platform/` 守卫，必须同增同减
- [ ] 发布状态与回滚说明（`SKILL_META.yaml` + `CHANGELOG.md`）

### 阶段三 · Stable（契约稳定）

- [ ] 需求调研升级为**真实用户验证**（Experimental 阶段可以只是线索存档，
      样例见 [fcs-invoice-check 调研](docs/specs/2026-08-04-fcs-invoice-check-demand-research.md)）
- [ ] 关键决策 ADR（`docs/adr/`）—— 只在"选了 A 没选 B 且理由重要"时写，不是每个 Skill 都要
- [ ] FT-11 逐平台验证记录（`tests/cross_platform/records/`）
- [ ] 真实用户跑过至少一个完整业务周期

### 任何阶段都不豁免

安全与确定性底线不随状态分级（PRD §1.2 严谨性一票否决）：

- [ ] `tools/verify --all` 6 项全过
- [ ] 确定性误判 0：候选唯一且规则完全满足才自动确认
- [ ] 金额一律 `Decimal`；运行期禁网、不改源文件、不打印交易明细
- [ ] **安全边界说明**（`docs/security/`）—— 仅当涉及 PRD §8.2 点名需单独评审的类型
      （PDF、OCR、税务、凭证、生产系统连接）时必须单独成文，其余并入技术设计即可

### 第 2 个 Skill 的一次性动作

- [ ] **按 [版本规划](docs/governance/versioning.md) §3.2 解耦 `skill_version`**，
      同时删除 `tests/supply_chain/test_version_consistency.py::test_single_skill_stage_versions_are_aligned`
      —— 脚手架会检测并提示，但不代劳：解耦是人的决定

## 版本与安装

改版本号前先读 [docs/governance/versioning.md](docs/governance/versioning.md)：它规定了四层版本
（工具集 / Skill / 规则 / 契约）各自的事实源与 bump 时机。两条最容易踩的：

- **`rule_version` 与 `contract_version` 一经发布只增不改。** 已落盘的运行清单引用的是旧版本号，
  改写它等于篡改审计证据。
- **运行期版本号只从 `skills/<skill>/scripts/version.py` 取**，不在业务代码里散写字面量。

安装方式统一走提示词，不加安装脚本（理由见
[docs/governance/agent-install.md](docs/governance/agent-install.md) §1）。改动安装路径要同时改
矩阵 §2 路径表与 README 三段提示词。

**两个漂移守卫会在 CI 里挡住不一致**：`tests/supply_chain/test_version_consistency.py`
（版本号跨文件一致）与 `tests/cross_platform/test_install_paths.py`（README 与路径表一致、
提示词覆盖每个 Skill）。它们防的问题在使用侧几乎不可发现——版本号漂移只体现在审计证据里，
安装路径写错则是"技能一个都不出现且无报错"。

## 三审（职责待明确）

| 维度 | 关注点 |
|---|---|
| 财务审核 | 业务规则正确、术语准确、勾稽逻辑成立 |
| 安全审核 | 网络隔离、日志脱敏、源文件完整性、依赖供应链 |
| 代码审核 | 确定性、可测试性、契约稳定、可维护 |

## 立项条件（PRD §10.2）

有真实用户、有重复出现的任务、可验证输入输出、确定性部分可程序化、
安全边界明确、与现有 Skill 边界清楚、至少一组脱敏测试数据与黄金答案。
