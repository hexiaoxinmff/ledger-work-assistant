# assets/

存放结果工作簿模板与样式等静态资源（可选）。例如：
- `workbook-template.xlsx`：7 张中文工作表的样式/表头模板。

骨架阶段暂空。若最终由 `reporter.py` 以代码生成样式，可不引入模板文件。
