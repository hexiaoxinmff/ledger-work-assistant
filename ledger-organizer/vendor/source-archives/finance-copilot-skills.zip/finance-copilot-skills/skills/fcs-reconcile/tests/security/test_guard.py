import socket

import guard
import pytest


def test_block_network_forbids_outbound(monkeypatch: pytest.MonkeyPatch) -> None:
    # 快照原始方法，交由 monkeypatch 在用例结束后恢复，避免 class 级 patch
    # 泄漏到同一 pytest 进程内的其他测试（testpaths 覆盖整个 skills/ 与 tests/）。
    monkeypatch.setattr(socket.socket, "connect", socket.socket.connect, raising=False)
    monkeypatch.setattr(socket.socket, "connect_ex", socket.socket.connect_ex, raising=False)
    guard.block_network()
    with socket.socket() as s, pytest.raises(guard.NetworkDisabledError):
        s.connect(("127.0.0.1", 9))


def test_get_logger_returns_logger() -> None:
    log = guard.get_logger("fcs")
    assert log.name == "fcs"
