from decimal import Decimal
from pathlib import Path

import reporter
from models import ResultItem, Status
from openpyxl import load_workbook


def _item(status: Status, sheet: str, priority: str) -> ResultItem:
    return ResultItem(status=status, priority=priority, sheet=sheet, no="A1",
                      amount_left=Decimal("10.00"), amount_right=Decimal("10.00"),
                      amount_diff=Decimal("0.00"), basis="x", suggested_action="y",
                      left_source_row=2, right_source_row=2)


def test_workbook_has_seven_named_sheets(tmp_path: Path) -> None:
    items = [_item(Status.AUTO_MATCHED, "已匹配", "—")]
    s = {"counts": {"已自动匹配": 1}, "match_rate": "1.0000",
         "quantity_reconciled": True, "amount_reconciled": True,
         "left_amount_total": "10.00", "right_amount_total": "10.00", "sum_amount_diff": "0.00"}
    p = tmp_path / "out.xlsx"
    reporter.write_workbook(items, s, {"rule_version": "1.0"}, str(p))
    wb = load_workbook(str(p))
    assert wb.sheetnames == ["对账总览", "待处理事项", "已匹配", "重复与冲突",
                             "数据质量", "审计明细", "运行参数"]
    assert wb["对账总览"]["A1"].value is not None
