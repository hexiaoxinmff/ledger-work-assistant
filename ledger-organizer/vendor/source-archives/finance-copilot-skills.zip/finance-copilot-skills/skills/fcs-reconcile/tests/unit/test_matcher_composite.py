from datetime import date
from decimal import Decimal

import config
import matcher
from models import Status, StdRow


def row(rid: int, amt: str, d: date | None, cp: str | None) -> StdRow:
    return StdRow(row_id=rid, source_row=rid + 2, no=f"N{rid}", amount=Decimal(amt),
                  date=d, counterparty=cp, direction_raw=None)


def test_composite_unique_auto_match() -> None:
    m = config.MatchConfig(composite_keys=("amount", "date", "counterparty"))
    left = [row(0, "10.00", date(2026, 1, 1), "X")]
    right = [row(9, "10.00", date(2026, 1, 1), "X")]
    out = matcher.match(left, right, m)
    assert [o.status for o in out] == [Status.AUTO_MATCHED]
    assert out[0].rule == "复合键唯一一致"


def test_composite_ambiguous_stays_single_sided() -> None:
    m = config.MatchConfig(composite_keys=("amount", "date", "counterparty"))
    left = [row(0, "10.00", date(2026, 1, 1), "X")]
    right = [row(8, "10.00", date(2026, 1, 1), "X"), row(9, "10.00", date(2026, 1, 1), "X")]
    out = matcher.match(left, right, m)
    # 左行有 2 个候选 → 不自动确认；全部落单边
    assert Status.AUTO_MATCHED not in {o.status for o in out}
    assert {o.status for o in out} == {Status.LEFT_ONLY, Status.RIGHT_ONLY}


def test_composite_disabled_when_no_keys() -> None:
    out = matcher.match([row(0, "10.00", date(2026, 1, 1), "X")],
                        [row(9, "10.00", date(2026, 1, 1), "X")], config.MatchConfig())
    assert {o.status for o in out} == {Status.LEFT_ONLY, Status.RIGHT_ONLY}


def test_composite_none_field_not_auto_matched() -> None:
    # 复合键含可空字段，两侧都缺失(None)时不得判为一致 → 不自动确认（误判 0）
    m = config.MatchConfig(composite_keys=("amount", "counterparty"))
    left = [row(0, "10.00", None, None)]    # counterparty=None
    right = [row(9, "10.00", None, None)]
    out = matcher.match(left, right, m)
    assert Status.AUTO_MATCHED not in {o.status for o in out}
    assert {o.status for o in out} == {Status.LEFT_ONLY, Status.RIGHT_ONLY}
