from datetime import date
from decimal import Decimal

import models


def test_status_values_are_chinese() -> None:
    assert models.Status.AUTO_MATCHED.value == "已自动匹配"
    assert models.Status.SUSPECT.value == "疑似匹配"
    assert models.Status.AMOUNT_DIFF.value == "金额差异"
    assert models.Status.LEFT_ONLY.value == "左侧单边"
    assert models.Status.RIGHT_ONLY.value == "右侧单边"
    assert models.Status.DUP_NO.value == "重复编号"
    assert models.Status.MULTI_CANDIDATE.value == "多候选冲突"
    assert models.Status.DATA_QUALITY.value == "数据质量问题"
    # StrEnum：str() 也应返回中文值，不泄漏英文枚举名
    assert str(models.Status.AUTO_MATCHED) == "已自动匹配"


def test_stdrow_is_frozen_and_hashable() -> None:
    r = models.StdRow(row_id=0, source_row=2, no="A1", amount=Decimal("1.00"),
                      date=date(2026, 1, 1), counterparty="X", direction_raw="收")
    assert r.quality_flags == ()
    assert hash(r)  # frozen dataclass 可哈希


def test_priority_and_sheet_cover_all_statuses() -> None:
    for s in models.Status:
        assert s in models.PRIORITY
        assert s in models.SHEET
