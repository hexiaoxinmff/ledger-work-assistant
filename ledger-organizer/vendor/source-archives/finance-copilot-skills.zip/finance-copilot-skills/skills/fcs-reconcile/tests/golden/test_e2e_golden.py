import json
import socket
from pathlib import Path
from typing import Any, cast

import config as cfg_mod
import pytest
import reconcile
import regen_snapshots

HERE = Path(__file__).parent
INPUTS = HERE / "inputs"


def _make_config(tmp_path: Path) -> tuple[cfg_mod.ReconcileConfig, Path]:
    """配置构造复用 regen_snapshots.make_config，与快照生成端共用一份。

    两处各写一份 YAML，快照就可能是在与测试不同的配置下生成的——那种"通过"没有意义。
    """
    out = tmp_path / "result.xlsx"
    return regen_snapshots.make_config(out), out


def test_golden_counts_and_reconciliation(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    # reconcile.run 会永久性 monkeypatch socket.socket 的 connect/connect_ex（guard.block_network）；
    # 这里先快照原始方法交给 monkeypatch 夹具在用例结束后恢复，避免泄漏到同一 pytest 进程内的其他测试
    # （pyproject.toml 的 testpaths 覆盖整个 skills/ 与 tests/，所有测试同进程运行）。
    monkeypatch.setattr(socket.socket, "connect", socket.socket.connect, raising=False)
    monkeypatch.setattr(socket.socket, "connect_ex", socket.socket.connect_ex, raising=False)
    conf, out = _make_config(tmp_path)
    s = reconcile.run(conf, run_id="test", run_at="2026-07-23T00:00:00")
    counts = cast(dict[str, int], s["counts"])
    assert counts["已自动匹配"] == 2
    assert counts["金额差异"] == 1
    assert counts["左侧单边"] == 1
    assert counts["右侧单边"] == 1
    assert s["quantity_reconciled"] is True
    assert s["amount_reconciled"] is True
    assert out.exists()


def test_determinism_same_summary_twice(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(socket.socket, "connect", socket.socket.connect, raising=False)
    monkeypatch.setattr(socket.socket, "connect_ex", socket.socket.connect_ex, raising=False)
    conf, _ = _make_config(tmp_path)
    s1 = reconcile.run(conf, run_id="r1", run_at="t1")
    conf2, _ = _make_config(tmp_path)
    s2 = reconcile.run(conf2, run_id="r2", run_at="t2")
    assert json.dumps(s1, ensure_ascii=False, sort_keys=True) == \
           json.dumps(s2, ensure_ascii=False, sort_keys=True)   # run_id/时间不影响结果


def test_workbook_matches_snapshot(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """逐单元格比对 7 张工作表（NFR-05「逐单元格一致」）。

    上面的计数断言只看 8 个 summary 数字：reporter 改错列顺序、改掉「判断依据」文案、
    少写一张表，它们全都不会红。这一条是那个缺口的补丁。

    比对的是**单元格内容**而非文件字节——xlsx 的 zip 条目时间戳与 docProps 创建时间
    每次运行都不同，字节级比对必然失败（实测：隔 3 秒的两个进程哈希就分叉）。
    """
    monkeypatch.setattr(socket.socket, "connect", socket.socket.connect, raising=False)
    monkeypatch.setattr(socket.socket, "connect_ex", socket.socket.connect_ex, raising=False)
    workbook_path, _ = regen_snapshots.run_golden(tmp_path / "result.xlsx")

    actual = regen_snapshots.dump_workbook(workbook_path)
    expected = json.loads(regen_snapshots.WORKBOOK_SNAPSHOT.read_text(encoding="utf-8"))
    assert actual == expected, (
        "结果工作簿与黄金答案快照不一致。确认差异是有意变更后，用\n"
        "  uv run python skills/fcs-reconcile/tests/golden/regen_snapshots.py\n"
        "重生成——但**因为这条测试红了就重生成 = 把回归钉死为期望值**。"
    )


def test_manifest_matches_snapshot(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """比对运行清单的稳定字段（FT-08）。

    剔除 run_id / run_at / skill_version 与各路径、输出哈希，理由逐条见
    regen_snapshots.MANIFEST_VOLATILE。保留 inputs[].sha256——它顺带守住了
    "测试输入文件没被意外改动"，那是所有黄金答案的前提。
    """
    monkeypatch.setattr(socket.socket, "connect", socket.socket.connect, raising=False)
    monkeypatch.setattr(socket.socket, "connect_ex", socket.socket.connect_ex, raising=False)
    _, manifest_path = regen_snapshots.run_golden(tmp_path / "result.xlsx")

    actual = regen_snapshots.dump_manifest(manifest_path)
    expected = json.loads(regen_snapshots.MANIFEST_SNAPSHOT.read_text(encoding="utf-8"))
    assert actual == expected, "运行清单与黄金答案快照不一致（见上一条的重生成说明）"


def test_workbook_bytes_are_not_reproducible_across_runs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """把「xlsx 字节不可重复」钉成显式事实，而不是留给别人踩。

    NFR-05 的「相同输入产生相同结果」在**内容级**成立（上面两条快照），在**字节级**
    不成立：xlsx 是 zip，条目时间戳与 docProps/core.xml 的创建时间每次都变。

    因此运行清单里 `outputs[].sha256` 的用途只能是「事后验证这份文件没被篡改」
    （FT-06），不能用来判断两次运行结果是否相同。这条测试的存在是为了：将来若有人
    让输出变得字节可重复，它会红，迫使同时更新这条说明与依赖该前提的文档。
    """
    monkeypatch.setattr(socket.socket, "connect", socket.socket.connect, raising=False)
    monkeypatch.setattr(socket.socket, "connect_ex", socket.socket.connect_ex, raising=False)
    first, _ = regen_snapshots.run_golden(tmp_path / "a.xlsx")
    second, _ = regen_snapshots.run_golden(tmp_path / "b.xlsx")

    # 内容一致
    assert regen_snapshots.dump_workbook(first) == regen_snapshots.dump_workbook(second)
    # 字节则不保证一致——不断言"必然不同"（同一秒内可能相同），只声明不可依赖
    if first.read_bytes() == second.read_bytes():
        pytest.skip("本次两轮恰好落在同一时间戳内，字节偶然相同；该属性本就不可依赖")


def test_manifest_records_errors_when_reconciliation_fails(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import json
    import socket

    import summary as summary_mod
    monkeypatch.setattr(socket.socket, "connect", socket.socket.connect, raising=False)
    monkeypatch.setattr(socket.socket, "connect_ex", socket.socket.connect_ex, raising=False)
    conf, out = _make_config(tmp_path)
    real = summary_mod.build_summary

    def _fail(*a: Any, **k: Any) -> dict[str, object]:
        d = dict(real(*a, **k))
        d["amount_reconciled"] = False
        return d

    monkeypatch.setattr(summary_mod, "build_summary", _fail)
    reconcile.run(conf, run_id="r", run_at="t")
    m = json.loads((tmp_path / (out.name + ".manifest.json")).read_text(encoding="utf-8"))
    assert m["errors"] == 1
