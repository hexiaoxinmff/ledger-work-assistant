import socket
from pathlib import Path

import config as cfg_mod
import guard
import integrity
import pytest
import reconcile

INPUTS = Path(__file__).parent.parent / "golden" / "inputs"


def test_source_files_unchanged_and_network_blocked(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    # reconcile.run 内部调用 guard.block_network() 会永久性 monkeypatch
    # socket.socket.connect/connect_ex；这里先快照原始方法交给 monkeypatch 夹具
    # 在用例结束后恢复，避免泄漏到同一 pytest 进程内的其他测试。
    monkeypatch.setattr(socket.socket, "connect", socket.socket.connect, raising=False)
    monkeypatch.setattr(socket.socket, "connect_ex", socket.socket.connect_ex, raising=False)

    before = {str(INPUTS / f): integrity.sha256_of(str(INPUTS / f))
              for f in ("left.csv", "right.csv")}
    out = tmp_path / "r.xlsx"
    yaml = f"""
left:  {{file: "{INPUTS / 'left.csv'}", sheet: null, header_row: 0, fields: {{no: 单号, amount: 金额, date: 日期, counterparty: 对方, direction: 方向}}}}
right: {{file: "{INPUTS / 'right.csv'}", sheet: null, header_row: 0, fields: {{no: 流水号, amount: 发生额, date: 日期, counterparty: 户名, direction: 借贷}}}}
match: {{primary_key: no, composite_keys: [], amount_tolerance: "0.00", date_tolerance_days: 0, direction_rule: signed, amount_scale: 2}}
output: {{path: "{out}"}}
rule_version: "1.0"
contract_version: "1.0"
"""
    p = tmp_path / "c.yaml"; p.write_text(yaml, encoding="utf-8")
    reconcile.run(cfg_mod.load_config(str(p)), run_id="r", run_at="t")
    # 源文件未变
    for path, h in before.items():
        assert integrity.sha256_of(path) == h
    # 运行后网络仍被禁（patch 在本用例内仍生效，teardown 时才由 monkeypatch 恢复）
    with socket.socket() as s, pytest.raises(guard.NetworkDisabledError):
        s.connect(("127.0.0.1", 9))
