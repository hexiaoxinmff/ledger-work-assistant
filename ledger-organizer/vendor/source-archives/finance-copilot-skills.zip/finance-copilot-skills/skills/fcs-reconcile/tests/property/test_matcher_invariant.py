from decimal import Decimal

import config
import matcher
from models import StdRow


def _rows(spec: list[tuple[str, str]]) -> list[StdRow]:
    return [StdRow(row_id=i, source_row=i + 2, no=no,
                   amount=Decimal(a), date=None, counterparty=None,
                   direction_raw=None) for i, (no, a) in enumerate(spec)]


def test_every_row_accounted_exactly_once() -> None:
    left = _rows([("A1", "1"), ("A2", "2"), ("A1", "9")])   # A1 重复
    right = _rows([("A1", "1"), ("B9", "5")])
    out = matcher.match(left, right, config.MatchConfig())
    left_ids = [o.left.row_id for o in out if o.left is not None]
    right_ids = [o.right.row_id for o in out if o.right is not None]
    assert sorted(left_ids) == [0, 1, 2]     # 每个左行恰好一次
    assert sorted(right_ids) == [0, 1]       # 每个右行恰好一次
