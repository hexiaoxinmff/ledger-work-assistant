from decimal import Decimal

import config
import matcher
from models import MatchOutcome, Status, StdRow


def row(rid: int, no: str | None, amt: str | None,
        side_flag: tuple[str, ...] = ()) -> StdRow:
    return StdRow(row_id=rid, source_row=rid + 2, no=no,
                  amount=(Decimal(amt) if amt is not None else None),
                  date=None, counterparty=None, direction_raw=None, quality_flags=side_flag)


def statuses(outcomes: list[MatchOutcome]) -> list[Status]:
    # Status 是 StrEnum：按值排序会落到中文字符的 Unicode 码点序（"右" < "左"），
    # 与测试断言的直觉顺序无关，故显式按成员名排序，避免误将该顺序当作实现契约。
    return sorted((o.status for o in outcomes), key=lambda s: s.name)


def test_unique_equal_auto_matched() -> None:
    out = matcher.match([row(0, "A1", "10.00")], [row(0, "A1", "10.00")], config.MatchConfig())
    assert [o.status for o in out] == [Status.AUTO_MATCHED]
    assert out[0].amount_diff == Decimal("0.00")


def test_tolerance_never_auto_confirms() -> None:
    m = config.MatchConfig(amount_tolerance=Decimal("1.00"))
    out = matcher.match([row(0, "A1", "10.00")], [row(0, "A1", "10.50")], m)
    assert out[0].status == Status.SUSPECT           # 容差内仍需人工，不自动放行


def test_amount_diff_beyond_tolerance() -> None:
    m = config.MatchConfig(amount_tolerance=Decimal("0.10"))
    out = matcher.match([row(0, "A1", "10.00")], [row(0, "A1", "12.00")], m)
    assert out[0].status == Status.AMOUNT_DIFF


def test_duplicate_no_same_side() -> None:
    out = matcher.match([row(0, "A1", "1"), row(1, "A1", "2")], [], config.MatchConfig())
    assert statuses(out) == [Status.DUP_NO, Status.DUP_NO]


def test_multi_candidate_conflict() -> None:
    out = matcher.match([row(0, "A1", "1")], [row(0, "A1", "1"), row(1, "A1", "1")], config.MatchConfig())
    assert Status.MULTI_CANDIDATE in {o.status for o in out}


def test_singletons_become_left_right_only() -> None:
    out = matcher.match([row(0, "L1", "1")], [row(0, "R1", "2")], config.MatchConfig())
    assert statuses(out) == [Status.LEFT_ONLY, Status.RIGHT_ONLY]


def test_quality_rows_bypass() -> None:
    out = matcher.match([row(0, None, None, side_flag=("空编号",))], [], config.MatchConfig())
    assert out[0].status == Status.DATA_QUALITY
