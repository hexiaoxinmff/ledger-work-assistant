import json
from pathlib import Path

import manifest


def test_manifest_structure_no_details(tmp_path: Path) -> None:
    m = manifest.build_manifest(
        skill_version="0.1.0", rule_version="1.0", contract_version="1.0",
        run_id="r1", run_at="2026-07-23T00:00:00",
        inputs=[{"path": "l.xlsx", "sha256": "h1"}],
        outputs=[{"path": "o.xlsx", "sha256": "h2"}],
        field_mapping={"left": {"no": "单号"}}, config_dict={"amount_tolerance": "0.00"},
        counts={"已自动匹配": 3}, warnings=0, errors=0)
    assert m["permissions"] == {"network": "disabled", "source_write": False}
    p = tmp_path / "manifest.json"
    manifest.write_manifest(m, str(p))
    loaded = json.loads(p.read_text(encoding="utf-8"))
    assert loaded["counts"]["已自动匹配"] == 3
    assert loaded["inputs"][0]["sha256"] == "h1"
