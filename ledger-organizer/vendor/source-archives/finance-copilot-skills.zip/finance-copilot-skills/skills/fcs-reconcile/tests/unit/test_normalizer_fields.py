from datetime import date, datetime
from decimal import Decimal

import normalizer


def test_parse_date_multi_format() -> None:
    assert normalizer.parse_date("2026-01-02")[0] == date(2026, 1, 2)
    assert normalizer.parse_date("2026/1/2")[0] == date(2026, 1, 2)
    assert normalizer.parse_date("bad") == (None, "非法日期")


def test_normalize_no_keeps_leading_zero() -> None:
    val, flags = normalizer.normalize_no("  007 ")
    assert val == "007" and flags == ()


def test_dangerous_long_number_flagged_not_fixed() -> None:
    val, flags = normalizer.normalize_no("1.23457E+17")
    assert val == "1.23457E+17"            # 保留原始文本，不"修复"
    assert "危险长编号" in flags


def test_empty_no_flagged() -> None:
    assert normalizer.normalize_no(" ") == (None, ("空编号",))


def test_direction_signed() -> None:
    assert normalizer.normalize_direction(Decimal("10.00"), "付", "signed") == (Decimal("-10.00"), None)
    assert normalizer.normalize_direction(Decimal("10.00"), "收", "signed") == (Decimal("10.00"), None)
    val, flag = normalizer.normalize_direction(Decimal("10.00"), None, "signed")
    assert flag == "方向缺失"


def test_parse_date_accepts_datetime_and_timestamp() -> None:
    import pandas as pd
    assert normalizer.parse_date(datetime(2026, 1, 2, 10, 30))[0] == date(2026, 1, 2)
    assert normalizer.parse_date(date(2026, 1, 2))[0] == date(2026, 1, 2)
    assert normalizer.parse_date(pd.Timestamp("2026-01-02"))[0] == date(2026, 1, 2)


def test_parse_date_dotted_and_yyyymmdd() -> None:
    assert normalizer.parse_date("2026.01.02")[0] == date(2026, 1, 2)
    assert normalizer.parse_date("20260102")[0] == date(2026, 1, 2)


def test_dangerous_long_pure_digits_flagged() -> None:
    val, flags = normalizer.normalize_no("1234567890123456")   # 16 位纯数字
    assert val == "1234567890123456"
    assert "危险长编号" in flags
    _, flags15 = normalizer.normalize_no("123456789012345")     # 15 位，不触发
    assert flags15 == ()


def test_direction_flag_decoupled_from_amount() -> None:
    assert normalizer.normalize_direction(None, None, "signed") == (None, "方向缺失")
    assert normalizer.normalize_direction(None, "付", "signed") == (None, None)
    assert normalizer.normalize_direction(Decimal("10.00"), "借", "signed") == (Decimal("10.00"), None)
