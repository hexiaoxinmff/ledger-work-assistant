from datetime import date
from decimal import Decimal

import config
import normalizer
import pandas as pd


def _fields() -> config.FieldMap:
    return config.FieldMap(no="单号", amount="金额", date="日期", counterparty="对方", direction="方向")


def _match() -> config.MatchConfig:
    return config.MatchConfig()


def test_assemble_stdrows() -> None:
    df = pd.DataFrame({"单号": ["A1", " "], "金额": ["10.00", "bad"],
                       "日期": ["2026-01-01", "2026-01-02"], "对方": ["X", "Y"],
                       "方向": ["收", "付"]})
    rows = normalizer.normalize(df, _fields(), _match())
    assert len(rows) == 2
    assert rows[0].no == "A1" and rows[0].amount == Decimal("10.00")
    assert rows[0].row_id == 0
    # 第 2 行：空编号 + 非法金额 → 两个质量标记
    assert "空编号" in rows[1].quality_flags
    assert "非法金额" in rows[1].quality_flags


def test_empty_cells_are_missing_not_nan_string() -> None:
    # 真实空单元格 → pandas NaN（float）；不得变成字符串 "nan"
    df = pd.DataFrame({"单号": ["A1", float("nan")], "金额": ["10.00", float("nan")],
                       "日期": ["2026-01-01", float("nan")], "对方": ["X", float("nan")],
                       "方向": ["收", float("nan")]})
    rows = normalizer.normalize(df, _fields(), _match())
    assert rows[1].no is None
    assert "空编号" in rows[1].quality_flags
    assert "非法金额" in rows[1].quality_flags
    assert rows[1].counterparty is None
    assert rows[1].direction_raw is None


def test_timestamp_date_cell_parsed() -> None:
    df = pd.DataFrame({"单号": ["A1"], "金额": ["10.00"],
                       "日期": [pd.Timestamp("2026-01-02")], "对方": ["X"], "方向": ["收"]})
    rows = normalizer.normalize(df, _fields(), _match())
    assert rows[0].date == date(2026, 1, 2)
    assert "非法日期" not in rows[0].quality_flags
