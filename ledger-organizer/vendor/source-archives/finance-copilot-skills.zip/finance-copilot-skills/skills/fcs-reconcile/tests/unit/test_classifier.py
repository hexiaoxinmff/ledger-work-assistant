from decimal import Decimal

import classifier
from models import MatchOutcome, Status, StdRow


def _r(rid: int, amt: str) -> StdRow:
    return StdRow(row_id=rid, source_row=rid + 2, no="A1", amount=Decimal(amt),
                  date=None, counterparty=None, direction_raw=None)


def test_classify_amount_diff_fills_fields() -> None:
    o = MatchOutcome(Status.AMOUNT_DIFF, left=_r(0, "12.00"), right=_r(0, "10.00"),
                     amount_diff=Decimal("2.00"), rule="金额超容差")
    item = classifier.classify([o])[0]
    assert item.priority == "高"
    assert item.sheet == "待处理事项"
    assert item.amount_left == Decimal("12.00")
    assert item.amount_right == Decimal("10.00")
    assert item.amount_diff == Decimal("2.00")
    assert item.left_source_row == 2 and item.right_source_row == 2
    assert item.basis  # 非空判断依据


def test_classify_left_only() -> None:
    o = MatchOutcome(Status.LEFT_ONLY, left=_r(0, "5.00"), rule="仅左侧存在")
    item = classifier.classify([o])[0]
    assert item.sheet == "待处理事项" and item.priority == "中"
    assert item.amount_right is None
