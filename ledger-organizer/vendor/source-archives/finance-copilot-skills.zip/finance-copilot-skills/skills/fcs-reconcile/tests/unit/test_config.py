from decimal import Decimal
from pathlib import Path

import config
import pytest

VALID = """
left:  {{file: "{L}", sheet: null, header_row: 0, fields: {{"no": 单号, "amount": 金额, "date": 日期, "counterparty": 对方, "direction": 方向}}}}
right: {{file: "{R}", sheet: null, header_row: 0, fields: {{"no": 流水号, "amount": 发生额, "date": 日期, "counterparty": 户名, "direction": 借贷}}}}
match: {{primary_key: "no", composite_keys: [], amount_tolerance: "0.00", date_tolerance_days: 0, direction_rule: signed, amount_scale: 2}}
output: {{path: "{O}"}}
rule_version: "1.0"
contract_version: "1.0"
"""


def _write(tmp_path: Path, out_name: str = "out.xlsx") -> Path:
    L = tmp_path / "left.xlsx"; L.write_text("x")
    R = tmp_path / "right.xlsx"; R.write_text("y")
    O = tmp_path / out_name
    cfg = tmp_path / "c.yaml"
    cfg.write_text(VALID.format(L=L, R=R, O=O))
    return cfg


def test_load_valid_config(tmp_path: Path) -> None:
    c = config.load_config(str(_write(tmp_path)))
    assert c.match.amount_tolerance == Decimal("0.00")
    assert c.left.fields.no == "单号"
    assert c.contract_version == "1.0"


def test_reject_output_overwriting_input(tmp_path: Path) -> None:
    with pytest.raises(config.ConfigError):
        config.load_config(str(_write(tmp_path, out_name="left.xlsx")))


def test_reject_bad_tolerance(tmp_path: Path) -> None:
    cfg = _write(tmp_path)
    cfg.write_text(cfg.read_text().replace('"0.00"', '"abc"'))
    with pytest.raises(config.ConfigError):
        config.load_config(str(cfg))


def test_unquoted_no_key_in_fields(tmp_path: Path) -> None:
    # 契约示例中 fields 的 `no` 键未加引号；YAML 解析为布尔 False，
    # 加载器需还原为字符串 "no"。
    L = tmp_path / "left.xlsx"; L.write_text("x")
    R = tmp_path / "right.xlsx"; R.write_text("y")
    O = tmp_path / "out.xlsx"
    yaml_text = f"""
left:  {{file: "{L}", sheet: null, header_row: 0, fields: {{no: 单号, amount: 金额, date: 日期, counterparty: 对方, direction: 方向}}}}
right: {{file: "{R}", sheet: null, header_row: 0, fields: {{no: 流水号, amount: 发生额, date: 日期, counterparty: 户名, direction: 借贷}}}}
match: {{amount_tolerance: "0.00"}}
output: {{path: "{O}"}}
rule_version: "1.0"
contract_version: "1.0"
"""
    cfg = tmp_path / "c.yaml"; cfg.write_text(yaml_text)
    c = config.load_config(str(cfg))
    assert c.left.fields.no == "单号"
    assert c.right.fields.no == "流水号"


def test_reject_negative_tolerance(tmp_path: Path) -> None:
    cfg = _write(tmp_path)
    cfg.write_text(cfg.read_text().replace('"0.00"', '"-1.00"'))
    with pytest.raises(config.ConfigError):
        config.load_config(str(cfg))


def test_reject_nan_tolerance(tmp_path: Path) -> None:
    cfg = _write(tmp_path)
    cfg.write_text(cfg.read_text().replace('"0.00"', '"nan"'))
    with pytest.raises(config.ConfigError):
        config.load_config(str(cfg))


def test_reject_missing_output_path(tmp_path: Path) -> None:
    cfg = _write(tmp_path)
    cfg.write_text(cfg.read_text().replace("path:", "other:"))
    with pytest.raises(config.ConfigError):
        config.load_config(str(cfg))


def test_reject_malformed_match(tmp_path: Path) -> None:
    cfg = _write(tmp_path)
    cfg.write_text(cfg.read_text().replace("date_tolerance_days: 0", 'date_tolerance_days: "abc"'))
    with pytest.raises(config.ConfigError):
        config.load_config(str(cfg))


def test_reject_composite_without_amount(tmp_path: Path) -> None:
    cfg = _write(tmp_path)
    cfg.write_text(cfg.read_text().replace("composite_keys: []", 'composite_keys: ["date", "counterparty"]'))
    with pytest.raises(config.ConfigError):
        config.load_config(str(cfg))


def test_reject_invalid_composite_key(tmp_path: Path) -> None:
    cfg = _write(tmp_path)
    cfg.write_text(cfg.read_text().replace("composite_keys: []", 'composite_keys: ["amount", "bogus"]'))
    with pytest.raises(config.ConfigError):
        config.load_config(str(cfg))


def test_reject_bad_direction_rule(tmp_path: Path) -> None:
    cfg = _write(tmp_path)
    cfg.write_text(cfg.read_text().replace("direction_rule: signed", "direction_rule: bogus"))
    with pytest.raises(config.ConfigError):
        config.load_config(str(cfg))


def test_reject_signed_without_direction_field(tmp_path: Path) -> None:
    L = tmp_path / "l.xlsx"; L.write_text("x")
    R = tmp_path / "r.xlsx"; R.write_text("y")
    O = tmp_path / "o.xlsx"
    yaml_text = f"""
left:  {{file: "{L}", sheet: null, header_row: 0, fields: {{"no": 单号, "amount": 金额, "date": 日期, "counterparty": 对方}}}}
right: {{file: "{R}", sheet: null, header_row: 0, fields: {{"no": 流水号, "amount": 发生额, "date": 日期, "counterparty": 户名}}}}
match: {{direction_rule: signed}}
output: {{path: "{O}"}}
rule_version: "1.0"
contract_version: "1.0"
"""
    cfg = tmp_path / "c.yaml"; cfg.write_text(yaml_text)
    with pytest.raises(config.ConfigError):
        config.load_config(str(cfg))
