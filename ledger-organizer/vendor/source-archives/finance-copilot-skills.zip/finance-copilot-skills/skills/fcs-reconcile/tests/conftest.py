"""pytest 配置：把本 Skill 的 scripts/ 注入 sys.path。

scripts/ 采用平铺模块（不包化，见项目结构设计 D4），因此测试需将 scripts/
目录加入 sys.path，才能像运行时那样 `import matcher`、`import normalizer` 等。
"""

import sys
from pathlib import Path

_SCRIPTS = Path(__file__).resolve().parent.parent / "scripts"
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))
