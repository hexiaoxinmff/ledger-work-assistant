from decimal import Decimal

import normalizer


def test_parse_thousands_and_currency() -> None:
    val, flag = normalizer.parse_amount("￥1,234.5", 2)
    assert val == Decimal("1234.50")
    assert flag is None


def test_parse_fullwidth_and_spaces() -> None:
    val, flag = normalizer.parse_amount("  １２．３４５ ", 2)
    assert val == Decimal("12.35")   # 四舍五入到 2 位（ROUND_HALF_UP）
    assert flag is None


def test_illegal_amount_flagged_not_guessed() -> None:
    val, flag = normalizer.parse_amount("待补", 2)
    assert val is None
    assert flag == "非法金额"


def test_empty_amount_flagged() -> None:
    assert normalizer.parse_amount(None, 2) == (None, "非法金额")


def test_nan_amount_flagged() -> None:
    assert normalizer.parse_amount("nan", 2) == (None, "非法金额")
    assert normalizer.parse_amount("NaN", 2) == (None, "非法金额")


def test_infinity_amount_flagged() -> None:
    assert normalizer.parse_amount("inf", 2) == (None, "非法金额")
    assert normalizer.parse_amount("Infinity", 2) == (None, "非法金额")
