# fcs-reconcile 测试

与 Skill 同目录、随 Skill 演进；发布时由 `tools/build` 剥离。
通过 `conftest.py` 将 `scripts/` 注入 `sys.path` 以导入平铺模块。

| 目录 | 用途（PRD §10.1 / 技术设计 §10） |
|---|---|
| `unit/` | 各模块单元测试 |
| `property/` | 勾稽恒等式恒成立、左右对称、已匹配集合无重复占用 |
| `golden/` | 黄金答案：`inputs/` 脱敏输入 → `expected/` 期望汇总/计数/勾稽，逐版本回归 |
| `boundary/` | 空编号、非法金额、危险长编号、重复编号、多候选、容差上下边界、日期跨界 |
| `security/` | 网络隔离（拦出站）、日志泄露扫描、源文件前后哈希一致 |

各目录当前仅占位（`.gitkeep`），随实现补充用例。
