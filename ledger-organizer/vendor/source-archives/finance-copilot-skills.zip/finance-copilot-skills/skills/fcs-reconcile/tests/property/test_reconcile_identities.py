from decimal import Decimal

import config
import matcher
import summary
from models import StdRow


def _rows(spec: list[tuple[str, str]]) -> list[StdRow]:
    return [StdRow(row_id=i, source_row=i + 2, no=no, amount=Decimal(a), date=None,
                   counterparty=None, direction_raw=None) for i, (no, a) in enumerate(spec)]


def test_identities_hold_on_mixed_input() -> None:
    left = _rows([("A1", "10.00"), ("A2", "20.00"), ("A1", "99.00")])
    right = _rows([("A1", "10.00"), ("B9", "7.00")])
    outs = matcher.match(left, right, config.MatchConfig())
    s = summary.build_summary(outs, len(left), len(right))
    assert s["quantity_reconciled"] is True
    assert s["amount_reconciled"] is True
