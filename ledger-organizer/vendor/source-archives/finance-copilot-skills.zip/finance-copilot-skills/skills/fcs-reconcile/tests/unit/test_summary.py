from decimal import Decimal
from typing import cast

import summary
from models import MatchOutcome, Status, StdRow


def _r(rid: int, amt: str) -> StdRow:
    return StdRow(row_id=rid, source_row=rid + 2, no="A", amount=Decimal(amt),
                  date=None, counterparty=None, direction_raw=None)


def test_summary_counts_and_reconciliation() -> None:
    outs = [
        MatchOutcome(Status.AUTO_MATCHED, left=_r(0, "10.00"), right=_r(0, "10.00"), amount_diff=Decimal("0.00")),
        MatchOutcome(Status.LEFT_ONLY, left=_r(1, "5.00")),
    ]
    s = summary.build_summary(outs, left_total_rows=2, right_total_rows=1)
    # build_summary 的返回类型是 dict[str, object]，嵌套取值前收窄（与 reconcile.py 同惯例）
    counts = cast(dict[str, int], s["counts"])
    assert counts["已自动匹配"] == 1
    assert counts["左侧单边"] == 1
    assert s["quantity_reconciled"] is True
    assert s["amount_reconciled"] is True
    assert s["left_amount_total"] == "15.00"
    assert s["right_amount_total"] == "10.00"


def test_amount_reconciled_detects_inconsistent_diff() -> None:
    # matcher 的 amount_diff 与左右金额不符（模拟 diff 计算 bug）→ 金额勾稽应失败
    o = MatchOutcome(Status.AUTO_MATCHED, left=_r(0, "10.00"), right=_r(0, "10.00"),
                     amount_diff=Decimal("999.99"))
    s = summary.build_summary([o], left_total_rows=1, right_total_rows=1)
    assert s["amount_reconciled"] is False


def test_quantity_reconciled_detects_row_count_mismatch() -> None:
    o = MatchOutcome(Status.LEFT_ONLY, left=_r(0, "5.00"))
    # 声称左表 2 行，但只有 1 行被计入 → 数量勾稽应失败
    s = summary.build_summary([o], left_total_rows=2, right_total_rows=0)
    assert s["quantity_reconciled"] is False
