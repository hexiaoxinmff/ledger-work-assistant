from pathlib import Path

import config
import integrity
import io_reader
import pandas as pd
import pytest


def _spec(path: Path) -> config.TableSpec:
    return config.TableSpec(file=str(path), sheet=None, header_row=0,
                            fields=config.FieldMap(no="单号", amount="金额", date="日期",
                                                   counterparty="对方", direction="方向"))


def test_read_csv_amount_as_string(tmp_path: Path) -> None:
    p = tmp_path / "l.csv"
    pd.DataFrame({"单号": ["A1"], "金额": ["1,234.50"], "日期": ["2026-01-01"],
                  "对方": ["X"], "方向": ["收"]}).to_csv(p, index=False)
    df, sha = io_reader.read_table(_spec(p))
    assert df.loc[0, "金额"] == "1,234.50"     # 未被转 float
    assert len(sha) == 64


def test_source_not_modified(tmp_path: Path) -> None:
    p = tmp_path / "l.csv"
    pd.DataFrame({"单号": ["A1"], "金额": ["1.00"], "日期": ["2026-01-01"],
                  "对方": ["X"], "方向": ["收"]}).to_csv(p, index=False)
    before = integrity.sha256_of(str(p))
    io_reader.read_table(_spec(p))
    assert integrity.sha256_of(str(p)) == before


def test_read_xlsx_amount_as_string(tmp_path: Path) -> None:
    p = tmp_path / "l.xlsx"
    pd.DataFrame({"单号": ["A1"], "金额": ["1,234.50"], "日期": ["2026-01-01"],
                  "对方": ["X"], "方向": ["收"]}).to_excel(p, index=False)
    df, sha = io_reader.read_table(_spec(p))
    assert df.loc[0, "金额"] == "1,234.50"
    assert len(sha) == 64


def test_non_default_header_row(tmp_path: Path) -> None:
    p = tmp_path / "l.csv"
    # 第 1 行为说明行，真实表头在第 2 行 → header_row=1
    p.write_text("说明行,x,y,z,w\n单号,金额,日期,对方,方向\nA1,10.00,2026-01-01,X,收\n", encoding="utf-8")
    spec = config.TableSpec(file=str(p), sheet=None, header_row=1,
                            fields=config.FieldMap(no="单号", amount="金额", date="日期",
                                                   counterparty="对方", direction="方向"))
    df, _ = io_reader.read_table(spec)
    assert df.loc[0, "金额"] == "10.00"


def test_missing_configured_column_raises(tmp_path: Path) -> None:
    p = tmp_path / "l.csv"
    # 真实金额列名（金额X）与配置（金额）不一致 → 应报错，而非静默 float 载入
    pd.DataFrame({"单号": ["A1"], "金额X": ["1.00"], "日期": ["2026-01-01"],
                  "对方": ["X"], "方向": ["收"]}).to_csv(p, index=False)
    with pytest.raises(ValueError):
        io_reader.read_table(_spec(p))
