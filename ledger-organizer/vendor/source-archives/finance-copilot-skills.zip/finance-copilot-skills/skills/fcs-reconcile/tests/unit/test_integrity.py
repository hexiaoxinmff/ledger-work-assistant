import os
from pathlib import Path

import integrity
import pytest


def test_sha256_stable(tmp_path: Path) -> None:
    f = tmp_path / "a.txt"
    f.write_text("hello")
    assert integrity.sha256_of(str(f)) == integrity.sha256_of(str(f))
    assert len(integrity.sha256_of(str(f))) == 64


def test_output_cannot_overwrite_input(tmp_path: Path) -> None:
    inp = tmp_path / "in.xlsx"
    inp.write_text("x")
    with pytest.raises(ValueError):
        integrity.assert_output_not_overwrites_input(str(inp), [str(inp)])


def test_output_overwrite_detected_via_messy_path(tmp_path: Path) -> None:
    # realpath 归一：同一文件的"绕路"路径也应被判为覆盖
    inp = tmp_path / "in.xlsx"
    inp.write_text("x")
    messy = os.path.join(str(tmp_path), "sub", "..", "in.xlsx")
    with pytest.raises(ValueError):
        integrity.assert_output_not_overwrites_input(messy, [str(inp)])


def test_output_overwrite_detected_via_symlink(tmp_path: Path) -> None:
    inp = tmp_path / "in.xlsx"
    inp.write_text("x")
    link = tmp_path / "alias.xlsx"
    link.symlink_to(inp)
    with pytest.raises(ValueError):
        integrity.assert_output_not_overwrites_input(str(link), [str(inp)])


def test_output_allows_distinct_path(tmp_path: Path) -> None:
    inp = tmp_path / "in.xlsx"
    inp.write_text("x")
    out = tmp_path / "out.xlsx"
    integrity.assert_output_not_overwrites_input(str(out), [str(inp)])  # 不抛


def test_verify_unchanged_detects_change() -> None:
    with pytest.raises(ValueError):
        integrity.verify_unchanged({"a": "h1"}, {"a": "h2"})
    integrity.verify_unchanged({"a": "h1"}, {"a": "h1"})  # 一致：不抛


def test_verify_unchanged_detects_missing_key() -> None:
    # after 缺少 before 中的 path（源文件消失）也应判为已变更
    with pytest.raises(ValueError):
        integrity.verify_unchanged({"a": "h1"}, {})
