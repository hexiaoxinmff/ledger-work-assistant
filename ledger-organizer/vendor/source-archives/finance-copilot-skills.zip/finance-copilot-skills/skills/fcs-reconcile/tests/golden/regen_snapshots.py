"""黄金答案快照的生成与读取（NFR-05）。

⚠ **重生成的前置条件**：只有当 `rule_version` 或 `contract_version` 有意 bump、
或输入数据有意变更时才执行本脚本，且必须在提交说明里逐条讲清差异的来源。
**因为回归测试红了就重生成快照 = 把回归钉死为期望值**，那比没有快照更糟——
从此所有后续比对都以错误结果为基准。

用法：

    uv run python skills/fcs-reconcile/tests/golden/regen_snapshots.py

生成与比对共用本模块的 dump 函数（`test_e2e_golden.py` 从这里 import），
两处各写一份的话，快照"永远通过"而没人察觉。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
INPUTS = HERE / "inputs"
EXPECTED = HERE / "expected"
SCRIPTS = HERE.parent.parent / "scripts"

if str(SCRIPTS) not in sys.path:            # 直接运行时自注入；pytest 下由 conftest 完成
    sys.path.insert(0, str(SCRIPTS))

import config as cfg_mod  # noqa: E402
import reconcile  # noqa: E402
from openpyxl import load_workbook  # noqa: E402

WORKBOOK_SNAPSHOT = EXPECTED / "result.snapshot.json"
MANIFEST_SNAPSHOT = EXPECTED / "manifest.snapshot.json"

# 固定的运行标识：快照要与运行时刻无关
RUN_ID = "golden"
RUN_AT = "2026-01-01T00:00:00"

# manifest 中随环境或版本变化、不该进快照的字段。
# 剔除它们不是"放宽"，而是各自另有守卫或另有含义：
MANIFEST_VOLATILE = {
    "run_id",           # 每次运行不同，本就是运行标识
    "run_at",           # 同上
    "skill_version",    # 每次发版都变；跨 6 处的一致性由 test_version_consistency 守
}
# inputs/outputs 里逐条要剔除的键
PATH_VOLATILE = {
    "path",             # 绝对路径，随机器与 tmp_path 变化
}
# 输出文件的 sha256 单独说明：**它跨运行不可重复**。
# xlsx 是 zip，条目时间戳与 docProps/core.xml 的创建时间每次不同，同样的输入两次运行
# 得到的文件哈希不同（实测：同进程内一致只是被秒级精度掩盖，隔 3 秒的两个进程就会分叉）。
# 该哈希的用途是"事后验证这份结果文件没被篡改"（FT-06），不是"验证两次运行结果相同"——
# 后者由本快照的单元格内容比对负责。
OUTPUT_VOLATILE = PATH_VOLATILE | {"sha256"}


def make_config(out_path: Path) -> cfg_mod.ReconcileConfig:
    """构造黄金答案用例的配置。生成与测试共用，避免两份 YAML 漂移。"""
    yaml = f"""
left:  {{file: "{INPUTS / 'left.csv'}", sheet: null, header_row: 0, fields: {{no: 单号, amount: 金额, date: 日期, counterparty: 对方, direction: 方向}}}}
right: {{file: "{INPUTS / 'right.csv'}", sheet: null, header_row: 0, fields: {{no: 流水号, amount: 发生额, date: 日期, counterparty: 户名, direction: 借贷}}}}
match: {{primary_key: no, composite_keys: [], amount_tolerance: "0.00", date_tolerance_days: 0, direction_rule: signed, amount_scale: 2}}
output: {{path: "{out_path}"}}
rule_version: "1.0"
contract_version: "1.0"
"""
    cfg_path = out_path.parent / "golden-config.yaml"
    cfg_path.write_text(yaml, encoding="utf-8")
    return cfg_mod.load_config(str(cfg_path))


def dump_workbook(path: Path) -> dict[str, list[list[str]]]:
    """把工作簿读成 {表名: [[单元格文本, ...], ...]}。

    逐单元格取值并统一转字符串：reporter 写入的金额本就是 `str(Decimal)`，
    统一成文本后，比对结果不受 openpyxl 读回时的类型推断影响。
    """
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        return {
            name: [
                ["" if cell is None else str(cell) for cell in row]
                for row in workbook[name].iter_rows(values_only=True)
            ]
            for name in workbook.sheetnames
        }
    finally:
        workbook.close()


def dump_manifest(path: Path) -> dict[str, Any]:
    """读运行清单并剔除随环境/版本变化的字段（见 MANIFEST_VOLATILE 的逐项理由）。"""
    raw = json.loads(path.read_text(encoding="utf-8"))
    stable = {k: v for k, v in raw.items() if k not in MANIFEST_VOLATILE}
    # inputs 保留 sha256——它守的是"测试输入文件没被意外改动"，很有价值
    stable["inputs"] = [
        {k: v for k, v in item.items() if k not in PATH_VOLATILE} for item in raw["inputs"]
    ]
    stable["outputs"] = [
        {k: v for k, v in item.items() if k not in OUTPUT_VOLATILE} for item in raw["outputs"]
    ]
    return stable


def run_golden(out_path: Path) -> tuple[Path, Path]:
    """跑一次黄金答案用例，返回 (工作簿路径, 运行清单路径)。"""
    reconcile.run(make_config(out_path), run_id=RUN_ID, run_at=RUN_AT)
    return out_path, out_path.parent / (out_path.name + ".manifest.json")


def _write(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8")


def main() -> int:
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        workbook_path, manifest_path = run_golden(Path(tmp) / "result.xlsx")
        EXPECTED.mkdir(exist_ok=True)
        _write(WORKBOOK_SNAPSHOT, dump_workbook(workbook_path))
        _write(MANIFEST_SNAPSHOT, dump_manifest(manifest_path))

    print(f"已重生成快照：\n  {WORKBOOK_SNAPSHOT}\n  {MANIFEST_SNAPSHOT}")
    print("\n⚠ 请逐张核对差异来源后再提交——快照测试的价值全部建立在"
          "「快照本身是对的」之上。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
