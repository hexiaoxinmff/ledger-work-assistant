# finance-copilot-skills（财务助手 Skill 工具集）

![license](https://img.shields.io/badge/license-MIT-blue)
![language](https://img.shields.io/badge/language-简体中文优先-green)
![status](https://img.shields.io/badge/status-v0.3.0-blue)
![release](https://img.shields.io/badge/release-Preview-yellow)
![data](https://img.shields.io/badge/数据-本地处理%20·%20默认禁网-brightgreen)
![agents](https://img.shields.io/badge/agents-Claude%20Code%20%7C%20Codex%20%7C%20WorkBuddy-grey)

**简体中文** | [English](README.en.md)

finance-copilot-skills 是一套装进你已经在用的 AI 编程代理（Claude Code / Codex / WorkBuddy）的财务工作流 Skill，简体中文优先——**程序管算**（金额、匹配、勾稽由本地确定性代码完成），**AI 管引导与解释**（问清字段、说明结果、提醒风险），**人管业务判断**（哪笔算对上、哪笔要追、要不要放行）。面向财务、审计人员与中小企业管理者：不用会 Python、不用敲命令，账也不上传到任何地方。它**不是** ERP、财务系统或记账软件，而是在你现有的 Excel / CSV / 本地文件工作流之上，补一组"小而专"的独立 Skill——装一个不必装一整套。当前 **v0.3.0**：1 个已发布 Skill [`fcs-reconcile`](skills/fcs-reconcile/)（对账，发布状态 `Preview`），另有 8 个候选方向待真实需求验证。每个 Skill 的准确状态、平台支持与测试情况以各自的 [`SKILL_META.yaml`](skills/fcs-reconcile/SKILL_META.yaml) 为准。

## 设计理念

**确定性的事交给程序，模糊的事交给人，AI 只在两者之间做翻译。**

财务工作里最耗时的那部分（多文件提取、格式清洗、流水与台账核对、勾稽检查）规则相对稳定、却极易因复制粘贴和公式出错；最不该自动化的那部分（这笔差额算不算手续费、这笔在途要不要追、能不能放行）依赖业务判断与责任承担。通用 AI 的问题恰恰是把两者搞反了：用不确定的推理去代替确定性计算，同一份数据两次跑出不同结果，还不告诉你文件有没有被上传、保存、用于训练。

本工具集把这条线划死：**金额计算、匹配、勾稽、格式转换、规则校验一律由可重复执行的本地程序完成**；AI 负责理解你的意图、引导字段确认、解释结果、提醒风险；**AI 不猜金额、不在多个候选里任选一个、不编造差异原因、不在规则不明确时自动确认、不替财务人员做最终业务判断**。

**不可退让的底线**：任何不确定的匹配一律不自动放行；每个结果都说清用了什么输入、什么规则、依据是什么、哪些仍需人工确认；原始明细默认不进入模型上下文。

**冲突仲裁：严谨性一票否决。** 不得为了"发布更快、流程更轻、少一次人工确认"而放松确定性校验、跳过测试或模糊化数据流披露。看似两难时，通常意味着流程本身该重新设计——"人工确认拖慢流程"要优化确认环节，而不是放宽自动确认条件（[PRD §1.2](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md)）。

**免费不以数据为代价**：核心能力免费，且不通过收集、出售、训练或分析你的财务数据获得收益。不设隐藏付费墙、不强制注册、不默认上传使用记录、不在你不知情时启用遥测。

## ✅ 会做的 / ⛔ 不做的

| ✅ finance-copilot-skills 会做的 | ⛔ finance-copilot-skills 不做的 |
| --- | --- |
| 核对银行流水与收付款台账、应收与回款、应付与付款 | 在候选不唯一时替你"猜"这笔该配哪笔 |
| 把差异分成 8 种中文状态，排出人工复核优先级 | 用模糊匹配自动放行、把不确定当成已对上 |
| 运行前把读写哪些文件、是否联网、原始数据是否进模型摆给你确认 | 自动登录网银 / 税务 / 生产 ERP，替你保管凭据 |
| 输入文件读取前后算 SHA-256，源文件只读，输出不覆盖输入 | 生成、审批或过账会计凭证 |
| 每次运行落一份机器可读运行清单（版本、哈希、字段映射、配置、计数） | 出税务申报结论或会计政策判断 |
| 产出 Excel 结果工作簿，你继续在 Excel 里复核、流转、交审计 | 默认连接数据库与生产系统 |
| 明说哪些还需人工确认、哪些是数据质量问题 | 收集、出售你的财务数据，或用它训练模型 |
| 一个 Skill 只解决一个任务，可独立安装 / 升级 / 卸载 | 做覆盖所有能力的"超级 Skill" |

**"不自动放行"不是能力缺口，是责任边界。** 对账里"看起来能配上"的那一笔，恰恰是最需要人看的那一笔。所以容差在这里只做**差异分级**，不放宽自动确认：金额差 8 元可能是手续费，也可能是少收了钱，程序不替你定性，只把它排到「待处理事项」的显眼位置，附上左右金额、差异、来源行与建议动作。

> 每条边界的出处见 [PRD §2.5 非目标](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md) 与 [§四 设计原则](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md)；对账的自动确认铁律见 [matching-rules.md](skills/fcs-reconcile/references/matching-rules.md)。

## 财务工作流 × 工具集能力

| 财务任务 | Skill | 做什么 | 状态 |
| --- | --- | --- | --- |
| **对账** | [`fcs-reconcile`](skills/fcs-reconcile/) | 银行流水 vs 收付款台账、应收 vs 回款、应付 vs 付款、两个业务系统明细核对；定位差异并出人工复核底稿 | ✅ 已发布（`Preview`） |
| 数据清洗 | `fcs-clean` | 清洗 Excel / CSV 财务明细，统一编号、金额与日期格式 | 🔭 候选，待需求验证 |
| 字段提取 | `fcs-extract` | 从结构化文件提取指定财务字段 | 🔭 候选，待需求验证 |
| 报表生成 | `fcs-report` | 按确认的模板生成管理财务报表 | 🔭 候选，待需求验证 |
| 勾稽检查 | `fcs-check` | 检查报表勾稽、公式与异常波动 | 🔭 候选，待需求验证 |
| 财报分析 | `fcs-analyze` | 分析财务报表、趋势与关键指标 | 🔭 候选，待需求验证 |
| 预算对比 | `fcs-budget` | 对比预算与实际并定位差异 | 🔭 候选，待需求验证 |
| 应收账龄 | `fcs-aging` | 生成与分析应收账龄 | 🔭 候选，待需求验证 |
| 费用检查 | `fcs-expense` | 检查费用明细中的重复、异常与缺失字段 | 🔭 候选，待需求验证 |
| 凭证过账 / 税务申报 / 联网登录外部系统 | —（不设 Skill） | 属核算系统与专业判断范畴，明文留给人和既有系统 | 🚫 明文不覆盖 |

**候选不等于路线图上的承诺。** 每个新 Skill 都要过独立需求验证（有真实用户、有重复出现的任务、可验证输入输出、确定性部分可程序化、安全边界明确、至少一组脱敏测试数据与黄金答案），不因"工具集想做大"就自动立项（[PRD §8.2](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md)）。涉及 PDF、OCR、税务、凭证或生产系统连接的 Skill，还要单独过安全评审。

## 快速开始

现在能用的是**对账**：把你导出的银行流水和收付款台账两份文件交给它，本地跑出 7 张中文工作表的结果工作簿。仓库里备了演示数据，装完 3 分钟就能看到完整产物。

### 安装

**复制下面对应你的代理的那段话，粘贴给它就行**——它会自己装完，你不用敲任何命令，也不用改里面的任何一个字。三段话只有目标目录不同，各自都是完整的。

**装到 Claude Code** 👇

```text
帮我安装 finance-copilot-skills 财务助手 Skill 工具集：

1. 把 https://github.com/cxtx/finance-copilot-skills 克隆到一个临时目录
2. 确保 ~/.claude/skills/ 存在（没有就创建），把仓库 skills/ 下的**全部子目录**
   复制进去，一个都不能少（当前 1 个：fcs-reconcile）
   - 复制的是子目录本身，别把整个 skills/ 目录整体套进去——多套一层，技能名会
     变成 skills:fcs-reconcile
   - 每个 skill 目录要整体复制：SKILL.md、SKILL_META.yaml、requirements.txt、LICENSE
     与 scripts/ references/ examples/ 都得在，缺 scripts/ 就只能被发现、跑不了对账
   - 同名目录直接覆盖，这就是更新
   - 该目录下其他来源的 skill 一个都别动，千万不要清空目录
3. 装运行时依赖（**只有这一步需要网络**）：
   python -m pip install -r ~/.claude/skills/fcs-reconcile/requirements.txt
   - 用哪个 python 装，后面就得用哪个 python 跑对账脚本，必须是同一个解释器
   - 装完把 pandas / openpyxl / pyyaml 的实际版本告诉我
   - 装不上就把报错原样给我，别跳过这步当作装好了——缺依赖时对账脚本会直接失败
4. 删掉临时目录
5. 告诉我装到了哪里、装了哪些 skill、依赖装在哪个解释器下
```

**装到 Codex** 👇

```text
帮我安装 finance-copilot-skills 财务助手 Skill 工具集：

1. 把 https://github.com/cxtx/finance-copilot-skills 克隆到一个临时目录
2. 确保 ~/.codex/skills/ 存在（没有就创建），把仓库 skills/ 下的**全部子目录**
   复制进去，一个都不能少（当前 1 个：fcs-reconcile）
   - 复制的是子目录本身，别把整个 skills/ 目录整体套进去——多套一层，技能名会
     变成 skills:fcs-reconcile
   - 每个 skill 目录要整体复制：SKILL.md、SKILL_META.yaml、requirements.txt、LICENSE
     与 scripts/ references/ examples/ 都得在，缺 scripts/ 就只能被发现、跑不了对账
   - 同名目录直接覆盖，这就是更新
   - 该目录下其他来源的 skill 一个都别动，千万不要清空目录
3. 装运行时依赖（**只有这一步需要网络**）：
   python -m pip install -r ~/.codex/skills/fcs-reconcile/requirements.txt
   - 用哪个 python 装，后面就得用哪个 python 跑对账脚本，必须是同一个解释器
   - 装完把 pandas / openpyxl / pyyaml 的实际版本告诉我
   - 装不上就把报错原样给我，别跳过这步当作装好了——缺依赖时对账脚本会直接失败
4. 删掉临时目录
5. 告诉我装到了哪里、装了哪些 skill、依赖装在哪个解释器下
```

**装到 WorkBuddy** 👇

```text
帮我安装 finance-copilot-skills 财务助手 Skill 工具集：

1. 把 https://github.com/cxtx/finance-copilot-skills 克隆到一个临时目录
2. 确保 ~/.workbuddy/skills/ 存在（没有就创建），把仓库 skills/ 下的**全部子目录**
   复制进去，一个都不能少（当前 1 个：fcs-reconcile）
   - 复制的是子目录本身，别把整个 skills/ 目录整体套进去——多套一层，技能名会
     变成 skills:fcs-reconcile
   - 每个 skill 目录要整体复制：SKILL.md、SKILL_META.yaml、requirements.txt、LICENSE
     与 scripts/ references/ examples/ 都得在，缺 scripts/ 就只能被发现、跑不了对账
   - 同名目录直接覆盖，这就是更新
   - 该目录下其他来源的 skill 一个都别动，千万不要清空目录
3. 装运行时依赖（**只有这一步需要网络**）：
   python -m pip install -r ~/.workbuddy/skills/fcs-reconcile/requirements.txt
   - 用哪个 python 装，后面就得用哪个 python 跑对账脚本，必须是同一个解释器
   - 装完把 pandas / openpyxl / pyyaml 的实际版本告诉我
   - 装不上就把报错原样给我，别跳过这步当作装好了——缺依赖时对账脚本会直接失败
4. 删掉临时目录
5. 告诉我装到了哪里、装了哪些 skill、依赖装在哪个解释器下
```

装完**新开一个会话**才会加载——已开的会话看不到新技能。WorkBuddy 还可以在「技能」面板里核对是否装齐。

> **只想在单个项目里用？** 把提示词里的用户级路径换成该项目根目录下的项目级目录：
> Claude Code 用 `.claude/skills/`，Codex 用 `.codex/skills/`，**WorkBuddy 用
> `.codebuddy/skills/`**——注意不是 `.workbuddy/`，它的用户级目录叫 `~/.workbuddy/`，
> 项目级目录却沿用底层 CodeBuddy 内核的名字，写错了技能一个都不出现。
>
> **用的是别的宿主？** 同一段提示词，把目标路径换成该宿主的 skills 目录即可。Skill 遵循
> Agent Skills 通用格式（`SKILL.md` + `scripts/` + `references/`），不绑定单一宿主。
> **装错位置的表现是技能一个都不出现、且没有任何报错**——几家宿主的目录互不读取，都用就各装一份。
>
> **安装期联网、运行期禁网**：第 3 步装依赖需要网络；装完之后每次对账都在本地跑，
> `scripts/reconcile.py` 一进来就阻断网络，不再装任何东西、不联任何网。

> ⚠ **三家宿主的支持级别不同，装之前请看清你用的是哪一档：**
>
> | 宿主 | 级别 | 含义 |
> | --- | --- | --- |
> | Claude Code、Codex | **使用验证** | 开发者在多个真实项目中反复安装并跑通。PRD FT-11 的 9 项验证项中，6 项由实际使用覆盖；**权限确认、运行期网络拦截、错误处理这 3 项未在宿主内确认**——它们只在异常分支出现，日常对账走不到。逐项状态见 [验证记录](tests/cross_platform/records/) |
> | WorkBuddy | **格式兼容** | 目录结构符合 Agent Skills 通用格式、路径取自该宿主公开约定，但**本仓库从未在它上面实际跑过** |
>
> 「使用验证」不等于 PRD FT-11 定义的「逐项走查」。完整路径表、9 项验证项清单与排查步骤见
> [多代理安装矩阵](docs/governance/agent-install.md)。

### 3 分钟试一下

仓库 [`skills/fcs-reconcile/examples/`](skills/fcs-reconcile/examples/) 备了一份演示数据（12 行台账 vs 13 行银行流水，埋了 7 类典型差异），把它拿出来对你的代理说：

> 用 fcs-reconcile 帮我核对这两份数据：对账演示数据.xlsx 里的台账和银行流水

它会**先展示数据处理声明等你确认**：

```plaintext
运行模式：本地隔离
将读取：N 个本地文件 ｜ 将写入：M 个结果文件
原始数据进入模型：否
网络访问：已禁用
源文件修改：否
终端输出交易明细：否
输入完整性：读取前后 SHA-256 校验
```

你确认后才本地跑对账，产出结果工作簿与运行清单。示例产物见同目录的 `对账演示数据_对账结果.xlsx`，可以直接打开对照着看该期待什么。

演示数据故意覆盖了对账里最常见的 7 种情形，其中第 ④ 类**刻意保留为"未自动匹配"**，用来演示主键匹配的边界在哪：

| 类型 | 场景 | 你该注意什么 |
| --- | --- | --- |
| ① 完全匹配 | 金额 / 日期 / 编号一致 | 对账基线，落「已匹配」 |
| ② 金额不一致 | 5,800 vs 5,808 | 手续费 / 汇兑差，引出"金额容差" |
| ③ 一对多 | 台账一笔 12,000 ↔ 银行 8,000 + 4,000 | 按合计金额匹配 |
| ④ 多对一 | 台账 3,500 + 2,500 ↔ 银行合并 6,000 | 银行附言无业务单号，纯主键匹配覆盖不到 → 落待处理，交你判断 |
| ⑤ 左表多余 | 台账有、银行无 | 在途 / 未到账 |
| ⑥ 右表多余 | 银行有、台账无 | 漏记账 / 手续费 / 利息 / 匿名收入 |
| ⑦ 日期错位 | 7/3 记账、7/4 入账 | 跨日对账的日期容差 |

## 怎么开口问：对账场景的提问示例

**不用背 Skill 名。** 用你自己的话说出你卡在哪，代理会匹配到对应的 Skill；你也可以直接点名 `fcs-reconcile`，两种方式等价。

> **提问只是开场，不是一问一答。** 它会先问清左右表是哪两份、哪些列是编号 / 金额 / 日期 / 方向、容差定多少、结果写到哪，在数据处理声明处停下等你拍板，**确认前零落盘**。

| 你会这么问 | 落到 | 你会拿到 |
| --- | --- | --- |
| "帮我核对下这个月的银行流水和收款台账" / "这两份账对一下" | `fcs-reconcile` | 字段映射与规则确认 → 数据处理声明 → 7 张中文工作表的结果工作簿 + `manifest.json` 运行清单 |
| "应收和回款对不上，差在哪" / "应付和付款核一下" | `fcs-reconcile` | 同上；左右表换成应收/回款或应付/付款明细即可，规则不变 |
| "两个系统导出来的明细不一致，帮我找差异" | `fcs-reconcile` | 同上；支持左右表字段名不同、非首行表头、指定工作表 |
| "台账和银行差了 8 块，是手续费吗" | `fcs-reconcile`（容差分级） | 落「疑似匹配（待人工确认）」而**不是**自动放行；附左右金额、差异、来源行与建议动作 |
| "同一个单号出现了两次，怎么办" | `fcs-reconcile`（旁路） | 「重复与冲突」表列出**全部**候选与冲突原因，不替你选一个 |
| "这批编号被 Excel 转成科学计数法了" | `fcs-reconcile`（数据质量） | 「数据质量」表标出"危险长编号"、保留原始文本，**不自动"修复"** |
| "对账结果要给审计看，怎么证明没被改过" | `fcs-reconcile`（可审计性） | 「运行参数」表 + `manifest.json`：输入输出文件 SHA-256、字段映射、规则/契约版本、运行时间与配置 |
| "我这数据很敏感，跑之前想确认它不会外传" | 运行前声明 | 读写文件数、原始数据是否进模型、网络状态、源文件是否修改、完整性校验结果——确认后才继续 |

### 这些问法会被拦下来——但每条都有替代出口

| 你可能会这么问 | 为什么不做 | 它会把你引到哪 |
| --- | --- | --- |
| "差不多的就自动配上吧，别让我一条条看" | 模糊匹配自动放行等于把误判写进账，NFR-01 要求确定性自动确认误判率为 0 | → 容差把差异**分级排优先级**，你只需要看「待处理事项」那一张表 |
| "对上的直接帮我过账 / 生成凭证" | 凭证生成、审批、过账属核算系统职责，是明文非目标 | → 结果工作簿带完整来源行，导回你既有的核算流程 |
| "登录我的网银把流水拉下来" | 运行期禁网，不代持任何凭据，也不连生产系统 | → 自己从网银导出 xlsx / csv，再本地对账 |
| "把这两个文件直接发给你分析" | 原始明细默认不进模型上下文（NFR-02） | → 只给文件路径；程序本地读，AI 只收汇总（匹配率、各状态计数、勾稽结论） |
| "这笔差额帮我判断要不要计提 / 怎么做税务处理" | 会计政策与税务结论属专业判断，AI 不出结论 | → 只陈列金额差异、来源行与判断依据，定性交你 |
| "结果直接覆盖回原文件吧" | 输出覆盖输入等于销毁审计证据 | → 输出路径校验会**直接拒绝执行**，请另存新文件 |
| "帮我做个能一键跑完所有账的超级 Skill" | 小而专是硬约束，堆功能会让边界与安全评审失效 | → 一个任务一个 Skill，按需装、按需升级 |

### 串起来看：一次对账从头到尾

```plaintext
 1. 从网银导出流水、从系统导出台账（两份 xlsx/csv）   ← 你自己做，不联网
 2. "帮我核对这两份"                                  → 代理匹配到 fcs-reconcile
 3. 确认左右表、字段映射、容差、借贷方向、输出位置       ← 你拍板
 4. 看数据处理声明（读写几个文件 / 是否进模型 / 网络）   ← 你确认，确认前零落盘
 5. 本地跑对账：读取 → 标准化 → 分阶段匹配 → 分类       ← 程序做，禁网
 6. 勾稽校验（数量勾稽 + 金额勾稽，Decimal）            ← 结论写进总览与运行清单，不静默吞掉
 7. 写 7 张表的结果工作簿 + manifest.json 运行清单       ← 落盘到你指定位置
 8. AI 只拿到汇总：匹配率、各状态计数、勾稽结论           ← 明细留在本地
 9. 你在 Excel 里复核「待处理事项」，填复核状态/复核人/意见 ← 判断归你
10. 结果 + 运行清单一起交审计                            ← 版本、哈希、配置都在里面
```

## 你会拿到什么：结果工作簿的 7 张表

全中文，无英文状态码，打开就能用 Excel 继续筛选、批注、流转（[输出契约 v1.0](docs/contracts/fcs-reconcile/output-contract.md)）：

| 工作表 | 用途 | 关键列 |
| --- | --- | --- |
| **对账总览** | 一屏判断这次对账完成度 | 匹配率、数量勾稽、金额勾稽、左/右金额合计、各状态计数、隐私运行摘要（运行模式 / 是否进模型 / 网络 / 源文件是否修改） |
| **待处理事项** | 人工复核底稿，你的主战场 | 优先级 · 问题类型 · 业务编号 · 左侧金额 · 右侧金额 · 金额差异 · 判断依据 · 建议动作 · 来源行 · 复核状态 · 复核人 · 复核意见 |
| **已匹配** | 自动确认留痕 | 业务编号、左右金额、匹配依据、来源行 |
| **重复与冲突** | 重复编号与全部候选 | 业务编号、候选清单、冲突原因 |
| **数据质量** | 空编号 / 非法金额 / 危险长编号 | 问题类型、来源行、原始值 |
| **审计明细** | 可追溯证据 | 源行、标准化值、命中规则、匹配证据 |
| **运行参数** | 复现这次运行所需的一切 | 输入、字段映射、配置、规则/契约版本、文件哈希 |

**8 种结果状态**（全中文）：已自动匹配 · 疑似匹配 · 金额差异 · 左侧单边 · 右侧单边 · 重复编号 · 多候选冲突 · 数据质量问题。含义与中文财务术语对照见 [field-glossary.md](skills/fcs-reconcile/references/field-glossary.md)。

## 为什么可信

不是承诺，是可以逐条检查的工程设计：

- **自动确认铁律**：进入「已自动匹配」当且仅当 ① 候选唯一（左右各恰一条、无竞争候选）**且** ② 规则完全满足（金额差严格 = 0，或复合键逐字段全等）。任一不满足就转对应待处理 / 冲突状态。**容差只做差异分级，永不放宽自动确认**——容差内的差异属"不确定"，交人判断（[matching-rules.md](skills/fcs-reconcile/references/matching-rules.md)）。
- **金额不碰浮点**：一律 `Decimal` 定点计算，千分位 / 货币符号 / 全角字符先清洗；量化小数位可配，四舍五入 HALF_UP。
- **勾稽显式呈现，不静默吞掉**：`左表行数 = Σ各状态左侧计数`、`右表行数 = Σ各状态右侧计数`、`左金额合计 − 右金额合计 = Σ金额差异`（Decimal）。结论以「通过 / 不通过」写在「对账总览」首屏，同时计入运行清单的 `errors` 计数——勾稽不过意味着"这次对账本身有问题"，你一眼就能看到，而不是拿到一份"看起来对"的结果。它保证的是每一行都有明确去向。
- **运行期禁网**：`scripts/reconcile.py` 第一步执行 `guard.block_network()`，任何出站 `socket.connect` 直接抛 `NetworkDisabledError`。只有**安装依赖**那一步需要网络。
- **源文件只读且可证**：读取前后各算一次 SHA-256 并比对；输出路径等于任一输入路径时直接拒绝执行。
- **明细不越界**：上交给 AI 的只有 `summary`（匹配率、各状态计数、勾稽结论）；原始明细、DataFrame、标准行不出数据平面，终端也不打印交易明细，日志只记状态计数与错误码。
- **可重复**：相同输入 + 相同配置 + 相同规则版本必须产生相同结果（NFR-05）。`rule_version` 与 `contract_version` 一经发布只增不改——已落盘的运行清单引用的是旧版本号，改写它等于篡改审计证据。
- **版本不漂移**：`pyproject.toml`、`SKILL_META.yaml`、`scripts/version.py`、`SKILL.md` 与两份 CHANGELOG 的版本号由 [`tests/supply_chain/test_version_consistency.py`](tests/supply_chain/test_version_consistency.py) 机器断言一致；README 的安装路径由 [`tests/cross_platform/test_install_paths.py`](tests/cross_platform/test_install_paths.py) 对着[安装矩阵](docs/governance/agent-install.md)守卫。这两类漂移在使用侧几乎不可发现，所以必须机器化。
- **测试现状**：单元 / 属性 / 黄金答案（逐单元格快照）/ 安全测试通过（网络隔离、日志脱敏、源文件完整性、输出不覆盖输入），工具集级安全基线 6 项在 CI 中真跑；**独立前向测试为 `self-tested`**——开发者自测过，但"测试者不预知答案"的那一轮还没跑，而开发者越熟悉这个 Skill 就越不能代表陌生用户，所以这里不写 `passing`。

> ⚠ **不要把"本地运行"读成"数据绝不离开本机"。** 本地脚本确实禁网，原始明细默认不进模型；但你与代理的**对话本身**要经过宿主平台（Claude Code / Codex / WorkBuddy 各有自己的数据政策）。所以：文件路径、字段名、汇总数会进对话，交易明细不会。高敏数据请配合完全离线环境使用（[PRD §7.2 宿主平台披露](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md)）。

> ⚠ **当前发布状态是 `Preview`**：不承诺接口稳定。仍未落地的有——FT-11 的 9 项逐项走查（当前是「使用验证」，3 项未在宿主内确认）、PRD §10.1 的独立前向测试（当前是开发者自测）、发布包签名与 SBOM。用于生产账务前请自行按你的内控要求评估，并保留人工复核环节。已知限制逐条列在 [CHANGELOG](CHANGELOG.md) 的「已知限制」里。

## 仓库结构

| 目录 | 用途 |
| --- | --- |
| [`skills/`](skills/) | 各 Skill 开发源（一 Skill 一目录，发布时产出自包含包） |
| [`packages/`](packages/) | 共享库唯一源（经 ≥2 个 Skill 验证后才抽象，当前为空） |
| [`tools/`](tools/) | 构建 / 同步 / 打包 / 签名 / SBOM / 安全校验 / 脚手架 |
| [`tests/`](tests/README.md) | 工具集级测试（触发冲突、跨平台、供应链） |
| [`docs/`](docs/) | [PRD](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md)、[技术设计](docs/design/fcs-reconcile-technical-design-v0.1.md)、[ADR](docs/adr/README.md)、[契约](docs/contracts/fcs-reconcile/input-contract.md)、[安全](docs/security/README.md)、[治理](docs/governance/README.md)与规格 |
| `dist/` | 构建产物：自包含 Skill 包（不入库） |

单个 Skill 内部（以 `fcs-reconcile` 为例）：`SKILL.md`（AI 入口）· `SKILL_META.yaml`（目录元数据）· `scripts/`（确定性执行，数据平面）· `references/`（AI 运行时参考，控制平面）· `agents/`（各代理专属配置）· `examples/`（演示数据与示例结果）· `tests/`（单元 / 属性 / 边界 / 黄金 / 安全）。

**确定性代码归 `scripts/`，AI 可见内容归 `SKILL.md` / `references/`**，两者不得混淆——这是控制平面与数据平面分离的落地方式。项目结构的完整设计与决策依据见 [docs/specs/2026-07-23-project-structure-design.md](docs/specs/2026-07-23-project-structure-design.md)。

## 开发

需要 Python ≥ 3.11 与 [uv](https://docs.astral.sh/uv/)。

```bash
# 依赖管理与统一工具（uv workspace）；uv.lock 是依赖锁定的唯一真源
uv sync

# 全量测试（工具集级 + 各 Skill 内部）
uv run pytest

# 只跑某个 Skill 的测试
uv run pytest skills/fcs-reconcile/tests

# Lint / 类型检查（mypy strict）
uv run ruff check .
uv run mypy .

# 重新生成演示数据与示例结果
python3 skills/fcs-reconcile/examples/gen_reconcile_demo.py
python3 skills/fcs-reconcile/examples/gen_reconcile_result.py
```

直接跑对账引擎（配置字段见[输入契约](docs/contracts/fcs-reconcile/input-contract.md)）：

```bash
python skills/fcs-reconcile/scripts/reconcile.py --config <config.yaml>
```

## 路线图

| 版本 | 主题 | 状态 |
| --- | --- | --- |
| v0.1 | 安全底座与对账参考实现 | ✅ 已发布 |
| **v0.2** | **多代理安装与版本统一** | ✅ 当前版本 |
| v0.3 | 第二个财务 Skill（前置：第一个 Skill 完成真实用户验证） | 计划中 |
| v0.4 | 跨平台分发：先完成 Codex 与 Claude Code 的 FT-11 逐项验证，再扩 GitHub Copilot / Cursor / Gemini CLI；签名发布与 SBOM | 计划中 |
| v0.5 | 工具集治理：Skill 目录、统一质量门禁、开发模板、发布状态、贡献审核、弃用与回滚 | 计划中 |
| v1.0 | 稳定免费工具集：≥3 个经真实用户验证的 Skill、核心安全控制通过独立检查、契约稳定 | 计划中 |

> **路线图是计划，[CHANGELOG](CHANGELOG.md) 是事实。** 两者不一致时以 CHANGELOG 为准（[versioning.md §6](docs/governance/versioning.md)）。

## 贡献

想参与开发或二次定制，先读 [CONTRIBUTING.md](CONTRIBUTING.md)（新增 Skill 的 FT-12 提交清单、三审维度、立项条件）与 [docs/governance/versioning.md](docs/governance/versioning.md)（四层版本的事实源与 bump 时机）。三条最容易踩的：

1. **不放松确定性校验、安全隔离或可核验性**——严谨性一票否决，这条压过一切便利。
2. **`rule_version` / `contract_version` 一经发布只增不改**；运行期版本号只从 `scripts/version.py` 取，不在业务代码里散写字面量。
3. **新增 Skill 要回改 README 三段安装提示词**（点名新 Skill、更新"当前 N 个"），否则 CI 的安装路径守卫会挡下。

⚠ 是否接受社区贡献 Skill、由谁做财务 / 安全 / 代码审核，尚待确定（PRD §10.4 待办 ⑨⑩）。

## 安全

漏洞请**不要**通过公开 issue 报告，也请勿在报告中附带真实财务数据；仅提供脱敏样本。私密报告渠道待定，详见 [SECURITY.md](SECURITY.md)。

## 许可

**[MIT License](LICENSE)** —— 可自由使用、修改、分发、商用与再授权，只需保留版权与许可声明。全文见 [`LICENSE`](LICENSE)。

许可证之外还有一条**不写进许可证、但同样不退让的承诺**：本工具集不收集、不出售、不用于训练你的财务数据（[PRD §1.3](docs/prd/Finance-Copilot-Skills-PRD-v0.2.md)）。MIT 约束的是代码的使用方式，管不了数据；这条承诺由工程设计兜底——运行期禁网、原始明细不进模型、日志不含交易明细，都是可以逐条检查的（见[为什么可信](#为什么可信)）。

软件按"原样"提供，不含任何担保。对账结果**始终需要你的人工复核**——这既是许可证的免责条款，也是本工具集的设计前提。
