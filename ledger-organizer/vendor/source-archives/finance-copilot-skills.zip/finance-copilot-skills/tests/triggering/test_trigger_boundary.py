"""触发边界守卫（FT-03）：断言 SKILL.md 的描述与 corpus.yaml 的边界声明一致。

**这个文件守不了什么，得先说清楚。** 「用户说某句话时宿主是否真的唤起了本 Skill」
是宿主的路由行为，pytest 观测不到。写一个用关键词匹配去模拟宿主路由的测试，只会让
tests.triggering 显示 passing，把真实的 FT-11 缺口盖住——那比不写更糟。真实触发行为
归 FT-11 第 3 项，由 tests/cross_platform/records/ 下的人工实测记录负责。

**它守的是可机器化的那一半**：用户在 Skill 列表里只看得到 description，
description 没覆盖到的能力等于没有，没排除掉的相邻领域等于会误触发。以及——
边界声明里指向的每个「该归谁」，都必须有真实去处。

依据 PRD FT-03、§10.1「触发 / 非触发 / 冲突测试」。
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import pytest
import yaml

REPO = Path(__file__).resolve().parents[2]
SKILLS_DIR = REPO / "skills"
PRD = REPO / "docs" / "prd" / "Finance-Copilot-Skills-PRD-v0.2.md"
CORPUS_PATH = Path(__file__).parent / "corpus.yaml"

FRONTMATTER = re.compile(r"\A---\n(?P<body>.*?)\n---\n", re.DOTALL)
SKILL_NAME = re.compile(r"fcs-[a-z]+")
NOT_A_SKILL = "不做"


def _skill_dirs() -> list[Path]:
    return sorted(p for p in SKILLS_DIR.iterdir() if p.is_dir() and (p / "SKILL.md").exists())


def _frontmatter(skill: Path) -> dict[str, Any]:
    text = (skill / "SKILL.md").read_text(encoding="utf-8")
    match = FRONTMATTER.match(text)
    assert match, f"{skill.name} 的 SKILL.md 缺 YAML frontmatter"
    data = yaml.safe_load(match.group("body"))
    assert isinstance(data, dict), f"{skill.name} 的 frontmatter 不是映射"
    return data


def _description(skill: Path) -> str:
    """description 去掉全部空白后返回。

    YAML 的 `>-` 折叠块会把换行变成空格，重排换行不该让守卫误报——
    边界关键词都是中文词，不含空白，去掉空白后匹配更稳。
    """
    description = _frontmatter(skill)["description"]
    assert isinstance(description, str), f"{skill.name} 的 description 不是字符串"
    return re.sub(r"\s+", "", description)


def _corpus() -> dict[str, Any]:
    data = yaml.safe_load(CORPUS_PATH.read_text(encoding="utf-8"))
    assert isinstance(data, dict), "corpus.yaml 根节点必须是映射"
    return data


def _known_skill_names() -> set[str]:
    """已存在的 Skill + PRD §8.2 规划中的候选。

    从 PRD 正文提取而非硬编码：PRD 新增候选时守卫自动认，不必同步改测试。
    """
    return {p.name for p in _skill_dirs()} | set(SKILL_NAME.findall(PRD.read_text(encoding="utf-8")))


SKILLS = _skill_dirs()
CORPUS = _corpus()


def _section(skill: Path) -> dict[str, Any]:
    """取该 Skill 的语料节。

    缺节时给可读断言而不是 KeyError——守卫红了以后，人先看到的是失败信息，
    一串 KeyError 堆栈会让「补 corpus.yaml」这个动作变得不明显。
    """
    section = CORPUS.get(skill.name)
    assert section is not None, (
        f"{skill.name} 在 tests/triggering/corpus.yaml 里没有对应节，先补上再看其余断言"
    )
    assert isinstance(section, dict), f"{skill.name} 的语料节必须是映射"
    return section


def test_skills_dir_is_not_empty() -> None:
    # 后面按 skill 参数化的用例都依赖这一点；空目录会让它们静默全部跳过
    assert SKILLS, "skills/ 下没有找到任何含 SKILL.md 的目录"


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_every_skill_has_corpus(skill: Path) -> None:
    """新增 Skill 不写触发语料就红——边界必须随能力一起交付，不能事后补。"""
    assert skill.name in CORPUS, (
        f"{skill.name} 在 tests/triggering/corpus.yaml 里没有对应节。"
        f"新增 Skill 必须同时声明应触发 / 不应触发语料与边界关键词（FT-03）"
    )


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_corpus_sections_are_not_empty(skill: Path) -> None:
    """语料写空等于没写。三段都必须有内容。"""
    section = _section(skill)
    assert section.get("should_trigger"), f"{skill.name}：should_trigger 为空"
    assert section.get("should_not_trigger"), f"{skill.name}：should_not_trigger 为空"
    keywords = section.get("boundary_keywords") or {}
    assert keywords.get("must_contain"), f"{skill.name}：boundary_keywords.must_contain 为空"
    assert keywords.get("must_exclude_scope"), f"{skill.name}：must_exclude_scope 为空"


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_description_covers_claimed_scope(skill: Path) -> None:
    """description 必须覆盖声称支持的能力与安全承诺。

    用户在宿主的 Skill 列表里只看得到这一段。能力没写进去，宿主就不会在该场景下
    选中它；安全承诺（本地隔离/禁网）没写进去，用户就无从知道数据不出本机。
    """
    description = _description(skill)
    for keyword in _section(skill)["boundary_keywords"]["must_contain"]:
        assert keyword in description, (
            f"{skill.name} 的 description 缺关键词「{keyword}」，"
            f"该能力或承诺在 Skill 列表里不可见"
        )


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_description_excludes_adjacent_scope(skill: Path) -> None:
    """description 必须明确排除相邻领域，否则会抢走隔壁 Skill 的任务。

    只在 description 里找，不接受"正文里写了"——宿主路由时读的是 description。
    """
    description = _description(skill)
    for keyword in _section(skill)["boundary_keywords"]["must_exclude_scope"]:
        assert keyword in description, (
            f"{skill.name} 的 description 未排除「{keyword}」；"
            f"排除声明写在正文里不算，宿主路由读的是 description"
        )


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_negative_cases_have_a_real_destination(skill: Path) -> None:
    """每条「不该我做」都要说得出该归谁，且那个去处必须真实存在。

    防的是把边界写成一句无处可去的空话——「这个不归我管」而说不出归谁管，
    等于没有划边界，用户的任务会掉在地上。
    """
    known = _known_skill_names()
    for case in _section(skill)["should_not_trigger"]:
        text, destination = case["text"], case["belongs_to"]
        if destination.startswith(NOT_A_SKILL):
            assert "PRD" in destination, (
                f"{skill.name}：「{text}」标为不做，但没写 PRD 依据。"
                f"格式应为「不做（PRD §X.Y ……）」"
            )
        else:
            assert destination in known, (
                f"{skill.name}：「{text}」的去处 {destination} 既不是已有 Skill，"
                f"也不在 PRD §8.2 的候选清单里"
            )
        assert destination != skill.name, (
            f"{skill.name}：「{text}」被标为不该触发，去处却指回自己"
        )


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_positive_and_negative_corpora_do_not_overlap(skill: Path) -> None:
    """同一句话不能既应触发又不应触发。

    单 Skill 阶段这是笔误检测；多 Skill 后它会长成真正的冲突测试
    （PRD §10.1「相邻 Skill 冲突」）——见 test_no_cross_skill_trigger_conflict。
    """
    section = _section(skill)
    positives = set(section["should_trigger"])
    negatives = {case["text"] for case in section["should_not_trigger"]}
    overlap = positives & negatives
    assert not overlap, f"{skill.name}：以下语料同时出现在应触发与不应触发中：{sorted(overlap)}"


def test_no_cross_skill_trigger_conflict() -> None:
    """一句话不得是 A 的应触发、同时又是 B 的应触发（PRD §10.1 冲突测试）。

    单 Skill 时恒过，第 2 个 Skill 落地后自动开始起作用——这正是 PRD §10.3
    风险表「Skill 功能重叠」要防的东西，届时不必新写测试。
    """
    owners: dict[str, list[str]] = {}
    for skill_name, section in CORPUS.items():
        for text in section["should_trigger"]:
            owners.setdefault(text, []).append(skill_name)
    conflicts = {text: names for text, names in owners.items() if len(names) > 1}
    assert not conflicts, f"以下语料被多个 Skill 声称应触发：{conflicts}"


def test_corpus_has_no_orphan_sections() -> None:
    """corpus.yaml 里不得有对应 Skill 已删除的残留节。"""
    orphans = set(CORPUS) - {p.name for p in SKILLS}
    assert not orphans, f"corpus.yaml 中这些节没有对应的 Skill 目录：{sorted(orphans)}"
