# tests/ —— 工具集级测试

**跨 Skill、工具集层面**的测试。单个 Skill 的内部测试在各自 `skills/<skill>/tests/`。

| 目录 | 用途（对应 PRD） | 当前用例 |
|---|---|---|
| `triggering/` | 触发 / 非触发 / 相邻 Skill 冲突测试（FT-03、§10.1） | `corpus.yaml` + `test_trigger_boundary.py` |
| `cross_platform/` | 平台发现、手动/自动调用、文件访问、权限、网络限制、输出、错误处理矩阵（FT-11） | `test_install_paths.py` + `records/`（各平台验证记录） |
| `supply_chain/` | 依赖锁定、依赖哈希、发布包签名与哈希验证、版本一致性与回滚（§7.2、§10.1） | `test_version_consistency.py`、`test_requirements_hashes.py` |

## 已落地的守卫

它们防的问题**在使用侧几乎不可发现**，所以必须机器化——版本号漂移只体现在审计证据里，
安装路径写错的症状是"技能一个都不出现且无报错"，依赖清单过期时版本号看起来还是对的。

- **`supply_chain/test_version_consistency.py`** —— 断言 `pyproject.toml`、各
  `SKILL_META.yaml`、`scripts/version.py`、`SKILL.md` 与两份 CHANGELOG 的版本号完全一致。
  运行清单（FT-08）把 `skill_version` 写进审计证据，版本号漂移会让 NFR-04 可审计性与
  NFR-05 可重复性失真。规则见 [docs/governance/versioning.md](../docs/governance/versioning.md) §4。
- **`cross_platform/test_install_paths.py`** —— 断言 README 的安装提示词与
  [安装矩阵](../docs/governance/agent-install.md)路径表一致、每家代理都有一段自身完整
  可整段复制的提示词、提示词之间不串路径、提示词点名了 `skills/` 下的每个 Skill。
  安装路径写错的症状是技能一个都不出现且无任何报错。

  **`platforms.verified` 的守卫在 0.3.0 由「一律为空」改为「凭记录放行」**
  （`test_verified_platforms_have_records`）：填进 `verified` 的每个平台，
  `records/` 下必须有对应记录，且记录必须自陈验证等级。意图没变——不许无据自称已验证。
  ⚠ **机器只能检查记录存在与等级已填，检查不了记录说得实不实**，那部分靠人。
  与之配套的 `test_readme_does_not_overclaim_verification` 在 `verified` 非空后额外
  要求 README 分档表述，禁止"三家均为…"这类整体性说法。

- **`supply_chain/test_requirements_hashes.py`** —— 断言各 Skill 的 `requirements.txt`
  每个依赖都带 `--hash=sha256:`，且**重新导出后与文件一致**。后一条才是真正的漂移守卫：
  改了 `uv.lock` 忘了重新导出时，旧哈希同样是"有"的。带哈希的清单配合
  `pip install --require-hashes` 才能拒绝被篡改的分发包——只锁版本号防不了
  "同一版本号的内容被换掉"（PRD §7.2）。

- **`triggering/test_trigger_boundary.py`** —— 断言 `SKILL.md` 的 `description` 覆盖了
  `corpus.yaml` 声称支持的能力与安全承诺、明确排除了相邻领域，且每条"不该我做"都指向
  真实存在的去处（已有 Skill 或 PRD §8.2 候选，否则须写明 PRD 依据）。

  ⚠ **它验证不了"用户说这句话时宿主是否真的唤起了该 Skill"**——那是宿主的路由行为，
  pytest 观测不到，归 FT-11 第 3 项的人工实测。`corpus.yaml` 里的语料同时就是那次
  实测的脚本，两边共用一份，不各写一套。**不要**为了让这里"覆盖得更全"而加一个模拟
  宿主路由的关键词匹配测试：那会让 `tests.triggering` 显示 passing 并盖住真实缺口。
