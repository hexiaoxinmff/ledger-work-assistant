"""安装路径漂移守卫：README 的安装提示词与安装矩阵路径表必须一致。

依据 docs/governance/agent-install.md——该文件的路径表是唯一事实源，README 由它派生。
装错位置的表现是技能一个都不出现、且没有任何报错（矩阵 §6），所以路径写错在使用侧
几乎不可发现；两处各写一份就必须有机器守卫。
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest
import yaml

REPO = Path(__file__).resolve().parents[2]
README = REPO / "README.md"
MATRIX = REPO / "docs" / "governance" / "agent-install.md"
SKILLS_DIR = REPO / "skills"
RECORDS = Path(__file__).resolve().parent / "records"

# 事实源：矩阵 §2 路径表。键为代理在 README 里的展示名，值为 (用户级, 项目级)。
AGENTS: dict[str, tuple[str, str]] = {
    "Claude Code": ("~/.claude/skills/", ".claude/skills/"),
    "Codex": ("~/.codex/skills/", ".codex/skills/"),
    "WorkBuddy": ("~/.workbuddy/skills/", ".codebuddy/skills/"),
}

# README 里每段安装提示词的围栏代码块
FENCED_BLOCKS = re.compile(r"```text\n(.*?)```", re.DOTALL)


def _readme() -> str:
    return README.read_text(encoding="utf-8")


def _matrix() -> str:
    return MATRIX.read_text(encoding="utf-8")


def _install_blocks() -> list[str]:
    return FENCED_BLOCKS.findall(_readme())


def _skill_dirs() -> list[Path]:
    return sorted(p for p in SKILLS_DIR.iterdir() if p.is_dir() and (p / "SKILL.md").exists())


def _compatible(skill: Path) -> list[str]:
    meta = yaml.safe_load((skill / "SKILL_META.yaml").read_text(encoding="utf-8"))
    platforms = meta["platforms"]["compatible"] or []
    assert isinstance(platforms, list)
    return platforms


def _installable_skill_names() -> list[str]:
    """对外可安装的 Skill = `platforms.compatible` 非空的。

    判据是「有没有声称可以在某个代理上安装」，不是发布状态——`fcs-reconcile` 至今是
    Experimental 却已对外安装，PRD §10.2 的 Experimental 只意味着"不承诺稳定"，
    并不等于不可安装，两者是正交的。

    这条判据让**新 Skill 在成型前不必回改两份 README**（`compatible: []` 即可），
    而那是新增 Skill 最重的一处连带修改。想对外发布时把 compatible 填上，守卫立刻
    开始要求它进提示词——由一个字段同时驱动两个方向，不会出现"声称可装却没写进
    安装说明"或"写进说明却没声称支持"的错配。
    """
    return sorted(p.name for p in _skill_dirs() if _compatible(p))


@pytest.mark.parametrize(("agent", "paths"), AGENTS.items())
def test_matrix_lists_both_scopes(agent: str, paths: tuple[str, str]) -> None:
    """矩阵 §2 路径表里每家代理的用户级与项目级目录都在。"""
    text = _matrix()
    user, project = paths
    assert agent in text, f"安装矩阵缺少代理 {agent}"
    assert user in text, f"安装矩阵缺少 {agent} 的用户级路径 {user}"
    assert project in text, f"安装矩阵缺少 {agent} 的项目级路径 {project}"


@pytest.mark.parametrize(("agent", "paths"), AGENTS.items())
def test_readme_has_a_self_contained_prompt_per_agent(agent: str, paths: tuple[str, str]) -> None:
    """每家代理都有一段**自身完整**的提示词块——用户整段复制即可，不需要手改路径。

    这是"统一走提示词"的核心可用性要求：面向的是财务人员，让他们照着说明替换路径
    等于把安装失败的责任推给使用者，而路径写错没有任何报错（矩阵 §6）。
    """
    user_path = paths[0]
    blocks = [b for b in _install_blocks() if user_path in b]
    assert blocks, f"README 里没有任何提示词块用到 {agent} 的用户级路径 {user_path}"
    # 该块必须自成一体：克隆源、目标目录、装依赖、清理临时目录都在同一块里
    for block in blocks:
        assert "github.com" in block, f"{agent} 的提示词块缺少仓库地址"
        assert "requirements.txt" in block, f"{agent} 的提示词块缺少装依赖步骤"
        assert "临时目录" in block, f"{agent} 的提示词块缺少临时目录的创建/清理说明"


@pytest.mark.parametrize(("agent", "paths"), AGENTS.items())
def test_prompt_does_not_leak_another_agents_path(agent: str, paths: tuple[str, str]) -> None:
    """一段提示词里不得混入别家代理的用户级路径——复制过去会装到错误位置。"""
    user_path = paths[0]
    others = [p[0] for name, p in AGENTS.items() if name != agent]
    for block in (b for b in _install_blocks() if user_path in b):
        intruders = [o for o in others if o in block]
        assert not intruders, f"{agent} 的提示词块混入了别家路径 {intruders}"


def test_prompts_cover_every_installable_skill() -> None:
    """提示词里点名的 skill 数量与**可安装**的数量一致。

    漏掉一个 skill 的表现同样是"安静地少一个技能"，所以在可安装 skill 增减时必须回改
    README。Experimental 的不算可安装，理由见 _installable_skill_names。
    """
    names = _installable_skill_names()
    for block in _install_blocks():
        for name in names:
            assert name in block, f"提示词块未点名 skill `{name}`"
        assert f"当前 {len(names)} 个" in block, (
            f"提示词块里的 skill 数量与实际不符，应为「当前 {len(names)} 个」"
        )


def test_unlisted_skills_are_not_advertised() -> None:
    """反向守卫：`compatible` 为空的 skill **不得**出现在安装提示词里。

    上一条放宽后必须有这一条兜住另一头，否则"豁免"会变成"随便"：一个还没成型、
    tests 全 pending 的 Skill 悄悄进了安装说明，财务人员照着装上就会拿真实数据跑它。

    两条合起来的效果是：`platforms.compatible` 与 README 提示词**必须同增同减**。
    """
    unlisted = [p.name for p in _skill_dirs() if not _compatible(p)]
    for block in _install_blocks():
        for name in unlisted:
            assert name not in block, (
                f"skill `{name}` 的 platforms.compatible 为空却出现在安装提示词里；"
                f"要对外发布请先在 SKILL_META.yaml 填 compatible"
            )


def test_readme_does_not_overclaim_verification() -> None:
    """README 的支持级别措辞必须与 `platforms.verified` 的实际内容一致（PRD FT-11）。

    WorkBuddy 仍是格式兼容，所以「格式兼容」一词必须还在；但一旦有平台进了 verified，
    就不能再用"三家都只是格式兼容"这类**整体性**表述——那会把已验证的说少、
    也把未验证的说混。两档必须在 README 里分开写。
    """
    text = _readme()
    assert "格式兼容" in text, "README 未声明支持级别为「格式兼容」"
    assert "docs/governance/agent-install.md" in text, "README 未链接到安装矩阵"

    if _any_verified():
        stale = [s for s in ("三家都只是", "三家均为", "三家都是") if s in text]
        assert not stale, (
            f"README 仍在用整体性表述 {stale} 说三家支持级别相同，但 platforms.verified "
            f"已非空；须按「已验证 / 格式兼容」两档分开表述"
        )
        assert "使用验证" in text, (
            "README 未说明已验证平台的验证等级。verified 里的平台是「使用验证」而非"
            "「逐项走查」，级别差异必须对用户可见（见 tests/cross_platform/records/README.md）"
        )


def _any_verified() -> bool:
    return any(
        yaml.safe_load((s / "SKILL_META.yaml").read_text(encoding="utf-8"))["platforms"]["verified"]
        for s in SKILLS_DIR.iterdir()
        if (s / "SKILL_META.yaml").exists()
    )


def test_verified_platforms_have_records() -> None:
    """每个填进 platforms.verified 的平台，本目录下必须有对应验证记录（PRD FT-11）。

    守卫的意图与改写前一致——**不许无据自称已验证**——只是从"一律禁止"升级为
    "凭证据放行"。改写发生在 0.3.0：Claude Code 与 Codex 依据开发者多项目实际使用
    填入 verified，记录落 `records/<平台>-<版本>.md`。

    ⚠ 本用例只能检查记录**存在**，检查不了记录**说了什么**。记录里的验证等级
    （逐项走查 / 使用验证）由人负责如实填写，规则见 `records/README.md`。
    机器守卫防的是"填了平台却一个字都没写"，防不了"写得不实"。
    """
    for skill in sorted(p for p in SKILLS_DIR.iterdir() if (p / "SKILL_META.yaml").exists()):
        meta = yaml.safe_load((skill / "SKILL_META.yaml").read_text(encoding="utf-8"))
        platforms = meta["platforms"]
        for platform in platforms["verified"] or []:
            records = sorted(RECORDS.glob(f"{platform}-*.md"))
            assert records, (
                f"{skill.name} 的 platforms.verified 含 `{platform}`，但 "
                f"tests/cross_platform/records/ 下没有 `{platform}-*.md` 记录；"
                f"要么补记录，要么把它从 verified 移回 compatible"
            )
        # compatible 为空 = 尚未对外安装（新 Skill 的默认态），此时不作要求；
        # 一旦非空，就必须恰好是 README 提供提示词的三家——只声称其中一两家的话，
        # 用户按另一段提示词装完会得到一个"没声称支持"的 skill。
        # 注意：已进 verified 的平台仍留在 compatible，两者不是互斥关系——
        # compatible 回答"能不能装"，verified 回答"验没验过"。
        compatible = platforms["compatible"] or []
        if compatible:
            assert set(compatible) == {"claude-code", "codex", "workbuddy"}, (
                f"{skill.name} 的 platforms.compatible 与 README 提供安装提示词的代理不一致"
            )


def test_verification_records_declare_their_level() -> None:
    """每份记录必须自陈验证等级——否则读者无从判断这份「已验证」有多硬。

    这条不检查等级填得对不对（机器判断不了），只检查**填了**。空着的记录会被
    默认读成"9 项都过了"，那是最坏的一种默认。
    """
    for record in sorted(RECORDS.glob("*.md")):
        if record.name == "README.md":
            continue
        text = record.read_text(encoding="utf-8")
        assert "验证等级" in text, f"{record.name} 未写明验证等级"
        levels = [lv for lv in ("逐项走查", "使用验证") if lv in text]
        assert levels, (
            f"{record.name} 的验证等级不是 records/README.md 定义的任一档"
            f"（逐项走查 / 使用验证）"
        )
