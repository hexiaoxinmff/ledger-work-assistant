"""版本漂移守卫：断言四处版本号事实源完全一致。

依据 docs/governance/versioning.md §4。运行清单（FT-08）把 skill_version 写进审计证据，
版本号漂移会直接让 NFR-04 可审计性与 NFR-05 可重复性失真——所以这是机器守卫，不是文档约定。
"""
from __future__ import annotations

import importlib.util
import re
import tomllib
from pathlib import Path

import pytest
import yaml

REPO = Path(__file__).resolve().parents[2]
SKILLS_DIR = REPO / "skills"
SEMVER = re.compile(r"^\d+\.\d+\.\d+$")
# Keep a Changelog 版本标题：## [0.2.0] — 2026-08-04
CHANGELOG_HEADING = re.compile(r"^##\s*\[(?P<version>[^\]]+)\]", re.MULTILINE)


def _skill_dirs() -> list[Path]:
    return sorted(p for p in SKILLS_DIR.iterdir() if p.is_dir() and (p / "SKILL.md").exists())


def _toolkit_version() -> str:
    with open(REPO / "pyproject.toml", "rb") as fh:
        data = tomllib.load(fh)
    version = data["project"]["version"]
    assert isinstance(version, str)
    return version


def _changelog_versions(path: Path) -> list[str]:
    return CHANGELOG_HEADING.findall(path.read_text(encoding="utf-8"))


def _skill_meta(skill: Path) -> dict[str, object]:
    raw = yaml.safe_load((skill / "SKILL_META.yaml").read_text(encoding="utf-8"))
    assert isinstance(raw, dict)
    return raw


def _skill_version(skill: Path) -> str:
    version = _skill_meta(skill)["skill_version"]
    assert isinstance(version, str)
    return version


SKILLS = _skill_dirs()


def test_skills_dir_is_not_empty() -> None:
    # 后面所有按 skill 参数化的用例都依赖这一点；空目录会让它们静默全部跳过。
    assert SKILLS, "skills/ 下没有找到任何含 SKILL.md 的目录"


def test_toolkit_version_is_semver() -> None:
    assert SEMVER.match(_toolkit_version()), f"工具集版本须形如 X.Y.Z：{_toolkit_version()}"


def test_toolkit_version_matches_root_changelog() -> None:
    """versioning.md §4-1：pyproject.toml 版本 == 根 CHANGELOG 最新条目。"""
    versions = _changelog_versions(REPO / "CHANGELOG.md")
    assert versions, "根 CHANGELOG.md 里没有任何 `## [版本]` 条目"
    assert versions[0] == _toolkit_version()


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_skill_version_matches_its_changelog(skill: Path) -> None:
    """versioning.md §4-2：SKILL_META.yaml == 该 Skill CHANGELOG 最新条目。"""
    versions = _changelog_versions(skill / "CHANGELOG.md")
    assert versions, f"{skill.name}/CHANGELOG.md 里没有任何 `## [版本]` 条目"
    assert versions[0] == _skill_version(skill)


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_skill_version_matches_scripts_version_module(skill: Path) -> None:
    """versioning.md §4-2：运行期版本号（scripts/version.py）== SKILL_META.yaml。

    运行清单里的 skill_version 取自 scripts/version.py；它与元数据分叉，
    落盘的审计证据就会指向一个不存在的发布版本。
    """
    version_py = skill / "scripts" / "version.py"
    if not version_py.exists():
        pytest.skip(f"{skill.name} 无 scripts/version.py")
    # 平铺模块（不包化，见项目结构设计 D4）。按文件路径以唯一模块名加载，不走
    # `sys.path` + `import version`——多个 Skill 各有一份 scripts/version.py 时，
    # 后者会命中 sys.modules 里第一个被导入的那份，静默比对到别的 Skill 的版本号。
    spec = importlib.util.spec_from_file_location(f"_fcs_version_{skill.name}", version_py)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert _skill_version(skill) == module.SKILL_VERSION


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_skill_md_mentions_current_version(skill: Path) -> None:
    """versioning.md §4-3：SKILL.md 正文提到的版本号与 skill_version 一致。

    SKILL.md 是 AI 与用户都会读到的门面；停在旧版本号会让人以为装到的是旧版。
    """
    text = (skill / "SKILL.md").read_text(encoding="utf-8")
    mentioned = set(re.findall(r"v(\d+\.\d+\.\d+)", text))
    current = _skill_version(skill)
    stale = mentioned - {current}
    assert not stale, f"{skill.name}/SKILL.md 提到了非当前版本 {sorted(stale)}（当前 {current}）"


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_skill_versions_are_semver(skill: Path) -> None:
    assert SEMVER.match(_skill_version(skill)), f"{skill.name} skill_version 须形如 X.Y.Z"


def test_no_unreleased_placeholder_left() -> None:
    """versioning.md §4-4：发布后不得残留 `[未发布]` 占位。"""
    changelogs = [REPO / "CHANGELOG.md"] + [s / "CHANGELOG.md" for s in SKILLS]
    # _changelog_versions 取的是 `## [...]` 方括号内的内容，故这里比对 "未发布" 本身。
    leftover = [
        c.relative_to(REPO).as_posix() for c in changelogs if "未发布" in _changelog_versions(c)
    ]
    assert not leftover, f"以下 CHANGELOG 仍有 [未发布] 占位条目：{leftover}"


def test_single_skill_stage_versions_are_aligned() -> None:
    """versioning.md §3.2：单 Skill 阶段 skill_version 与工具集版本对齐。

    ⚠ 第 2 个 Skill 落地后按 versioning.md §3.2 删除本用例——那时各 skill_version
    独立演进（FT-02），强行对齐反而违背"一个 Skill 的改动不迫使另一个改版本号"。
    """
    if len(SKILLS) != 1:
        pytest.skip(f"已有 {len(SKILLS)} 个 Skill，进入解耦阶段，本断言按 §3.2 应删除")
    assert _skill_version(SKILLS[0]) == _toolkit_version()
