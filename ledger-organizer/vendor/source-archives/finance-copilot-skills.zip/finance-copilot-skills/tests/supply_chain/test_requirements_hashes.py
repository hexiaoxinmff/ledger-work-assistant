"""依赖哈希守卫：断言各 Skill 的 requirements.txt 带哈希，且与 uv.lock 未漂移。

依据 PRD §7.2 软件供应链「固定依赖版本 + 依赖哈希」。带 `--hash` 的清单配合
`pip install --require-hashes` 才能拒绝被篡改的分发包——没有哈希时，锁定版本号只能
防"装错版本"，防不了"同一个版本号的内容被换掉"。

守的是**漂移**：改了 uv.lock 却忘了重新导出。这类问题在使用侧不可发现——用户装到的
是一份过期清单，版本号看起来还是对的。与版本号漂移守卫同类，所以同样必须机器化。

requirements.txt 是 `uv export` 的**纯生成物**（文件头注释里就是可复现的完整命令），
不手工编辑；重新导出的命令见 tools/build/README.md。
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
SKILLS_DIR = REPO / "skills"

EXPORT_ARGS = ["--frozen", "--no-dev", "--no-emit-project", "--format", "requirements-txt"]


def _skill_dirs() -> list[Path]:
    return sorted(p for p in SKILLS_DIR.iterdir() if p.is_dir() and (p / "SKILL.md").exists())


def _strip_comments(text: str) -> list[str]:
    """剥离注释与空行，只留实质内容。

    注释里含导出命令与 `# via xxx` 溯源行，会随导出方式变化而不同，
    但它们不影响装出来的东西——比对实质内容即可。
    """
    return [line.rstrip() for line in text.splitlines() if line.strip() and not line.strip().startswith("#")]


def _requirement_blocks(lines: list[str]) -> dict[str, list[str]]:
    """把剥离注释后的清单切成 {依赖声明: [该依赖的 --hash 行]}。

    uv 导出的形态是一行依赖声明（可带环境标记）后跟若干缩进的 --hash 行：

        numpy==2.4.6 ; python_full_version < '3.12' \\
            --hash=sha256:001f... \\
            --hash=sha256:0280...
    """
    blocks: dict[str, list[str]] = {}
    current: str | None = None
    for line in lines:
        stripped = line.strip().removesuffix("\\").strip()
        if line.startswith((" ", "\t")):
            if current is not None:
                blocks[current].append(stripped)
        else:
            current = stripped
            blocks[current] = []
    return blocks


SKILLS = _skill_dirs()


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_requirements_file_exists(skill: Path) -> None:
    req = skill / "requirements.txt"
    assert req.exists(), f"{skill.name} 缺 requirements.txt；离线安装与哈希校验都依赖它"


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_every_requirement_is_hash_pinned(skill: Path) -> None:
    """每个依赖都必须带 sha256 哈希，一个都不能漏。

    漏一个的后果不是"少一层保护"，而是 `pip install --require-hashes` 直接拒绝整份
    清单——pip 要求全有或全无。
    """
    blocks = _requirement_blocks(_strip_comments((skill / "requirements.txt").read_text("utf-8")))
    assert blocks, f"{skill.name} 的 requirements.txt 没有任何依赖行"
    for requirement, hashes in blocks.items():
        assert hashes, f"{skill.name}：依赖 {requirement} 没有 --hash 行"
        for h in hashes:
            assert h.startswith("--hash=sha256:"), (
                f"{skill.name}：依赖 {requirement} 的哈希行格式非法：{h}"
            )


@pytest.mark.parametrize("skill", SKILLS, ids=lambda p: p.name)
def test_requirements_match_lockfile(skill: Path) -> None:
    """重新导出的内容必须与文件一致——这一条才是真正的漂移守卫。

    上一条只保证"有哈希"，改了 uv.lock 忘了重导出时，旧哈希同样是"有"的。
    """
    if shutil.which("uv") is None:
        pytest.skip("环境中没有 uv，跳过与 uv.lock 的比对")

    result = subprocess.run(
        ["uv", "export", *EXPORT_ARGS],
        cwd=REPO,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, f"uv export 失败：{result.stderr.strip()}"

    expected = _strip_comments(result.stdout)
    actual = _strip_comments((skill / "requirements.txt").read_text("utf-8"))
    assert actual == expected, (
        f"{skill.name} 的 requirements.txt 与 uv.lock 不一致（漂移）。重新导出：\n"
        f"  uv export {' '.join(EXPORT_ARGS)} -o skills/{skill.name}/requirements.txt"
    )
