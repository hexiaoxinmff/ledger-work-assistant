"""安全基线的 5 项校验（PRD §9 硬目标）。

**与 Skill 自身 tests/security/ 的分工**：那边是白盒单元级，直接 import `guard`、
`integrity` 断言函数行为；这里是黑盒工具集级，只看外部可观测的证据——子进程有没有
出站连接、输出里有没有明细、源文件哈希变没变、清单字段齐不齐。两边都需要：白盒能
定位到具体函数，黑盒能发现"函数都对但连起来漏了"。
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from cases import REPO, BaselineCase

Status = Literal["pass", "fail", "skip"]

PROBE = Path(__file__).resolve().parent / "net_probe.py"

# FT-08 要求运行清单必备的字段
MANIFEST_REQUIRED = {
    "skill", "skill_version", "rule_version", "contract_version", "run_id", "run_at",
    "inputs", "outputs", "field_mapping", "config", "permissions", "counts",
    "warnings", "errors",
}


@dataclass(frozen=True)
class CheckResult:
    name: str
    status: Status
    detail: str

    @property
    def ok(self) -> bool:
        return self.status != "fail"


@dataclass(frozen=True)
class RunArtifacts:
    """一次真实执行留下的全部外部可观测证据。"""

    probe: dict[str, Any]
    stdout: str
    stderr: str
    hashes_before: dict[str, str]
    hashes_after: dict[str, str]


def sha256_of(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def execute(case: BaselineCase, workdir: Path) -> RunArtifacts:
    """通过网络探针跑一次真实入口，只跑一次，五项校验共用其证据。"""
    before = {str(p): sha256_of(p) for p in case.input_paths}
    report_path = workdir / "net-probe.json"

    completed = subprocess.run(
        [sys.executable, str(PROBE), str(report_path), str(case.entry), *case.args],
        capture_output=True, text=True, cwd=str(REPO), check=False,
    )
    probe = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {
        "error": f"探针未产出报告；子进程 stderr：{completed.stderr.strip()[:400]}",
        "early_connects": [], "guard_installed": False, "guard_blocks": False, "exit_code": 1,
    }
    after = {str(p): sha256_of(p) for p in case.input_paths}
    return RunArtifacts(probe, completed.stdout, completed.stderr, before, after)


def check_execution_succeeded(case: BaselineCase, run: RunArtifacts) -> CheckResult:
    """0 号前置：执行本身得成功，否则后面四项的"通过"都没有意义。

    没有这一条，一个启动即崩的 Skill 会拿到满分——没连过网、没泄露过日志、
    没改过源文件，全都因为它什么都没做。
    """
    if run.probe.get("error"):
        return CheckResult("执行成功", "fail", f"入口抛异常：{run.probe['error']}")
    if run.probe.get("exit_code") not in (0, None):
        return CheckResult("执行成功", "fail", f"退出码非 0：{run.probe.get('exit_code')}")
    if not case.output_path.exists():
        return CheckResult("执行成功", "fail", f"未产出结果文件：{case.output_path.name}")
    return CheckResult("执行成功", "pass", "入口正常退出并产出结果文件")


def check_network_isolation(case: BaselineCase, run: RunArtifacts) -> CheckResult:
    """未授权网络请求 = 0（PRD §9）。判据见 net_probe.py 的模块说明。"""
    early = run.probe.get("early_connects") or []
    if early:
        return CheckResult(
            "网络隔离", "fail", f"网络隔离生效前发起了 {len(early)} 次连接：{early[:3]}"
        )
    if not run.probe.get("guard_installed"):
        return CheckResult(
            "网络隔离", "fail", "运行结束时 socket.connect 仍是探针函数，说明未安装网络隔离"
        )
    if not run.probe.get("guard_blocks"):
        exc = run.probe.get("guard_block_exc")
        return CheckResult(
            "网络隔离", "fail",
            f"网络隔离已安装但未真正拦截出站连接（探测异常：{exc or '无'}）——疑似空实现",
        )
    return CheckResult("网络隔离", "pass", "隔离前无出站；隔离已安装且实测拦截生效")


def _flatten_values(node: Any) -> set[str]:
    if isinstance(node, dict):
        return {v for item in node.values() for v in _flatten_values(item)}
    if isinstance(node, list):
        return {v for item in node for v in _flatten_values(item)}
    return {str(node)}


def check_log_leakage(case: BaselineCase, run: RunArtifacts) -> CheckResult:
    """日志敏感数据泄露 = 0（PRD §9）。

    对**编号与往来单位名**零容忍：它们是交易明细的标识，出现即泄露。

    对**单笔金额**做白名单豁免：合法的汇总值可能恰好等于某一笔的金额（本用例里
    左侧合计 50.00 就等于 A004 的单笔金额），硬禁止会把合规输出误报成泄露。
    白名单取自 stdout 里那份 summary——PRD §5.1 明确允许汇总上交控制平面。
    """
    haystack = run.stdout + "\n" + run.stderr

    hits = sorted(v for v in case.forbidden_identifiers if v and v in haystack)
    if hits:
        return CheckResult("日志泄露", "fail", f"输出中出现交易明细标识：{hits[:5]}")

    try:
        allowed = _flatten_values(json.loads(run.stdout.strip().splitlines()[-1]))
    except (ValueError, IndexError):
        allowed = set()      # 解析不出汇总就不豁免，从严

    amount_hits = sorted(
        v for v in case.single_amounts if v and v in haystack and v not in allowed
    )
    if amount_hits:
        return CheckResult("日志泄露", "fail", f"输出中出现非汇总的单笔金额：{amount_hits[:5]}")

    ids, amounts = len(case.forbidden_identifiers), len(case.single_amounts)
    return CheckResult("日志泄露", "pass", f"{ids} 个明细标识、{amounts} 个单笔金额均未泄露")


def check_source_integrity(case: BaselineCase, run: RunArtifacts) -> CheckResult:
    """源文件非预期修改 = 0（PRD §9、FT-06）。"""
    changed = [p for p, h in run.hashes_before.items() if run.hashes_after.get(p) != h]
    if changed:
        names = [Path(p).name for p in changed]
        return CheckResult("源文件完整性", "fail", f"运行前后哈希不一致：{names}")
    return CheckResult(
        "源文件完整性", "pass", f"{len(run.hashes_before)} 个输入文件运行前后 SHA-256 一致"
    )


def check_dependency_hashes(case: BaselineCase, run: RunArtifacts) -> CheckResult:
    """未锁定依赖 = 0（PRD §9、§7.2）。

    漏洞扫描（"高危依赖 = 0"的另一半）**本阶段未实现**，不在这里假装通过：
    漏洞库要联网拉取，会让 CI 结果随外部数据源变化而波动——今天绿明天红而代码一行
    没改，门禁很快就会被习惯性忽略。阶段 B 随 SBOM 一起定阻断策略。
    """
    requirements = REPO / "skills" / case.skill / "requirements.txt"
    if not requirements.exists():
        return CheckResult("依赖哈希", "fail", f"缺 {requirements.relative_to(REPO)}")

    unpinned: list[str] = []
    current: str | None = None
    has_hash = False
    for line in requirements.read_text(encoding="utf-8").splitlines():
        if not line.strip() or line.strip().startswith("#"):
            continue
        if line.startswith((" ", "\t")):
            has_hash = has_hash or line.strip().startswith("--hash=sha256:")
        else:
            if current and not has_hash:
                unpinned.append(current)
            current, has_hash = line.strip().removesuffix("\\").strip(), False
    if current and not has_hash:
        unpinned.append(current)

    if unpinned:
        return CheckResult("依赖哈希", "fail", f"未带哈希的依赖：{unpinned[:5]}")
    return CheckResult("依赖哈希", "pass", "全部依赖带 sha256（漏洞扫描未实现，见阶段 B）")


def check_manifest_completeness(case: BaselineCase, run: RunArtifacts) -> CheckResult:
    """运行清单完整率 = 100%，且不含交易明细（PRD §9、FT-08）。"""
    if not case.manifest_path.exists():
        return CheckResult("运行清单", "fail", f"未产出运行清单：{case.manifest_path.name}")

    raw = case.manifest_path.read_text(encoding="utf-8")
    manifest = json.loads(raw)

    missing = sorted(MANIFEST_REQUIRED - set(manifest))
    if missing:
        return CheckResult("运行清单", "fail", f"缺必备字段：{missing}")

    leaked = sorted(v for v in case.forbidden_identifiers if v and v in raw)
    if leaked:
        return CheckResult("运行清单", "fail", f"清单中含交易明细标识：{leaked[:5]}")

    return CheckResult(
        "运行清单", "pass", f"{len(MANIFEST_REQUIRED)} 个必备字段齐全，且不含交易明细"
    )


CHECKS = [
    check_execution_succeeded,
    check_network_isolation,
    check_log_leakage,
    check_source_integrity,
    check_dependency_hashes,
    check_manifest_completeness,
]
