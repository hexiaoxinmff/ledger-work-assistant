"""各 Skill 的安全基线用例：跑一次真实执行需要的输入、配置与敏感值清单。

**当前只注册了一个 Skill。** 这是有意的：PRD 的抽象准则是「公共能力经至少 2 个
Skill 验证后才抽象」（见 packages/README.md）。第 2 个 Skill 落地时，若两者形态
一致，再评估把 CASES 换成各 Skill 目录下的声明式配置——现在就设计通用契约，等于
凭一个样本猜通用形态。
"""
from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class BaselineCase:
    """一次可复现的真实运行，以及判定日志泄露所需的敏感值。"""

    skill: str
    entry: Path                      # 入口脚本（黑盒调用，不 import 其内部模块）
    args: list[str]                  # 传给入口的参数
    input_paths: list[Path]          # 运行前后要校验哈希的源文件
    output_path: Path
    manifest_path: Path
    # 交易明细标识：出现在任何输出里都是泄露，无例外
    forbidden_identifiers: set[str] = field(default_factory=set)
    # 单笔金额：只有在不等于任何合法汇总值时才算泄露（见 checks.check_log_leakage）
    single_amounts: set[str] = field(default_factory=set)


def _read_column(path: Path, column: str) -> list[str]:
    with path.open(encoding="utf-8") as fh:
        return [row[column].strip() for row in csv.DictReader(fh) if row.get(column)]


def fcs_reconcile_case(workdir: Path) -> BaselineCase:
    """用黄金答案的输入数据跑一次完整对账。

    用 tests/golden/inputs/ 而不是 examples/：前者是纯文本、进版本控制、内容稳定，
    敏感值可以直接从 CSV 逐列读出来，不必解析 xlsx。
    """
    skill_dir = REPO / "skills" / "fcs-reconcile"
    inputs = skill_dir / "tests" / "golden" / "inputs"
    left, right = inputs / "left.csv", inputs / "right.csv"
    output = workdir / "verify-result.xlsx"

    # 块状写法而非契约示例里的 flow 写法，纯粹是为了不超行宽；两者解析结果一致
    # （含 `no` 键——PyYAML 按 YAML 1.1 把它读成布尔 False，由 config.py 还原为字符串）
    config_path = workdir / "verify-config.yaml"
    config_path.write_text(
        f"""
left:
  file: "{left}"
  sheet: null
  header_row: 0
  fields: {{no: 单号, amount: 金额, date: 日期, counterparty: 对方, direction: 方向}}
right:
  file: "{right}"
  sheet: null
  header_row: 0
  fields: {{no: 流水号, amount: 发生额, date: 日期, counterparty: 户名, direction: 借贷}}
match:
  primary_key: no
  composite_keys: []
  amount_tolerance: "0.00"
  date_tolerance_days: 0
  direction_rule: signed
  amount_scale: 2
output:
  path: "{output}"
rule_version: "1.0"
contract_version: "1.0"
""",
        encoding="utf-8",
    )

    identifiers = set(
        _read_column(left, "单号")
        + _read_column(right, "流水号")
        + _read_column(left, "对方")
        + _read_column(right, "户名")
    )
    amounts = set(_read_column(left, "金额") + _read_column(right, "发生额"))

    return BaselineCase(
        skill="fcs-reconcile",
        entry=skill_dir / "scripts" / "reconcile.py",
        args=["--config", str(config_path), "--run-id", "verify",
              "--run-at", "2026-01-01T00:00:00"],
        input_paths=[left, right],
        output_path=output,
        manifest_path=Path(str(output) + ".manifest.json"),
        forbidden_identifiers=identifiers,
        single_amounts=amounts,
    )


CASES = {"fcs-reconcile": fcs_reconcile_case}
