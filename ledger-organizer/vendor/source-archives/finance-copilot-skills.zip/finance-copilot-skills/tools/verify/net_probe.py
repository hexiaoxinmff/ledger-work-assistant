"""网络探针：在目标脚本**之前**装好，观测它启动期间与结束之后的网络状态。

单纯「统计出站 connect 次数是否为 0」在这里行不通：Skill 一进来就
`guard.block_network()`，那句话会把探针自己替换掉，之后的计数永远是 0——
一个恒真的校验。

改为观测三件可证伪的事，写进报告交给 run.py 判定：

1. **early_connects** —— 从进程启动到 guard 装好之间有没有发起过连接。
   这段窗口是探针唯一还在位的时候，也是"偷偷联网"最可能发生的地方。
2. **guard_installed** —— 跑完之后 `socket.socket.connect` 是否已不是探针的函数。
   还是探针的，说明目标压根没装网络隔离。
3. **guard_blocks** —— 跑完之后主动发起一次连接，看是不是被拒。
   拒的异常若是 `OSError` 家族（如 ConnectionRefused），说明请求真的走到了系统调用，
   guard 是空实现；只有非 OSError（guard 自定义的拒绝异常）才算真拦住。

用法：`python net_probe.py <报告输出路径> <目标脚本> [目标参数...]`
"""
from __future__ import annotations

import json
import runpy
import socket
import sys
from pathlib import Path
from typing import Any

report_path = Path(sys.argv[1])
target = Path(sys.argv[2])
sys.argv = [str(target), *sys.argv[3:]]

# 目标是平铺模块 Skill 的入口脚本（`import config` 等依赖同目录在 sys.path 上）。
# runpy.run_path 不像直接运行脚本那样自动注入脚本目录，这里手工补。
sys.path.insert(0, str(target.parent))

_original_connect = socket.socket.connect
_early_connects: list[str] = []


def _recording_connect(self: socket.socket, address: Any) -> None:
    _early_connects.append(str(address))
    _original_connect(self, address)


socket.socket.connect = _recording_connect  # type: ignore[assignment]

report: dict[str, Any] = {"exit_code": 0, "error": None}
try:
    runpy.run_path(str(target), run_name="__main__")
except SystemExit as exc:
    report["exit_code"] = exc.code if isinstance(exc.code, int) else 1
except BaseException as exc:  # noqa: BLE001 —— 目标任何失败都要如实记进报告
    report["error"] = f"{type(exc).__name__}: {exc}"
    report["exit_code"] = 1

report["early_connects"] = _early_connects
report["guard_installed"] = socket.socket.connect is not _recording_connect

if report["guard_installed"]:
    try:
        socket.socket().connect(("127.0.0.1", 9))
    except BaseException as exc:  # noqa: BLE001
        # OSError 家族 = 请求真的走到了系统调用，guard 没拦住，只是端口恰好不通
        report["guard_blocks"] = not isinstance(exc, OSError)
        report["guard_block_exc"] = type(exc).__name__
    else:
        report["guard_blocks"] = False
        report["guard_block_exc"] = None
else:
    report["guard_blocks"] = False
    report["guard_block_exc"] = None

report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
