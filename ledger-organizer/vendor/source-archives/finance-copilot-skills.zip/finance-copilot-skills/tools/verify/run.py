"""安全基线校验入口：任一项失败即非零退出，阻断发布（PRD §9）。

    uv run python tools/verify/run.py --skill fcs-reconcile
    uv run python tools/verify/run.py --all

失败信息只报"哪一项、为什么"，**不回显任何单元格内容**——一个会把敏感数据打进
CI 日志的安全校验器本身就是泄露源（FT-09）。
"""
from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:                     # 平铺模块，与 skills/*/scripts 同惯例
    sys.path.insert(0, str(_HERE))

from cases import CASES  # noqa: E402
from checks import CHECKS, CheckResult, execute  # noqa: E402

_MARK = {"pass": "✅", "fail": "❌", "skip": "⏭"}


def verify_skill(skill: str) -> list[CheckResult]:
    build_case = CASES.get(skill)
    if build_case is None:
        return [CheckResult("用例注册", "fail", f"{skill} 未在 tools/verify/cases.py 注册基线用例")]

    with tempfile.TemporaryDirectory() as tmp:
        workdir = Path(tmp)
        case = build_case(workdir)
        run = execute(case, workdir)
        return [check(case, run) for check in CHECKS]


def _print(skill: str, results: list[CheckResult]) -> None:
    print(f"\n=== {skill} ===")
    width = max(len(r.name) for r in results)
    for result in results:
        print(f"  {_MARK[result.status]} {result.name.ljust(width)}  {result.detail}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="fcs-verify", description="安全基线校验")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--skill", help="只校验指定 Skill")
    group.add_argument("--all", action="store_true", help="校验全部已注册 Skill")
    args = parser.parse_args(argv)

    targets = sorted(CASES) if args.all else [args.skill]
    failed = 0
    for skill in targets:
        results = verify_skill(skill)
        _print(skill, results)
        failed += sum(1 for r in results if not r.ok)

    total = sum(len(CHECKS) for _ in targets)
    if failed:
        print(f"\n❌ 安全基线未通过：{failed}/{total} 项失败。发布已阻断（PRD §9 硬目标）。")
        return 1
    print(f"\n✅ 安全基线通过：{total}/{total} 项。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
