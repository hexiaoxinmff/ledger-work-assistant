# tools/release —— 版本 / 哈希 / 签名 / SBOM / 发布状态

对 `dist/<skill>/` 自包含包执行发布加固，产出可信、可追溯的正式版本。

## 职责（对应 PRD §7.2 软件供应链）

- 计算发布包整体 **SHA-256**。
- 生成 **SBOM**（软件物料清单）。
- 对发布包**签名**。
- 打**发布状态**标签：`Experimental → Preview → Stable → Deprecated → Retired`
  （与各 Skill `SKILL_META.yaml` 的 `status` 字段一致，规范见 `docs/governance/`）。
- 记录版本信息：Skill / 规则 / 契约 / 依赖版本、支持平台、安全测试状态、已知限制、回滚版本。

## 前置门禁

发布前必须：自动化测试 100% 通过、`tools/verify` 安全基线通过、独立前向测试通过。
