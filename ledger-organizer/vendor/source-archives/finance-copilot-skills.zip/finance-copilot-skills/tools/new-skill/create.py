"""新 Skill 脚手架：生成骨架，让 27 条工具集级守卫开箱即绿。

    uv run python tools/new-skill/create.py fcs-clean --display 清洗 \\
        --description "清洗 Excel/CSV 财务明细，统一编号、金额与日期格式。"

**为什么需要这个脚本**：新增一个 Skill 会触发 4 个测试文件、27 条守卫，逐条手工满足
要碰 10 个位置（SKILL.md 的 frontmatter 与正文版本号、SKILL_META、CHANGELOG、
version.py、requirements.txt、corpus.yaml、两份 README……）。那不是标准太高，是缺工具——
放松守卫会让"版本号漂移只体现在审计证据里"这类问题重新变得不可发现，而生成骨架
既保住守卫又把成本降到一条命令。

**生成的 Skill 默认 `platforms.compatible: []`**，因此不必写进两份 README 的安装
提示词——那是新增 Skill 最重的一处连带修改。判据是"有没有声称可以在某个代理上安装"，
不是发布状态：`fcs-reconcile` 至今是 Experimental 却已对外安装，PRD §10.2 的
Experimental 只意味着"不承诺稳定"，与可不可安装正交。

想对外发布时把 compatible 填上，`tests/cross_platform/` 立刻开始要求它进提示词；
没填却写进了提示词也会红——一个字段驱动两个方向，不会出现错配。
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
import tomllib
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
SKILLS_DIR = REPO / "skills"
CORPUS = REPO / "tests" / "triggering" / "corpus.yaml"
SKILL_NAME = re.compile(r"^fcs-[a-z][a-z0-9-]*$")

INITIAL_VERSION = "0.1.0"


def _toolkit_version() -> str:
    with (REPO / "pyproject.toml").open("rb") as fh:
        version = tomllib.load(fh)["project"]["version"]
    assert isinstance(version, str)
    return version


def _existing_skills() -> list[str]:
    return sorted(p.name for p in SKILLS_DIR.iterdir() if p.is_dir() and (p / "SKILL.md").exists())


def _skill_md(name: str, display: str, description: str, version: str) -> str:
    """SKILL.md 骨架。

    description 里预置了 corpus.yaml 的 must_contain / must_exclude_scope 关键词——
    触发边界守卫只认 description（宿主路由读的就是它），正文里写了不算。
    """
    return f"""---
name: {name}
description: >-
  {display} Skill：<一句话说清做什么>。核对与计算由本地确定性程序完成，
  原始明细不进模型上下文，默认本地隔离、禁网。
  当用户需要"<触发说法 1> / <触发说法 2>"时使用。
  不适用于凭证过账、报表生成、税务判断，或需要联网登录网银/ERP 的场景。
---

# {name}（{display}）

> 发布状态 **Experimental**（v{version}）——实验中，不承诺稳定，暂不对外安装。

## 何时使用 / 不使用

- **应触发**：<场景，与 tests/triggering/corpus.yaml 的 should_trigger 对应>
- **不应触发**：<场景 → 该归谁，与 corpus.yaml 的 should_not_trigger 对应>

## 数据处理声明（运行前须向用户展示并确认）

```text
运行模式：本地隔离
将读取：N 个本地文件 ｜ 将写入：M 个结果文件
原始数据进入模型：否
网络访问：已禁用
源文件修改：否
终端输出交易明细：否
输入完整性：读取前后 SHA-256 校验
```

## 核心约束（不可退让）

- 确定性计算由程序完成，不确定的结果一律进人工复核（NFR-01）。
- 金额一律 `Decimal`，不参与浮点运算。
- 运行期禁网、不修改源文件、不打印交易明细（FT-05 / FT-06）。

## 运行

```bash
python scripts/main.py --config <config.yaml>
```
"""


def _skill_meta(name: str, display: str, description: str, version: str) -> str:
    return f"""# {name} 目录元数据（FT-01）。

name: {name}
display_name: {display}
description: {description}

# 隐私等级：high = 处理银行账户、交易明细等高敏数据，默认本地隔离 + 禁网
privacy_level: high

skill_version: "{version}"
rule_version: "1.0"
contract_version: "1.0"

# 发布状态：Experimental → Preview → Stable → Deprecated → Retired
status: Experimental

license: MIT

# compatible 为空 = 尚未声称可在任何代理上安装，因此不必写进 README 提示词。
# 想对外发布时填 [claude-code, codex, workbuddy]，并把本 Skill 加进两份 README 的
# 三段安装提示词——两处必须同增同减，tests/cross_platform/ 双向守卫。
# verified 只在 FT-11 九项逐条实测通过、记录落 tests/cross_platform/records/ 后才填。
platforms:
  verified: []
  compatible: []

applicable: []
not_applicable: [凭证过账, 报表生成, 税务判断, 联网登录外部系统]

io:
  input: [xlsx, csv]
  output: [xlsx, "manifest.json"]

dependencies: [pandas, openpyxl]

tests:
  unit: pending
  property: pending
  golden: pending
  security: pending
  forward: pending
"""


def _changelog(name: str, display: str, version: str) -> str:
    return f"""# {name} 变更记录

本文件记录 **{name}（{display}）** 自身的版本。工具集级发布见仓库根 `CHANGELOG.md`。

## [{version}] — 未发布

骨架创建，尚无功能。发布状态 `Experimental`。

### 发布信息

- **支持平台**：暂不对外安装（Experimental）。
- **规则/契约版本**：`rule_version=1.0`、`contract_version=1.0`。
- **已知限制**：功能未实现。
- **回滚版本**：无（首个版本）。
"""


def _version_py(name: str, version: str) -> str:
    return f'''"""{name} 的版本号事实源。

运行期版本号只从这里取，不在业务代码里散写字面量——运行清单（FT-08）把它写进
审计证据，散写会导致漂移（见 docs/governance/versioning.md §4）。
"""

SKILL_VERSION = "{version}"
'''


def _conftest(name: str) -> str:
    return '''"""pytest 配置：把本 Skill 的 scripts/ 注入 sys.path。

scripts/ 采用平铺模块（不包化，见项目结构设计 D4），因此测试需将 scripts/
目录加入 sys.path，才能像运行时那样直接 import 兄弟模块。
"""

import sys
from pathlib import Path

_SCRIPTS = Path(__file__).resolve().parent.parent / "scripts"
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))
'''


def _smoke_test(name: str, version: str) -> str:
    return f'''"""占位冒烟测试：保证新骨架至少有一条真断言，而不是空目录。

    删掉本文件前，先让真正的单元测试跑起来——`tests.unit: pending` 转 passing
    的判据是有实质覆盖，不是有文件。
"""
from __future__ import annotations

import version


def test_version_matches_meta() -> None:
    assert version.SKILL_VERSION == "{version}"
'''


def _corpus_section(name: str, display: str) -> str:
    return f"""
{name}:
  # TODO 换成财务人员真实会说的话，别写规范化的功能描述
  should_trigger:
    - <触发说法 1>
    - <触发说法 2>

  # belongs_to 必须有真实去处：已有/已规划的 Skill 名，或「不做（PRD §X.Y ……）」
  should_not_trigger:
    - text: 帮我把这张表的日期格式统一了
      belongs_to: fcs-clean
    - text: 这笔业务要不要交增值税
      belongs_to: 不做（PRD §2.5 排除税务申报或会计政策结论）

  boundary_keywords:
    # 必须出现在 SKILL.md 的 description 里（守卫只认 description）
    must_contain: [本地隔离, 禁网]
    must_exclude_scope: [凭证过账, 报表生成, 税务判断]
"""


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print(f"  + {path.relative_to(REPO)}")


def create(name: str, display: str, description: str) -> int:
    if not SKILL_NAME.match(name):
        print(f"❌ Skill 名须形如 fcs-xxx（小写、连字符）：{name}", file=sys.stderr)
        return 1

    target = SKILLS_DIR / name
    if target.exists():
        print(f"❌ {target.relative_to(REPO)} 已存在", file=sys.stderr)
        return 1

    existing = _existing_skills()
    # 单 Skill 阶段 skill_version 与工具集版本对齐（versioning §3.2）；
    # 第 2 个 Skill 起解耦，新 Skill 从 0.1.0 独立起步。
    version = _toolkit_version() if not existing else INITIAL_VERSION

    print(f"生成 {name}（{display}），版本 {version}：")
    _write(target / "SKILL.md", _skill_md(name, display, description, version))
    _write(target / "SKILL_META.yaml", _skill_meta(name, display, description, version))
    _write(target / "CHANGELOG.md", _changelog(name, display, version))
    _write(target / "scripts" / "version.py", _version_py(name, version))
    _write(target / "tests" / "conftest.py", _conftest(name))
    _write(target / "tests" / "unit" / "test_smoke.py", _smoke_test(name, version))
    _write(target / "references" / "README.md",
           f"# {name} 参考资料\n\nAI 运行时读的规则与术语放这里（控制平面）。\n")

    # MIT 要求所有副本都含许可声明；安装方式是复制本目录，根 LICENSE 不会跟着走
    _write(target / "LICENSE", (REPO / "LICENSE").read_text(encoding="utf-8"))

    print(f"  + skills/{name}/requirements.txt（uv export，带哈希）")
    subprocess.run(
        ["uv", "export", "--frozen", "--no-dev", "--no-emit-project",
         "--format", "requirements-txt", "-o", str(target / "requirements.txt")],
        cwd=REPO, check=True, capture_output=True,
    )

    corpus = CORPUS.read_text(encoding="utf-8").rstrip() + "\n" + _corpus_section(name, display)
    CORPUS.write_text(corpus, encoding="utf-8")
    print(f"  ~ {CORPUS.relative_to(REPO)}（追加 {name} 一节）")

    _print_next_steps(name, existing)
    return 0


def _print_next_steps(name: str, existing: list[str]) -> None:
    print("\n✅ 骨架已生成。现在跑一次守卫应当全绿：\n  uv run pytest tests/ -q\n")
    print("接下来（Experimental 阶段只需要这些）：")
    print(f"  1. 填 skills/{name}/SKILL.md 的 description —— 它是宿主路由的唯一依据")
    print(f"  2. 把 tests/triggering/corpus.yaml 里 {name} 的 <占位> 换成真实语料")
    print("  3. 写 scripts/ 与 tests/，删掉占位冒烟测试")
    print("\n转 Preview 时才需要（见 CONTRIBUTING.md 的分级清单）：")
    print("  · 输入输出契约、技术设计、独立前向测试")
    print(f"  · SKILL_META.platforms.compatible 填三家 + 两份 README 的三段提示词点名 {name}")

    if existing and len(existing) == 1:
        print(
            "\n⚠ 这是第 2 个 Skill，触发 versioning.md §3.2 的解耦条件。"
            "\n  须手工删除这条断言（它只在单 Skill 阶段成立）："
            "\n    tests/supply_chain/test_version_consistency.py::"
            "test_single_skill_stage_versions_are_aligned"
            "\n  没删的话它会红——这是有意的，解耦是人的决定，不由脚本代劳。"
        )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="new-skill", description="生成新 Skill 骨架")
    parser.add_argument("name", help="Skill 名，形如 fcs-clean")
    parser.add_argument("--display", required=True, help="中文名，如「清洗」")
    parser.add_argument("--description", required=True, help="一句话功能说明（进 SKILL_META）")
    args = parser.parse_args(argv)
    return create(args.name, args.display, args.description)


if __name__ == "__main__":
    raise SystemExit(main())
