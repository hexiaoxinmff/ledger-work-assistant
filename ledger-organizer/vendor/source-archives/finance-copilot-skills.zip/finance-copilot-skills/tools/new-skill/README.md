# tools/new-skill —— 新 Skill 脚手架

按统一规范生成一个新 Skill 的目录骨架与待补文档清单（对应 FT-12）。

## 生成内容

```
skills/<skill>/
├── SKILL.md              # 触发规范 / 功能 / 限制 / 数据处理声明骨架
├── SKILL_META.yaml       # 目录元数据（status=Experimental）
├── agents/               # 平台专属配置占位
├── scripts/              # 平铺模块占位（不包化）
├── references/           # AI 运行时规则/术语占位
├── assets/
├── tests/                # unit / property / golden / boundary / security + conftest.py
├── requirements.txt      # 由 tools/build 导出（占位）
└── CHANGELOG.md
docs/contracts/<skill>/    # 输入输出契约占位
```

## 用法

```bash
uv run python tools/new-skill/create.py fcs-clean \
  --display 清洗 --description "清洗 Excel/CSV 财务明细，统一编号、金额与日期格式。"
```

跑完后 `uv run pytest tests/` 应当**全绿，无需任何手工修改**。

## 为什么需要这个脚本

新增一个 Skill 会触发 4 个测试文件、27 条工具集级守卫，逐条手工满足要碰 10 个位置：
`SKILL.md` 的 frontmatter 与正文版本号、`SKILL_META.yaml`、`CHANGELOG.md`、
`scripts/version.py`、带哈希的 `requirements.txt`、`tests/conftest.py`、
`tests/triggering/corpus.yaml`、两份 README……

**那不是标准太高，是缺工具。** 放松这些守卫会让"版本号漂移只体现在审计证据里"
「安装路径写错时技能一个都不出现且无报错」这类问题重新变得不可发现；生成骨架则
既保住守卫，又把成本降到一条命令。

## 生成后的默认状态：Experimental，不对外安装

`SKILL_META.yaml` 生成时 `status: Experimental`、**`platforms.compatible: []`**。
后者是关键：`tests/cross_platform/` 用「compatible 是否非空」判定一个 Skill 是否
对外可安装——为空就**不必写进两份 README 的安装提示词**，那是新增 Skill 最重的
一处连带修改。

想对外发布时把 `compatible` 填上三家，守卫立刻开始要求它进提示词；反过来，没填却
写进了提示词也会红。**一个字段同时驱动两个方向**，不会出现"声称可装却没写进安装
说明"或"写进说明却没声称支持"的错配。

分阶段的完整清单见 [CONTRIBUTING.md](../../CONTRIBUTING.md#新增-skill-的提交清单对应-ft-12)。

## 不代劳的一件事

检测到这是**第 2 个 Skill** 时，脚本只打印提示，不自动删除
`test_single_skill_stage_versions_are_aligned`——按
[versioning.md](../../docs/governance/versioning.md) §3.2，`skill_version` 与工具集
版本解耦是一个需要人确认的决定，改测试代码不该由脚手架代劳。
