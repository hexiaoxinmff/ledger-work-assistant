"""Clean hand-kept Excel ledgers and reconcile them into one import-ready dataset.

Reads every ledger in legacy/, applies explicit general rules only (it does not
know which problems the sample data carries) and writes output/clean_dataset.xlsx:
clean master sheets, an approval log, a per-ledger reconciliation and an issue log.

Anything the rules cannot decide is imported (or held back, where importing
would mean guessing) and flagged "Needs business confirmation". Nothing is
dropped or changed silently.
"""
import argparse
import re
import sys
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parent.parent
AUTHOR = "Climb Yang"
LEDGER_YEAR = 2026                       # year assumed for dates written without one ("Sept 3")
AS_OF = date(2026, 9, 30)                # reporting date for due / overdue calculations
IMPORT_TS = datetime(2026, 9, 30, 9, 0)  # fixed so repeated runs give identical output

FONT = "Calibri"


def F(**kw):
    return Font(name=FONT, size=10, **kw)


FIXED = "Fixed"
CONFIRM = "Needs business confirmation"

FILES = ["customers.xlsx", "contracts_2026.xlsx", "orders_warehouse.xlsx", "payments_finance.xlsx",
         "expenses_2026Q3.xlsx"]

MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september",
          "october", "november", "december"]
LEGAL_WORDS = {"inc", "llc", "ltd", "limited", "co", "corp", "corporation", "company", "group"}

ISO_DATE = re.compile(r"(\d{4})-(\d{1,2})-(\d{1,2})")
SLASH_DATE = re.compile(r"(\d{1,2})/(\d{1,2})/(\d{4})")
DAY_MONTH_YEAR = re.compile(r"(\d{1,2})\s+([A-Za-z]+)\.?,?\s+(\d{4})")
MONTH_DAY = re.compile(r"([A-Za-z]+)\.?\s+(\d{1,2})(?:,?\s+(\d{4}))?")
AMOUNT = re.compile(r"(?:US\$|\$|USD)?\s*(\d[\d,]*(?:\.\d+)?|\.\d+)\s*([kKmM])?\s*(?:USD)?", re.I)

APPROVED, REJECTED, PENDING, DRAFT = "Approved", "Rejected", "Pending manager approval", "Draft"
STATUS_WORDS = {
    APPROVED: {"approved", "approve", "ok", "okay", "mgr approved", "manager approved"},
    REJECTED: {"rejected", "reject", "declined", "returned"},
    PENDING: {"pending", "pending mgr", "pending manager", "awaiting manager"},
    DRAFT: {"draft"},
}


class Log:
    """Collects issues. Per-cell fixes are grouped by (file, type, action); judgement calls are individual."""

    def __init__(self):
        self.entries = {}  # key -> dict(file, rows, kind, raws, action, status, seq)

    def _entry(self, key, file, kind, action, status):
        if key not in self.entries:
            self.entries[key] = {"file": file, "rows": [], "kind": kind, "raws": [], "action": action,
                                 "status": status, "seq": len(self.entries)}
        return self.entries[key]

    def group(self, file, kind, row, action, raw=None):
        e = self._entry((file, kind, action, FIXED), file, kind, action, FIXED)
        e["rows"].append(row)
        if raw:
            e["raws"].append(raw)

    def add(self, file, row, kind, raw, action, status=FIXED):
        e = self._entry(("single", len(self.entries)), file, kind, action, status)
        e["rows"].extend(row if isinstance(row, list) else [row])
        e["raws"].append(raw)
        e["single"] = True

    def count(self, file, status):
        return sum(len(e["rows"]) if not e.get("single") else 1
                   for e in self.entries.values() if e["file"] == file and e["status"] == status)

    def table(self):
        out = []
        for e in self.entries.values():
            rows = sorted(set(e["rows"]))
            where = ("Row " if len(rows) == 1 else "Rows ") + ", ".join(str(r) for r in rows)
            if e.get("single"):
                raw = e["raws"][0]
            else:
                shown = list(dict.fromkeys(e["raws"]))
                raw = f"{len(e['rows'])} occurrence(s)" + (f": {'; '.join(shown[:6])}" + (" ..." if len(shown) > 6 else "")
                                                     if shown else "")
            out.append((e["status"] != CONFIRM, FILES.index(e["file"]), min(e["rows"]), e["seq"],
                        [e["file"], where, e["kind"], raw, e["action"], e["status"]]))
        out.sort(key=lambda t: t[:4])
        return [[f"ISS-{i:02d}"] + t[4] for i, t in enumerate(out, 1)]


class Tally:
    def __init__(self, file, raw_rows):
        self.file, self.raw_rows = file, raw_rows
        self.blank = self.merged = self.held = self.imported = 0
        self.raw_amt = self.merged_amt = self.held_amt = self.imported_amt = 0.0


# ---------------------------------------------------------------- readers and small parsers

def load(src, name, log):
    ws = load_workbook(src / name, data_only=True).active
    rows = list(ws.iter_rows(values_only=True))
    data, blanks = [], 0
    for n, r in enumerate(rows[1:], 2):
        if all(v is None or str(v).strip() == "" for v in r):
            blanks += 1
            log.group(name, "Blank row", n, "Skipped")
        else:
            data.append((n, list(r)))
    return rows[0], data, blanks, len(rows) - 1


def tidy(rows, cols, file, log):
    """Trim and collapse whitespace in the given text columns; empty strings become None."""
    for n, r in rows:
        for c in cols:
            v = r[c]
            if isinstance(v, str):
                s = " ".join(v.split())
                if s != v:
                    log.group(file, "Leading, trailing or doubled spaces", n, "Trimmed", f"'{v}'")
                r[c] = s or None


def case_map(rows, col):
    """Map each case-insensitive spelling to the most common spelling in the ledger (ties: first seen)."""
    vals = [r[col] for _, r in rows if r[col]]
    counts, order = Counter(vals), list(dict.fromkeys(vals))
    best = {}
    for v in order:
        k = v.casefold()
        if k not in best or counts[v] > counts[best[k]]:
            best[k] = v
    return {v: best[v.casefold()] for v in order}


def apply_case(rows, col, file, log):
    cmap = case_map(rows, col)
    for n, r in rows:
        v = r[col]
        if v and cmap[v] != v:
            log.group(file, "Text capitalisation inconsistent", n, "Standardised to the ledger's most common spelling",
                      f"'{v}' -> '{cmap[v]}'")
            r[col] = cmap[v]


def contract_no(v, file, n, log):
    if v is None or str(v).strip() == "":
        return ""
    raw = str(v)
    no = re.sub(r"\s+", "", raw).upper()
    if no != raw:
        log.group(file, "Contract no. case or spacing", n, "Upper-cased, spaces removed", f"'{raw}'")
    return no


def money(v, file, n, log):
    """Normalise to a number in USD. Returns None when the text cannot be read."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    s = str(v).strip()
    m = AMOUNT.fullmatch(s)
    if not m:
        return None
    val = float(m.group(1).replace(",", ""))
    val *= {"k": 1e3, "m": 1e6}.get((m.group(2) or "").lower(), 1)
    val = round(val, 2)
    log.group(file, "Amount format inconsistent", n, "Converted to a number (USD)", f"'{s}' -> {val:,.2f}")
    return val


def slash_convention(rows, col):
    """Day-first or month-first for a ledger, from its unambiguous slash dates (ties default to month-first)."""
    dmy = mdy = 0
    for _, r in rows:
        m = SLASH_DATE.fullmatch(str(r[col]).strip()) if isinstance(r[col], str) else None
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            if a > 12 >= b:
                dmy += 1
            elif b > 12 >= a:
                mdy += 1
    return ("DMY" if dmy > mdy else "MDY"), dmy, mdy


def month_number(word):
    w = word.lower()
    for i, name in enumerate(MONTHS, 1):
        if len(w) >= 3 and (name.startswith(w) or (w == "sept" and i == 9)):
            return i
    return None


def when(v, conv, file, n, log):
    """Parse a date cell. Returns a date, or None when unreadable. Ambiguous day/month values are flagged."""
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = str(v).strip()
    try:
        d = None
        m = ISO_DATE.fullmatch(s)
        if m:
            d = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        if not d:
            m = DAY_MONTH_YEAR.fullmatch(s)
            if m and month_number(m.group(2)):
                d = date(int(m.group(3)), month_number(m.group(2)), int(m.group(1)))
        if not d:
            m = MONTH_DAY.fullmatch(s)
            if m and month_number(m.group(1)):
                year = int(m.group(3)) if m.group(3) else None
                d = date(year or LEDGER_YEAR, month_number(m.group(1)), int(m.group(2)))
                if year is None:
                    log.group(file, "Date written without a year", n, f"Year assumed to be {LEDGER_YEAR}", f"'{s}'")
                    return d
        if not d:
            m = SLASH_DATE.fullmatch(s)
            if m:
                a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
                if a > 12:
                    d = date(y, b, a)
                elif b > 12 or a == b:
                    d = date(y, a, b)
                else:
                    d = date(y, b, a) if conv == "DMY" else date(y, a, b)
                    alt = date(y, a, b) if conv == "DMY" else date(y, b, a)
                    log.add(file, n, "Ambiguous date (day/month)",
                            f"'{s}' reads as {d:%d %b %Y} or {alt:%d %b %Y}",
                            f"Imported as {d:%Y-%m-%d} using this ledger's {conv} convention", CONFIRM)
                    return d
        if not d:
            return None
    except ValueError:
        return None
    log.group(file, "Date format inconsistent", n, "Converted to a true date (yyyy-mm-dd)", f"'{s}'")
    return d


def name_key(s):
    words = re.sub(r"[^a-z0-9 ]", " ", s.casefold()).split()
    return tuple(w for w in words if w not in LEGAL_WORDS)


def match_customer(raw, customers, file, n, log):
    """Map a written customer name to the master list. Returns None when there is no single clear match."""
    if raw in customers:
        return raw
    k = name_key(raw)
    hits = [c for c in customers if k and (name_key(c) == k or name_key(c)[:len(k)] == k or k[:len(name_key(c))] == name_key(c))]
    if len(hits) == 1:
        log.group(file, "Customer name written differently", n, "Mapped to the customer list's full name",
                  f"'{raw}' -> '{hits[0]}'")
        return hits[0]
    return None


def hold(log, tally, n, kind, raw, action):
    tally.held += 1
    log.add(tally.file, n, kind, raw, action, CONFIRM)


# ---------------------------------------------------------------- the migration

def migrate(src, as_of):
    log = Log()
    tallies = {}

    # customers
    file = "customers.xlsx"
    _, rows, blanks, total = load(src, file, log)
    tidy(rows, [0, 1, 2], file, log)
    customers = {}
    for i, (_, r) in enumerate(rows, 1):
        customers[r[0]] = {"code": f"C{i:03d}", "type": r[1], "owner": r[2], "terms": int(r[3])}
    t = tallies[file] = Tally(file, total)
    t.blank, t.imported = blanks, len(customers)

    # contracts
    file = "contracts_2026.xlsx"
    _, rows, blanks, total = load(src, file, log)
    tidy(rows, [1, 2, 5], file, log)
    conv, dmy, mdy = slash_convention(rows, 3)
    t = tallies[file] = Tally(file, total)
    t.blank = blanks
    contracts, seen = {}, {}
    for n, r in rows:
        no = contract_no(r[0], file, n, log)
        amt = money(r[4], file, n, log)
        if amt is None:
            hold(log, t, n, "Unreadable amount", f"{no}: '{r[4]}'", "Row held back, not imported")
            continue
        t.raw_amt += amt
        signed = when(r[3], conv, file, n, log)
        if signed is None:
            hold(log, t, n, "Unreadable date", f"{no}: '{r[3]}'", "Row held back, not imported")
            t.held_amt += amt
            continue
        key = (no, r[1], r[2], signed, amt, r[5])
        if no in seen:
            if seen[no] == key:
                t.merged += 1
                t.merged_amt += amt
                log.add(file, n, "Duplicate row", f"{no} is identical to an earlier row", "Merged into one record")
            else:
                hold(log, t, n, "Same contract no. with different details", f"{no} appears twice with different content",
                     "First kept, this row held back for confirmation")
                t.held_amt += amt
            continue
        seen[no] = key
        cust = match_customer(r[1], customers, file, n, log)
        if cust is None:
            hold(log, t, n, "Customer cannot be matched", f"{no}: '{r[1]}'", "Held back until sales confirms the customer")
            t.held_amt += amt
            continue
        contracts[no] = {"title": r[2], "customer": cust, "signed": signed, "amount": amt,
                         "terms": customers[cust]["terms"], "owner": customers[cust]["owner"], "status": r[5],
                         "note": ""}
    t.imported = len(contracts)
    t.imported_amt = sum(c["amount"] for c in contracts.values())

    # orders
    file = "orders_warehouse.xlsx"
    _, rows, blanks, total = load(src, file, log)
    tidy(rows, [0, 3, 6], file, log)
    apply_case(rows, 3, file, log)
    conv, _, _ = slash_convention(rows, 2)
    t = tallies[file] = Tally(file, total)
    t.blank = blanks
    orders, seen = [], {}
    for n, r in rows:
        no = contract_no(r[1], file, n, log)
        amt = money(r[5], file, n, log)
        if amt is None:
            hold(log, t, n, "Unreadable amount", f"{r[0]}: '{r[5]}'", "Row held back, not imported")
            continue
        t.raw_amt += amt
        odate = when(r[2], conv, file, n, log)
        if odate is None:
            hold(log, t, n, "Unreadable date", f"{r[0]}: '{r[2]}'", "Row held back, not imported")
            t.held_amt += amt
            continue
        key = (r[0], no, odate, r[3], r[4], amt)
        if r[0] in seen:
            if seen[r[0]] == key:
                t.merged += 1
                t.merged_amt += amt
                log.add(file, n, "Duplicate row", f"{r[0]} is identical to an earlier row", "Merged into one record")
            else:
                hold(log, t, n, "Same order no. with different details", f"{r[0]} appears twice with different content",
                     "First kept, this row held back for confirmation")
                t.held_amt += amt
            continue
        seen[r[0]] = key
        if no not in contracts:
            hold(log, t, n, "Contract no. not found in contract register", f"{r[0]} cites {no or '(blank)'}",
                 "Held back until the warehouse confirms the contract")
            t.held_amt += amt
            continue
        orders.append({"no": r[0], "contract": no, "date": odate, "cat": r[3], "qty": r[4], "amount": amt,
                       "ship": r[6], "row": n, "note": ""})
    ordered = defaultdict(float)
    for o in orders:
        ordered[o["contract"]] += o["amount"]
    for no, total_amt in ordered.items():
        if total_amt > contracts[no]["amount"] + 0.005:
            hits = [o for o in orders if o["contract"] == no]
            for o in hits:
                o["note"] = "Order total exceeds contract value"
            contracts[no]["note"] = "Order total exceeds contract value"
            log.add(file, [o["row"] for o in hits], "Order total exceeds contract value",
                    f"{no}: orders total {total_amt:,.2f}, contract value {contracts[no]['amount']:,.2f}",
                    "Imported as written; sales to confirm whether an amendment exists", CONFIRM)
    t.imported = len(orders)
    t.imported_amt = sum(o["amount"] for o in orders)

    # payments
    file = "payments_finance.xlsx"
    _, rows, blanks, total = load(src, file, log)
    tidy(rows, [1, 4, 5, 6], file, log)
    conv, _, _ = slash_convention(rows, 0)
    t = tallies[file] = Tally(file, total)
    t.blank = blanks
    payments, refs = [], {}
    for n, r in rows:
        amt = money(r[3], file, n, log)
        if amt is None:
            hold(log, t, n, "Unreadable amount", f"'{r[3]}' ({r[1]})", "Row held back, not imported")
            continue
        t.raw_amt += amt
        pdate = when(r[0], conv, file, n, log)
        if pdate is None:
            hold(log, t, n, "Unreadable date", f"'{r[0]}' ({r[1]})", "Row held back, not imported")
            t.held_amt += amt
            continue
        ref = re.sub(r"\s+", "", str(r[5] or "")).upper()
        no = contract_no(r[2], file, n, log)
        payer = match_customer(r[1], customers, file, n, log)
        if ref in refs:
            first_row, first = refs[ref]
            diffs = [label for label, a, b in (("date", first["date"], pdate), ("contract no.", first["raw_contract"], no),
                                              ("entered by", first["clerk"], r[6])) if a != b]
            same = first["amount"] == amt and first["payer"] == (payer or r[1])
            if same:
                t.merged += 1
                t.merged_amt += amt
                detail = f"Bank ref {ref} already recorded on row {first_row} (same payer and amount"
                detail += f"; differs in {', '.join(diffs)})" if diffs else ")"
                log.add(file, n, "Same bank reference entered twice", detail, "Merged into one record")
            else:
                hold(log, t, n, "Same bank reference with different amount or payer",
                     f"Bank ref {ref} already recorded on row {first_row}", "First kept, this row held back for confirmation")
                t.held_amt += amt
            continue
        payer_name = payer or r[1]
        note, link = "", no
        if payer is None:
            log.add(file, n, "Payer not found in customer list", f"'{r[1]}', {amt:,.2f}", "Imported as written", CONFIRM)
        if no and no not in contracts:
            note, link = f"Contract no. {no} not in register", ""
            log.add(file, n, "Contract no. not found in contract register", f"{payer_name}, {amt:,.2f}, cites {no}",
                    "Imported but not linked to a contract; finance to confirm", CONFIRM)
        elif not no:
            mine = sorted(k for k, c in contracts.items() if c["customer"] == payer)
            note = "No contract no. in source ledger"
            log.add(file, n, "Payment without a contract no.",
                    f"{payer_name}, {amt:,.2f}; customer has {len(mine)} contract(s): {', '.join(mine) or 'none'}",
                    "Imported but not linked to a contract; not auto-assigned", CONFIRM)
        elif contracts[no]["customer"] != payer:
            note = "Payer differs from contract customer"
            log.add(file, n, "Payer differs from contract customer", f"{payer_name} paid {no}",
                    "Imported and linked as written; finance to confirm", CONFIRM)
        rec = {"contract": link, "raw_contract": no, "payer": payer_name, "date": pdate, "amount": amt,
               "method": r[4], "ref": ref, "clerk": r[6], "note": note}
        refs[ref] = (n, rec)
        payments.append(rec)
    t.imported = len(payments)
    t.imported_amt = sum(p["amount"] for p in payments)

    # expenses
    file = "expenses_2026Q3.xlsx"
    _, rows, blanks, total = load(src, file, log)
    tidy(rows, [0, 1, 2, 3, 6, 7], file, log)
    apply_case(rows, 2, file, log)
    apply_case(rows, 3, file, log)
    conv, _, _ = slash_convention(rows, 8)
    t = tallies[file] = Tally(file, total)
    t.blank = blanks
    expenses = []
    for n, r in rows:
        amt = money(r[4], file, n, log)
        if amt is None:
            hold(log, t, n, "Unreadable amount", f"{r[0]}: '{r[4]}'", "Row held back, not imported")
            continue
        t.raw_amt += amt
        applied = when(r[8], conv, file, n, log)
        if applied is None:
            hold(log, t, n, "Unreadable date", f"{r[0]}: '{r[8]}'", "Row held back, not imported")
            t.held_amt += amt
            continue
        status = map_status(r[7])
        if status is None:
            status = DRAFT
            log.add(file, n, "Approval status not recognised", f"{r[0]}: '{r[7]}'",
                    "Imported as Draft; approver to re-confirm", CONFIRM)
        elif r[7] is None:
            log.group(file, "Approval status blank", n, f"Imported as {status}")
        elif r[7] != status:
            if status == PENDING:
                log.group(file, "Approval status does not name the approval step", n,
                          f"Imported as '{status}'; manager to re-confirm", f"'{r[7]}'")
            else:
                log.group(file, "Approval status wording varies", n, "Mapped to the standard status",
                          f"'{r[7]}' -> {status}")
        no = contract_no(r[5], file, n, log)
        if no and no not in contracts:
            log.add(file, n, "Contract no. not found in contract register", f"{r[0]} cites {no}",
                    "Imported with the contract left blank", CONFIRM)
            no = ""
        expenses.append({"no": r[0], "who": r[1], "dept": r[2], "cat": r[3], "amount": amt, "contract": no,
                         "reason": r[6], "status": status, "orig": r[7] or "(blank)", "date": applied})
    t.imported = len(expenses)
    t.imported_amt = sum(e["amount"] for e in expenses)

    return log, tallies, customers, contracts, orders, payments, expenses, ordered


def map_status(raw):
    if raw is None:
        return DRAFT
    k = " ".join(re.sub(r"[^a-z ]", " ", str(raw).casefold()).split())
    for status, words in STATUS_WORDS.items():
        if k in words or k == status.casefold():
            return status
    return None


# ---------------------------------------------------------------- workbook output

HEAD_FILL = PatternFill("solid", fgColor="1F3864")
GOOD = (PatternFill("solid", fgColor="C6EFCE"), F(color="006100", bold=True))
WARN = (PatternFill("solid", fgColor="FFEB9C"), F(color="7F4F00", bold=True))
BAD = (PatternFill("solid", fgColor="FFC7CE"), F(color="9C0006", bold=True))
GREY = (PatternFill("solid", fgColor="E7E6E6"), F(color="404040", bold=True))
EDGE = Border(bottom=Side(style="thin", color="D9D9D9"))
STATUS_STYLE = {FIXED: GOOD, CONFIRM: WARN, "OK": GOOD, "Mismatch": BAD, APPROVED: GOOD, REJECTED: BAD,
                PENDING: WARN, DRAFT: GREY}


def add_sheet(wb, title, header, rows, widths=None, freeze="A2", wrap=(), style_cols=(), filt=True):
    ws = wb.create_sheet(title)
    ws.append(header)
    for c in ws[1]:
        c.fill, c.font = HEAD_FILL, F(color="FFFFFF", bold=True)
        c.alignment = Alignment(vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 30
    for r in rows:
        ws.append(r)
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.border = EDGE
            c.font = F()
            c.alignment = Alignment(vertical="top", wrap_text=c.column in wrap)
            if isinstance(c.value, datetime):
                c.number_format = "yyyy-mm-dd hh:mm"
            elif isinstance(c.value, date):
                c.number_format = "yyyy-mm-dd"
            elif isinstance(c.value, float):
                c.number_format = "#,##0.00"
            elif isinstance(c.value, int):
                c.number_format = "#,##0"
            if c.column in style_cols and c.value in STATUS_STYLE:
                c.fill, c.font = STATUS_STYLE[c.value]
    for i, col in enumerate(ws.columns, 1):
        if widths and i in widths:
            w = widths[i]
        else:
            w = min(max(len(f"{c.value:,.2f}" if isinstance(c.value, float) else str(c.value or "")) for c in col) + 3, 48)
        ws.column_dimensions[get_column_letter(i)].width = max(w, 11)
    if wrap:
        for row in ws.iter_rows(min_row=2):
            lines = max(-(-len(str(c.value or "")) // int(ws.column_dimensions[c.column_letter].width * 1.05))
                        for c in row if c.column in wrap)
            ws.row_dimensions[row[0].row].height = max(lines, 1) * 13.5 + 3
    ws.freeze_panes = freeze
    if filt:
        ws.auto_filter.ref = ws.dimensions
    ws.page_setup.orientation = "landscape"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToHeight = 0
    return ws


def write(out, as_of, log, tallies, customers, contracts, orders, payments, expenses, ordered):
    paid = defaultdict(float)
    for p in payments:
        if p["contract"]:
            paid[p["contract"]] += p["amount"]

    wb = Workbook()
    wb.remove(wb.active)
    add_sheet(wb, "Customers", ["Customer ID", "Customer Name", "Customer Type", "Account Manager",
                                "Payment Terms (days)"],
              [[v["code"], k, v["type"], v["owner"], v["terms"]] for k, v in customers.items()])

    crow = []
    for no, c in sorted(contracts.items()):
        due = c["signed"] + timedelta(days=c["terms"])
        outstanding = round(c["amount"] - paid[no], 2)
        overdue = outstanding if (as_of > due and outstanding > 0) else 0.0
        crow.append([no, c["title"], c["customer"], c["signed"], c["amount"], c["terms"], c["owner"], c["status"],
                     due, round(ordered[no], 2), round(paid[no], 2), outstanding, float(overdue), c["note"]])
    add_sheet(wb, "Contracts", ["Contract No", "Title", "Customer", "Signed", "Contract Value (USD)",
                                "Terms (days)", "Account Manager", "Status", "Due Date", "Ordered (USD)",
                                "Paid (USD)", "Outstanding (USD)", f"Overdue at {as_of:%Y-%m-%d} (USD)",
                                "Migration Note"], crow, freeze="B2", wrap=(14,))
    ws = wb["Contracts"]
    for row in ws.iter_rows(min_row=2):
        if row[12].value:
            row[12].fill, row[12].font = BAD

    add_sheet(wb, "Orders", ["Order No", "Contract No", "Order Date", "Category", "Qty", "Amount (USD)",
                             "Shipping Status", "Migration Note"],
              [[o["no"], o["contract"], o["date"], o["cat"], o["qty"], o["amount"], o["ship"], o["note"]]
               for o in sorted(orders, key=lambda o: (o["date"], o["no"]))])

    prow = [[f"PAY-{i:04d}", p["contract"], p["payer"], p["date"], p["amount"], p["method"], p["ref"], p["clerk"],
             p["note"]] for i, p in enumerate(sorted(payments, key=lambda p: (p["date"], p["ref"])), 1)]
    add_sheet(wb, "Payments", ["Payment ID", "Contract No", "Payer", "Date Received", "Amount (USD)", "Method",
                               "Bank Ref", "Entered By", "Migration Note"], prow)

    add_sheet(wb, "Expenses", ["Expense No", "Applicant", "Department", "Category", "Amount (USD)", "Contract No",
                               "Reason", "Approval Status", "Date Applied"],
              [[e["no"], e["who"], e["dept"], e["cat"], e["amount"], e["contract"], e["reason"], e["status"],
                e["date"]] for e in expenses], style_cols=(8,))

    add_sheet(wb, "Approval Log", ["Summary", "Expense No", "Step", "Action", "Actor", "Note", "Timestamp"],
              [[f"{e['no']} migrated", e["no"], "Migration", "Imported", "Migration script",
                f"Source status: {e['orig']}; imported as: {e['status']}", IMPORT_TS] for e in expenses])

    rec = []
    for name in FILES:
        t = tallies[name]
        has_amt = name != "customers.xlsx"
        rows_ok = t.raw_rows - t.blank - t.merged - t.held == t.imported
        amt_ok = (not has_amt) or abs(t.raw_amt - t.merged_amt - t.held_amt - t.imported_amt) < 0.005
        rec.append([name, t.raw_rows, t.blank, t.merged, t.held, t.imported,
                    log.count(name, CONFIRM),
                    t.raw_amt if has_amt else None, t.merged_amt if has_amt else None,
                    t.held_amt if has_amt else None, t.imported_amt if has_amt else None,
                    (t.raw_amt - t.imported_amt) if has_amt else None,
                    "OK" if rows_ok and amt_ok else "Mismatch"])
    ws = add_sheet(wb, "Reconciliation",
                   ["Source ledger", "Source rows", "Blank rows", "Merged duplicates", "Held back", "Imported rows",
                    "Items flagged", "Source total (USD)", "Merged duplicates (USD)", "Held back (USD)",
                    "Imported total (USD)", "Difference (USD)", "Check"], rec, style_cols=(13,), filt=False,
                   widths={1: 26, 2: 12, 3: 12, 4: 14, 5: 11, 6: 14, 7: 12, 8: 18, 9: 20, 10: 16, 11: 19, 12: 17,
                           13: 12})
    linked = sum(paid.values())
    unlinked = sum(p["amount"] for p in payments if not p["contract"])
    imported_pay = tallies["payments_finance.xlsx"].imported_amt
    ws.append([])
    ws.append(["Cross-checks"])
    ws.cell(ws.max_row, 1).font = F(bold=True)
    checks = [
        ("Payments: linked + not linked = imported total", linked + unlinked, imported_pay),
        ("Contracts sheet 'Paid' column = payments linked to a contract", sum(c[10] for c in crow), linked),
        ("Contracts sheet 'Ordered' column = imported order total", sum(c[9] for c in crow),
         tallies["orders_warehouse.xlsx"].imported_amt),
    ]
    for label, a, b in checks:
        ws.append([label, None, None, None, None, None, None, round(a, 2), None, None, round(b, 2),
                   round(a - b, 2), "OK" if abs(a - b) < 0.005 else "Mismatch"])
        r = ws.max_row
        ws.cell(r, 8).number_format = ws.cell(r, 11).number_format = ws.cell(r, 12).number_format = "#,##0.00"
        ws.cell(r, 13).fill, ws.cell(r, 13).font = STATUS_STYLE[ws.cell(r, 13).value]
    ws.append([])
    ws.append([f"Unlinked payments awaiting confirmation: {sum(1 for p in payments if not p['contract'])} "
               f"payments, {unlinked:,.2f} USD. Held-back rows are excluded from the imported totals."])
    ws.append(["Difference = source total minus imported total; it equals the merged duplicates plus any held-back rows."])

    issues = log.table()
    add_sheet(wb, "Issue Log", ["Issue ID", "Source file", "Source row(s)", "Issue type", "Original value",
                                "Action taken", "Status"], issues,
              widths={1: 10, 2: 26, 3: 16, 4: 38, 5: 78, 6: 52, 7: 28}, wrap=(2, 3, 4, 5, 6, 7), style_cols=(7,))

    for ws in wb:
        for row in ws.iter_rows():
            for c in row:
                if c.font.size != 10:
                    c.font = F(bold=bool(c.font.b))
    wb.properties.creator = AUTHOR
    wb.properties.lastModifiedBy = AUTHOR
    wb.properties.created = IMPORT_TS
    wb.properties.modified = IMPORT_TS
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    return rec, issues, paid, linked, unlinked


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--legacy", type=Path, default=ROOT / "legacy")
    ap.add_argument("--out", type=Path, default=ROOT / "output" / "clean_dataset.xlsx")
    ap.add_argument("--as-of", type=date.fromisoformat, default=AS_OF, help="reporting date for overdue amounts")
    args = ap.parse_args()
    # consoles with a legacy code page cannot print every character found in the ledgers
    sys.stdout.reconfigure(errors="replace")

    log, tallies, customers, contracts, orders, payments, expenses, ordered = migrate(args.legacy, args.as_of)
    rec, issues, paid, linked, unlinked = write(args.out, args.as_of, log, tallies, customers, contracts, orders,
                                                payments, expenses, ordered)

    print(f"written {args.out}")
    for r in rec:
        amounts = "" if r[7] is None else f"; amount {r[7]:,.2f} -> {r[10]:,.2f}, difference {r[11]:,.2f}"
        print(f"  {r[0]}: {r[1]} rows, blank {r[2]}, merged {r[3]}, held {r[4]}, imported {r[5]}{amounts} [{r[12]}]")
    kinds = {}
    for i in issues:
        kinds.setdefault(i[3], set()).add(i[6])
    fixed = sorted(k for k, s in kinds.items() if s == {FIXED})
    confirm = sorted(k for k, s in kinds.items() if CONFIRM in s)
    print(f"  issue log: {len(issues)} entries, {len(kinds)} issue types "
          f"({len(fixed)} fixed by rule, {len(confirm)} needing business confirmation)")
    print(f"  entries needing confirmation: {sum(1 for i in issues if i[6] == CONFIRM)}")
    print(f"  contract value {sum(c['amount'] for c in contracts.values()):,.2f}; payments linked {linked:,.2f}, "
          f"unlinked {unlinked:,.2f}")
    for i in issues:
        print("   ", " | ".join(str(x) for x in i))


if __name__ == "__main__":
    main()
