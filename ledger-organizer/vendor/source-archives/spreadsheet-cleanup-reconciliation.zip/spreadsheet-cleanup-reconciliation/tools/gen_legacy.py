"""Build mock legacy Excel ledgers for the cleanup sample.

All names, amounts and dates are fictional. The ledgers deliberately carry the
kinds of problems hand-kept spreadsheets have (name variants, mixed date and
amount formats, duplicate rows, unknown contract numbers) so migrate.py has
something real to find.
"""
from datetime import date, datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font

FONT = "Calibri"

OUT = Path(__file__).resolve().parent.parent / "legacy"
AUTHOR = "Climb Yang"
STAMP = datetime(2026, 9, 30, 9, 0)

# name, type, account manager, payment terms (days)
CUSTOMERS = [
    ("Northwind Grocers Inc", "Chain retail", "Dana Whitfield", 45),
    ("Brightpath Baby Stores", "Chain retail", "Dana Whitfield", 60),
    ("Maple Corporate Gifts LLC", "Corporate buyer", "Ethan Cole", 30),
    ("Summit Trade Co. Ltd", "Distributor", "Ethan Cole", 30),
    ("Bluepeak Wholesale Supply", "Distributor", "Priya Nair", 45),
    ("Harvest Lane Markets", "Channel platform", "Priya Nair", 15),
    ("Lakeside Hotels Group Ltd", "Corporate buyer", "Ethan Cole", 60),
    ("Crestline Promo Products ", "Distributor", "Dana Whitfield", 30),
]

# contract no, customer as written, title, signed (as written), value (as written), status
CONTRACT_ROWS = [
    ("CT-2026-001", "Northwind Grocers Inc", "Q3 store restock", date(2026, 6, 8), 168000, "Completed"),
    ("CT-2026-002", "Maple Corporate Gifts LLC", "Holiday staff gift boxes", "07/15/2026", 236000, "Completed"),
    ("CT-2026-003", "Summit Trade", "Regional distribution Q3", "20 Jun 2026", 120000, "Active"),
    ("CT-2026-004", "Brightpath Baby", "In-store baby range supply", "2 Jul 2026", "$86,000.00", "Completed"),
    ("CT-2026-005", "Bluepeak Wholesale Supply", "Wholesale pilot order", "07/28/2026", 54000, "Active"),
    ("CT-2026-006", "Harvest Lane Markets", "August promotion campaign", "2026-08-01", "USD 39800", "Completed"),
    ("CT-2026-007", "Lakeside Hotels", "Annual guest amenities supply", date(2026, 8, 12), "258k", "Active"),
    ("CT-2026-007", "Lakeside Hotels", "Annual guest amenities supply", date(2026, 8, 12), "258k", "Active"),
    ("CT-2026-008", "CRESTLINE PROMO PRODUCTS", "Custom promo items", "08/25/2026", 72000, "Active"),
    (None, None, None, None, None, None),
    ("CT-2026-009", "Northwind Grocers Inc ", "Peak season top-up", "Sept 3", 95000, "Active"),
    ("CT-2026-010", "Summit Trade Co., Ltd.", "Regional distribution Q4", "09/10/2026", "130k", "Active"),
    (" ct-2026-011", "Maple Corporate Gifts", "Year-end gift pre-order", date(2026, 9, 18), "180,000 USD", "Active"),
    ("CT-2026-012", "Harvest Lane Markets", "September promotion campaign", "5 Sep 2026", "$42,500", "Active"),
]

# order no, contract no (as written), date, category, qty, amount (as written), shipping
ORDER_ROWS = [
    ("ORD-260611", "CT-2026-001", date(2026, 6, 11), "Snack Box", 1400, 98000, "Delivered"),
    ("ORD-260702", "CT-2026-001", "2 Jul 2026", "Snack Box", 1000, "$70,000", "Delivered"),
    ("ORD-260718", "CT-2026-002", date(2026, 7, 18), "Holiday Gift Box", 1500, 120000, "Delivered"),
    ("ORD-260801", "CT-2026-002", "1 Aug 2026", "Holiday Gift Box", 1000, 80000, "Delivered"),
    ("ORD-260815", "ct-2026-002 ", date(2026, 8, 15), "Personal Care Set", 600, "$36,000.00", "Delivered"),
    ("ORD-260623", "CT-2026-003", date(2026, 6, 23), "Home Cleaning", 3500, 70000, "Delivered"),
    ("ORD-260722", "CT-2026-003", "22 Jul 2026", "home cleaning", 2500, "50k", "Delivered"),
    ("ORD-260705", "CT-2026-004", date(2026, 7, 5), "Baby Products", 1720, 86000, "Delivered"),
    ("ORD-260730", "CT-2026-005", date(2026, 7, 30), "Snack Box", 900, 54000, "Delivered"),
    ("ORD-260804", "CT-2026-006", date(2026, 8, 4), "Home Cleaning", 1990, "USD 39,800.00", "Delivered"),
    ("ORD-260816", "CT-2026-007", date(2026, 8, 16), "Personal Care Set", 2600, 130000, "Shipped"),
    ("ORD-260828", "CT-2026-008", date(2026, 8, 28), "Holiday Gift Box", 600, 48000, "Delivered"),
    ("ORD-260910", "CT-2026-008", date(2026, 9, 10), "HOLIDAY GIFT BOX", 380, "28.5k", "Delivered "),
    ("ORD-260910", "CT-2026-008", date(2026, 9, 10), "HOLIDAY GIFT BOX", 380, "28.5k", "Delivered "),
    ("ORD-260906", "CT-2026-009", "Sept 6", "Snack Box", 860, 60000, "Shipped"),
    ("ORD-260914", "CT-2026-010", "14/09/2026", "Home Cleaning", 3250, 65000, "Shipped"),
    ("ORD-260908", "CT-2026-012", date(2026, 9, 8), "Home Cleaning", 2125, 42500, "Delivered"),
]

# date, payer as written, contract no (as written), amount, method, bank ref, entered by
PAYMENT_ROWS = [
    (date(2026, 7, 10), "Northwind Grocers Inc", "CT-2026-001", 80000, "Wire transfer", "WT20260710003", "Linda Foster"),
    ("20/08/2026", "Northwind Grocers Inc", "CT-2026-001", 88000, "Wire transfer", "WT20260820011", "Linda Foster"),
    (date(2026, 7, 25), "Maple Corporate Gifts LLC", "CT-2026-002", 100000, "Wire transfer", "WT20260725006", "Linda Foster"),
    ("28 Aug 2026", "Maple Corporate Gifts LLC", "CT-2026-002", 136000, "Bank draft", "BD20260828001", "Linda Foster"),
    (date(2026, 7, 30), "Summit Trade", "CT-2026-003", 60000, "Wire transfer", "WT20260730014", "Linda Foster"),
    (date(2026, 8, 15), "Brightpath Baby", "CT-2026-004", 40000, "Wire transfer", "WT20260815002", "Linda Foster"),
    ("28/09/2026", "Brightpath Baby Stores", "CT-2026-004", "$46,000.00", "Wire transfer", "WT20260928009", "Linda Foster"),
    (date(2026, 8, 14), "Harvest Lane Markets", "CT-2026-006", 39800, "Online payment", "OP20260814117", "Linda Foster"),
    (date(2026, 9, 15), "Lakeside Hotels Group Ltd", "CT-2026-007", "120k", "Wire transfer", "WT20260915004", "Linda Foster"),
    ("01/09/2026", "Crestline Promo Products", "CT-2026-008", 36000, "Wire transfer", "WT20260901008", "Linda Foster"),
    (date(2026, 9, 25), "Summit Trade Co., Ltd.", "CT-2026-010", 65000, "Wire transfer", "WT20260925012", "Linda Foster"),
    (date(2026, 9, 19), "Harvest Lane Markets", "CT-2026-012", 42500, "Online payment", "OP20260919042", "Linda Foster"),
    (date(2026, 9, 20), "Harvest Lane Markets", "CT-2026-012", 42500, "Online payment", "OP20260919042", "Marcus Chen"),
    (date(2026, 9, 26), "Crestline Promo", "CT-2026-013", 18000, "Wire transfer", "WT20260926005", "Marcus Chen"),
    (date(2026, 9, 29), "Northwind Grocers Inc", None, 30000, "Wire transfer", "WT20260929010", "Marcus Chen"),
]

# expense no, applicant, dept, category, amount (as written), contract, reason, status (as written), applied
EXPENSE_ROWS = [
    ("EXP-2026-0901", "Dana Whitfield", "Sales", "Travel", 3260, "CT-2026-001", "Store visits", "approved", date(2026, 7, 12)),
    ("EXP-2026-0902", "Ethan Cole", "Sales", "Entertainment", 1880, "CT-2026-002", "Holiday proposal meeting", "Approved ✓", "20 Jul 2026"),
    ("EXP-2026-0903", "Priya Nair", "Operations", "Marketing", "12k", None, "Online campaign promotion fee", "OK", date(2026, 8, 3)),
    ("EXP-2026-0904", "Tom Becker", "Logistics", "Freight", 6450, "ct-2026-007", "Hotel client first delivery", "approved", date(2026, 8, 18)),
    ("EXP-2026-0905", "Dana Whitfield ", "Sales", "Samples", 2300, "CT-2026-008", "Sample run for custom items", "rejected", "27 Aug 2026"),
    ("EXP-2026-0906", "Ethan Cole", "Sales", "travel", 4120, "CT-2026-010", "Distributor visit", "approved", date(2026, 9, 12)),
    ("EXP-2026-0907", "Grace Liu", "Admin", "Office", 860, None, "Printer supplies", "approved ", date(2026, 9, 15)),
    ("EXP-2026-0908", "Priya Nair", "Operations", "Marketing", 8800, "CT-2026-012", "September slot promotion", "pending mgr", "Sept 22"),
    ("EXP-2026-0909", "Dana Whitfield", "Sales", "Travel", 5600, "CT-2026-011", "Year-end proposal for client", "Pending Mgr", "Sep 26"),
    ("EXP-2026-0910", "Ethan Cole", "sales", "Entertainment", 2450, None, "Pre-holiday client thank-you", None, "2026-09-29"),
]


def save(name, header, rows, sheet):
    wb = Workbook()
    ws = wb.active
    ws.title = sheet
    ws.append(header)
    for r in rows:
        ws.append(list(r))
    for row in ws.iter_rows():
        for c in row:
            c.font = Font(name=FONT, size=10, bold=c.row == 1)
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = 18
    wb.properties.creator = AUTHOR
    wb.properties.lastModifiedBy = AUTHOR
    wb.properties.created = STAMP
    wb.properties.modified = STAMP
    wb.save(OUT / name)
    print(f"{name}: {len(rows)} rows")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    save("customers.xlsx", ["Customer Name", "Customer Type", "Account Manager", "Payment Terms (days)"],
         CUSTOMERS, "Customers")
    save("contracts_2026.xlsx", ["Contract No", "Customer", "Description", "Signed", "Contract Value", "Status"],
         CONTRACT_ROWS, "Contracts")
    save("orders_warehouse.xlsx",
         ["Order No", "Contract No", "Order Date", "Category", "Qty", "Amount", "Shipping Status"],
         ORDER_ROWS, "Orders")
    save("payments_finance.xlsx",
         ["Date Received", "Payer", "Contract No", "Amount", "Method", "Bank Ref", "Entered By"],
         PAYMENT_ROWS, "Payments")
    save("expenses_2026Q3.xlsx",
         ["Expense No", "Applicant", "Department", "Category", "Amount", "Contract", "Reason", "Status", "Date Applied"],
         EXPENSE_ROWS, "Expenses")


if __name__ == "__main__":
    main()
