# Spreadsheet Cleanup and Reconciliation (sample)

![Issue log, reconciliation and key figures from the sample run](images/00_cover.png)

Turns five hand-kept Excel ledgers (customers, contracts, orders, payments, expenses) into one clean, reconciled dataset that is ready to import into a database, accounting tool or no-code platform. Every problem the script finds is written to an issue log, and anything it cannot decide on its own is flagged for the business instead of being guessed.

All customer names, amounts and dates are fictional. All amounts are in a single currency (USD); no exchange-rate conversion is done.

## What is in the folder

| Path | Content |
|---|---|
| `tools/gen_legacy.py` | Builds the five messy sample ledgers |
| `tools/migrate.py` | Cleans the ledgers and writes the dataset, reconciliation and issue log |
| `legacy/` | The five source ledgers: `customers.xlsx`, `contracts_2026.xlsx`, `orders_warehouse.xlsx`, `payments_finance.xlsx`, `expenses_2026Q3.xlsx` |
| `output/clean_dataset.xlsx` | The result |
| `images/` | Screenshots of the issue log, reconciliation sheet and cleaned contracts sheet |
| `requirements.txt` | Python dependency (openpyxl) |

## How to run

Requires Python 3.10 or newer and openpyxl.

1. `pip install -r requirements.txt`
2. `python tools/gen_legacy.py` (optional; the sample ledgers are already in `legacy/`)
3. `python tools/migrate.py`

The script prints the row counts and amount totals before and after for each ledger, then the full issue log. Optional arguments: `--legacy` (folder with the ledgers), `--out` (output file), `--as-of` (reporting date used for the overdue column, default 2026-09-30). Repeated runs on the same input produce identical content.

## Cleaning rules

The script applies explicit, general rules only. It has no special cases for the problems planted in the sample data, so the same rules apply to real ledgers.

- **Blank rows** are skipped and logged.
- **Extra spaces** (leading, trailing, doubled) in text cells are trimmed.
- **Customer names** that differ from the customer list ("Summit Trade", "Summit Trade Co., Ltd.", "CRESTLINE PROMO PRODUCTS") are mapped to the full name on the list. Matching ignores case, punctuation and legal suffixes (Inc, LLC, Ltd, Co, Group), and accepts a name that is the leading part of exactly one list entry. If zero or several customers match, the name is not guessed.
- **Amounts** written as "$86,000.00", "USD 39800", "180,000 USD", "258k" or "28.5k" are converted to plain numbers in USD. Text that cannot be read holds the row back for confirmation.
- **Dates** written as ISO text, "2 Jul 2026", "Sept 3" or with slashes are converted to true dates. A date with no year gets the ledger year (2026) and is logged.
- **Day/month order** for slash dates is decided per ledger: the script counts the unambiguous slash dates in that ledger (for example 28/09/2026 can only be day-first) and uses the majority format, defaulting to month-first when there is no evidence. A slash date that is genuinely ambiguous (such as 09/10/2026) is still imported using that convention, but is flagged with both readings.
- **Contract numbers** with case or spacing differences are upper-cased and stripped.
- **Capitalisation** differences in category and department fields are standardised to the most common spelling in that ledger.
- **Duplicates**: identical rows are merged. A bank reference entered twice with the same payer and amount is merged, even when the date or the person who entered it differs. The same key with different details is held back and flagged.
- **Approval statuses** ("approved", "Approved ✓", "OK", "rejected", "pending mgr", blank) are mapped to Approved, Rejected, Pending manager approval or Draft. A status that names no approval step is logged so the manager can re-confirm it, and an unrecognised status is flagged.
- **Uncertain cases are never decided silently.** A payment citing a contract number that does not exist, a payment with no contract number, a payer that differs from the contract's customer, and an order total above the contract value are all imported as written, left unlinked where linking would be a guess, and marked "Needs business confirmation". An order that cites an unknown contract is held back until confirmed.

## Output

`output/clean_dataset.xlsx` contains:

| Sheet | Content |
|---|---|
| Customers, Contracts, Orders, Payments, Expenses | Clean master data. Contracts also carry computed due date, ordered, paid, outstanding and overdue amounts |
| Approval Log | One import record per expense, keeping the original status wording as an audit trail |
| Reconciliation | Per ledger: source rows, blank rows, merged duplicates, held-back rows, imported rows, source and imported totals, the difference, and an OK / Mismatch check. Cross-checks tie the payments and orders totals to the Contracts sheet |
| Issue Log | Issue ID, source file, source row(s), issue type, original value, action taken, status (Fixed or Needs business confirmation) |

Overdue is calculated as the full outstanding amount once the due date (signed date plus the customer's payment terms) is before the reporting date. Payments awaiting confirmation are not linked to a contract, so they do not reduce that contract's outstanding amount until the business decides.

## Result of the sample run

- 4 business ledgers with 56 source rows (plus an 8-row customer list); 1 blank row skipped and 3 duplicate rows merged (one each in contracts, orders and payments), leaving 12 contracts, 16 orders, 14 payments and 10 expenses.
- 17 issue types found, in 34 issue log entries: 13 types fixed by rules, 4 types (5 entries) flagged "Needs business confirmation".
- The 5 flagged entries: a payment citing contract CT-2026-013, which does not exist; a payment of 30,000.00 with no contract number from a customer with two contracts; one contract whose orders (76,500.00) exceed its value (72,000.00); and two genuinely ambiguous day/month dates.
- Contract value totals 1,481,300.00 after the merge, against 1,739,300.00 in the source rows; the 258,000.00 difference is exactly the merged duplicate contract.
- Orders: 1,106,300.00 in the source, 1,077,800.00 imported (difference 28,500.00 = the merged duplicate order). Payments: 943,800.00 in the source, 901,300.00 imported (difference 42,500.00 = the merged duplicate bank reference), of which 853,300.00 is linked to contracts and 48,000.00 awaits confirmation. Expenses: 47,720.00 before and after.
- Every reconciliation check reads OK: row counts and amount totals tie out once the merged duplicates are accounted for.

## What a real project would adjust

- Field mapping and rules are agreed against your real ledgers first, then run in bulk.
- The day/month convention and the fixed currency are confirmed with the people who keep the ledgers.
- The output layout is matched to the system you are importing into.

## License

MIT. See `LICENSE`.
